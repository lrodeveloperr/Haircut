/* Haircut Studio customers: generated people, skin, hair textures, baldness, trimmable beards, face shapes. */
// ---------------------------------------------------------------------------------------------
// Customer generator. Every customer is a plain, serialisable record derived deterministically from
// a seed, so a saved session always brings back the same person.
//
// Heritage groups only steer *correlated* traits (skin tone range, hair texture, natural hair colour,
// eye colour, beard density, how common pattern baldness is, and small average face-shape tendencies).
// Individual variation is always larger than the group tendency, and face-shape offsets are kept
// subtle so nobody is drawn as a caricature. Group ids are internal and never shown to the player.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';

  const PERSON_VERSION = 1;

  // small deterministic PRNG (mulberry32)
  function rng(seed) {
    // scramble the seed first (murmur3 finaliser) so nearby seeds give unrelated people
    let a = seed >>> 0;
    a = Math.imul(a ^ (a >>> 16), 0x85ebca6b);
    a = Math.imul(a ^ (a >>> 13), 0xc2b2ae35);
    a = (a ^ (a >>> 16)) >>> 0 || 1;
    const next = () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    return {
      next,
      range: (lo, hi) => lo + (hi - lo) * next(),
      int: (lo, hi) => lo + Math.floor(next() * (hi - lo + 1)),
      // approximately normal (sum of uniforms)
      gauss: (sd = 1) => (next() + next() + next() + next() - 2) * 1.732 * sd,
      pick(weights) {
        const entries = Object.entries(weights).filter(([, w]) => w > 0);
        let total = 0;
        for (const [, w] of entries) total += w;
        let x = next() * total;
        for (const [k, w] of entries) {
          if ((x -= w) < 0) return k;
        }
        return entries[entries.length - 1][0];
      },
    };
  }
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const smooth = (e0, e1, x) => {
    const t = clamp((x - e0) / (e1 - e0), 0, 1);
    return t * t * (3 - 2 * t);
  };

  // ---- skin: 10 tones from very fair to very deep, linear albedo used directly by the skin shader ----
  const SKIN_TONES = [
    [0.7, 0.425, 0.345],
    [0.66, 0.385, 0.3],
    [0.615, 0.37, 0.27],
    [0.56, 0.345, 0.235],
    [0.485, 0.298, 0.19],
    [0.4, 0.24, 0.15],
    [0.31, 0.182, 0.112],
    [0.225, 0.128, 0.082],
    [0.155, 0.088, 0.058],
    [0.105, 0.06, 0.042],
  ];
  const UNDERTONES = {
    pink: [1.03, 0.97, 1.0],
    neutral: [1, 1, 1],
    olive: [0.98, 1.02, 0.94],
    golden: [1.03, 1.0, 0.85],
    red: [1.04, 0.96, 0.95],
  };

  // ---- hair colour: index into the game's 12 colour presets ----
  const HAIR = {
    jet: 0, softBlack: 1, vdb: 2, db: 3, mb: 4, lb: 5, dblonde: 6, gblonde: 7, lblonde: 8, auburn: 9, ginger: 10, silver: 11,
  };
  // stubble / brow tint per preset (dark-end colour of the hair, linear)
  const HAIR_DARK = [
    [0.012, 0.011, 0.012], [0.018, 0.016, 0.016], [0.026, 0.019, 0.014], [0.035, 0.024, 0.018], [0.05, 0.034, 0.022],
    [0.075, 0.052, 0.033], [0.1, 0.075, 0.045], [0.14, 0.1, 0.05], [0.2, 0.16, 0.1], [0.08, 0.035, 0.018],
    [0.13, 0.05, 0.02], [0.18, 0.18, 0.18],
  ];

  const EYES = {
    blue: ['#a8c4d6', '#5d90b3', '#34688d', '#1d3c55'],
    grey: ['#c4cdd2', '#8b9aa3', '#5f6e78', '#36424a'],
    green: ['#b5c49a', '#6f8e55', '#4d6b3a', '#2c3f22'],
    hazel: ['#c9b27a', '#8d7a45', '#5f5a33', '#3a331c'],
    lbrown: ['#b38a5a', '#7d5631', '#5a3b1f', '#33200f'],
    brown: ['#8a6038', '#5a3a1e', '#3d2612', '#22150a'],
    dbrown: ['#5a3c22', '#3a2412', '#26170b', '#140c06'],
  };

  // morph keys, each in [-1, 1]; see faces.js for what they do
  const MORPHS = ['noseW', 'noseBridge', 'noseTip', 'lips', 'jaw', 'chin', 'cheek', 'brow'];

  const HERITAGE = [
    { id: 'nw-europe', w: 14, skin: [0, 2.6], under: { pink: 3, neutral: 2, red: 1 },
      tex: { straight: 6, wavy: 3, curly: 1 },
      hair: { softBlack: 0.5, vdb: 2.5, db: 5, mb: 5, lb: 4, dblonde: 3, gblonde: 2, lblonde: 1.2, auburn: 1, ginger: 1 },
      eyes: { blue: 4, grey: 1, green: 2, hazel: 2, lbrown: 1.5, brown: 2 }, greyOnset: 34, bald: 1, beard: 1, patchy: 0.1,
      morph: { noseW: -0.3, noseBridge: 0.35, noseTip: 0.15, lips: -0.25, jaw: 0.1, chin: 0.15, cheek: -0.1, brow: 0.35 } },
    { id: 's-europe', w: 10, skin: [1.2, 4], under: { neutral: 2, olive: 3 },
      tex: { straight: 4, wavy: 4, curly: 2 },
      hair: { jet: 1, softBlack: 3, vdb: 5, db: 5, mb: 3, lb: 1, auburn: 0.5 },
      eyes: { brown: 6, hazel: 3, green: 1.5, blue: 1, lbrown: 1 }, greyOnset: 34, bald: 1, beard: 1.1, patchy: 0.1,
      morph: { noseW: -0.05, noseBridge: 0.35, noseTip: 0.1, lips: 0, jaw: 0.1, chin: 0.1, cheek: 0, brow: 0.25 } },
    { id: 'mena', w: 9, skin: [2.6, 5], under: { olive: 3, golden: 2 },
      tex: { straight: 2, wavy: 4, curly: 4 },
      hair: { jet: 3, softBlack: 5, vdb: 4, db: 2 },
      eyes: { brown: 7, dbrown: 2, hazel: 2, green: 1 }, greyOnset: 33, bald: 1, beard: 1.3, patchy: 0.05,
      morph: { noseW: 0.1, noseBridge: 0.5, noseTip: 0.2, lips: 0.1, jaw: 0.1, chin: 0, cheek: 0.1, brow: 0.25 } },
    { id: 'south-asia', w: 10, skin: [3.8, 7], under: { golden: 3, neutral: 2 },
      tex: { straight: 4, wavy: 5, curly: 1 },
      hair: { jet: 6, softBlack: 4, vdb: 2 },
      eyes: { brown: 6, dbrown: 4, hazel: 0.5, lbrown: 0.5 }, greyOnset: 33, bald: 0.9, beard: 1.1, patchy: 0.12,
      morph: { noseW: 0.2, noseBridge: 0.15, noseTip: 0.1, lips: 0.2, jaw: 0, chin: -0.05, cheek: 0.1, brow: 0.1 } },
    { id: 'east-asia', w: 11, skin: [1, 3.6], under: { golden: 4, neutral: 1 },
      tex: { straight: 9, wavy: 1 },
      hair: { jet: 7, softBlack: 4, vdb: 1 },
      eyes: { dbrown: 7, brown: 3 }, greyOnset: 37, bald: 0.6, beard: 0.45, patchy: 0.45,
      morph: { noseW: 0.15, noseBridge: -0.5, noseTip: -0.2, lips: 0.1, jaw: 0.2, chin: -0.1, cheek: 0.4, brow: -0.4 } },
    { id: 'se-asia', w: 6, skin: [3, 6], under: { golden: 4, neutral: 1 },
      tex: { straight: 7, wavy: 3 },
      hair: { jet: 7, softBlack: 3 },
      eyes: { dbrown: 6, brown: 4 }, greyOnset: 37, bald: 0.65, beard: 0.5, patchy: 0.4,
      morph: { noseW: 0.35, noseBridge: -0.4, noseTip: -0.15, lips: 0.3, jaw: 0.1, chin: -0.1, cheek: 0.3, brow: -0.3 } },
    { id: 'w-africa', w: 13, skin: [5.8, 9.4], under: { neutral: 3, golden: 1, red: 1 },
      tex: { coily: 9, curly: 1 },
      hair: { jet: 8, softBlack: 3 },
      eyes: { dbrown: 8, brown: 2 }, greyOnset: 40, bald: 0.7, beard: 0.9, patchy: 0.15,
      morph: { noseW: 0.6, noseBridge: -0.3, noseTip: -0.1, lips: 0.6, jaw: 0.1, chin: 0, cheek: 0.2, brow: 0.1 } },
    { id: 'e-africa', w: 5, skin: [5.8, 8.6], under: { neutral: 3, red: 1 },
      tex: { coily: 7, curly: 3 },
      hair: { jet: 8, softBlack: 2 },
      eyes: { dbrown: 7, brown: 3 }, greyOnset: 40, bald: 0.7, beard: 0.8, patchy: 0.2,
      morph: { noseW: 0.2, noseBridge: 0.1, noseTip: 0, lips: 0.4, jaw: 0, chin: 0.05, cheek: 0.3, brow: 0.1 } },
    { id: 'latin', w: 12, skin: [2, 6.2], under: { olive: 2, golden: 2, neutral: 2 },
      tex: { straight: 4, wavy: 4, curly: 2, coily: 0.5 },
      hair: { jet: 4, softBlack: 5, vdb: 4, db: 2, mb: 1 },
      eyes: { brown: 7, dbrown: 2, hazel: 2, green: 0.5, lbrown: 1 }, greyOnset: 35, bald: 0.9, beard: 1, patchy: 0.15,
      morph: { noseW: 0.2, noseBridge: 0.05, noseTip: 0, lips: 0.2, jaw: 0.1, chin: 0, cheek: 0.2, brow: 0 } },
    { id: 'indigenous', w: 3, skin: [3, 6], under: { golden: 3, red: 1 },
      tex: { straight: 9, wavy: 1 },
      hair: { jet: 8, softBlack: 2 },
      eyes: { dbrown: 8, brown: 2 }, greyOnset: 38, bald: 0.6, beard: 0.4, patchy: 0.45,
      morph: { noseW: 0.2, noseBridge: 0.3, noseTip: 0.1, lips: 0.1, jaw: 0.2, chin: 0, cheek: 0.5, brow: 0 } },
    { id: 'pacific', w: 3, skin: [4.5, 7], under: { golden: 3, neutral: 1 },
      tex: { wavy: 4, curly: 5, straight: 1 },
      hair: { jet: 7, softBlack: 3 },
      eyes: { dbrown: 7, brown: 3 }, greyOnset: 38, bald: 0.7, beard: 0.8, patchy: 0.25,
      morph: { noseW: 0.5, noseBridge: -0.1, noseTip: -0.05, lips: 0.4, jaw: 0.4, chin: 0.05, cheek: 0.3, brow: 0.1 } },
  ];

  const AGE_BANDS = {
    young: { w: 40, years: [18, 30] },
    middle: { w: 35, years: [31, 55] },
    old: { w: 25, years: [56, 84] },
  };

  // Hamilton-Norwood stage probabilities by age band (stage 1 = no recession). Stage '3v' is the
  // vertex (crown) variant. Shifted toward stage 1 for groups where pattern baldness is less common.
  const NORWOOD = {
    young: { 1: 52, 2: 28, 3: 11, '3v': 4, 4: 3, 5: 1.5, 6: 0.4, 7: 0.1 },
    middle: { 1: 24, 2: 22, 3: 15, '3v': 10, 4: 11, 5: 8, 6: 6, 7: 4 },
    old: { 1: 12, 2: 13, 3: 12, '3v': 10, 4: 12, 5: 13, 6: 14, 7: 14 },
  };
  // [front recession, temple recession, crown radius, bridge loss, horseshoe (fringe drop)] in radians-ish
  const NORWOOD_SHAPE = {
    1: [0, 0, 0, 0, 0],
    2: [0.02, 0.1, 0, 0, 0],
    3: [0.05, 0.2, 0, 0, 0],
    '3v': [0.05, 0.2, 0.17, 0, 0],
    4: [0.14, 0.27, 0.23, 0, 0],
    5: [0.26, 0.34, 0.3, 0.5, 0],
    6: [0.46, 0.42, 0.36, 1, 0],
    7: [0.62, 0.5, 0.44, 1, 0.3],
  };

  // beard styles: which regions carry hair and how long (mm ranges)
  const BEARD_STYLES = {
    clean: {},
    stubble: { moustache: [0.8, 2], chin: [0.8, 2], cheeks: [0.8, 2], neck: [0.5, 1.5], jaw: [0.8, 2] },
    moustache: { moustache: [8, 16] },
    goatee: { moustache: [6, 12], chin: [8, 16] },
    vandyke: { moustache: [8, 14], chin: [10, 20], chinOnly: true },
    chinstrap: { jaw: [4, 8], chin: [4, 8] },
    boxed: { moustache: [6, 10], chin: [8, 13], cheeks: [6, 10], jaw: [8, 13], neck: [3, 6] },
    full: { moustache: [10, 16], chin: [13, 22], cheeks: [10, 16], jaw: [13, 22], neck: [8, 13] },
    long: { moustache: [13, 20], chin: [30, 50], cheeks: [16, 25], jaw: [25, 40], neck: [16, 25] },
    mutton: { cheeks: [10, 16], jaw: [8, 13] },
  };
  const BEARD_BY_AGE = {
    young: { clean: 30, stubble: 28, boxed: 10, goatee: 8, moustache: 2, chinstrap: 6, full: 10, vandyke: 4, long: 0.5 },
    middle: { clean: 26, stubble: 20, boxed: 14, goatee: 10, full: 14, moustache: 6, vandyke: 4, chinstrap: 2, long: 2, mutton: 1 },
    old: { clean: 30, stubble: 10, moustache: 15, full: 14, long: 9, boxed: 10, goatee: 7, mutton: 3, vandyke: 2 },
  };

  function makePerson(seed, opts = {}) {
    const R = rng(seed);
    const weights = {};
    HERITAGE.forEach((h, i) => (weights[i] = h.w));
    const her = HERITAGE[opts.heritage != null ? opts.heritage : +R.pick(weights)];

    const ageBand = opts.age || R.pick(Object.fromEntries(Object.entries(AGE_BANDS).map(([k, v]) => [k, v.w])));
    const [y0, y1] = AGE_BANDS[ageBand].years;
    const years = R.int(y0, y1);
    const age01 = clamp((years - 18) / (80 - 18), 0, 1);

    const skinT = R.range(her.skin[0], her.skin[1]);
    const under = R.pick(her.under);
    const texture = opts.texture || R.pick(her.tex);
    // curl tightness inside the texture family (e.g. 3a..3c, 4a..4c)
    const curl = R.next();

    let hairColour = HAIR[R.pick(her.hair)];
    // fair hair tends to darken by adulthood
    if (hairColour >= HAIR.dblonde && hairColour <= HAIR.lblonde && ageBand !== 'young' && R.next() < 0.4) hairColour -= 1;

    // greying: individual onset age, then a gradual increase; beards and temples grey first
    const onset = her.greyOnset + R.gauss(6);
    const greyRaw = clamp((years - onset) / 44, 0, 1);
    const grey = Math.min(0.97, Math.pow(greyRaw, 1.1));
    const beardGrey = clamp(grey * 1.25 + (years > onset - 4 ? 0.04 : 0), 0, 1);

    // pattern baldness
    const nwTable = Object.assign({}, NORWOOD[ageBand]);
    const keep = her.bald;
    for (const k of Object.keys(nwTable)) if (k !== '1') nwTable[k] *= keep;
    let norwood = opts.norwood != null ? String(opts.norwood) : R.pick(nwTable);
    const diffuse = R.next() < 0.06 + 0.1 * age01 ? R.range(0.15, 0.45) * (0.4 + age01) : 0;

    // beard: style frequency by age, sparser for groups with lighter beard growth
    const bw = Object.assign({}, BEARD_BY_AGE[ageBand]);
    if (her.beard < 0.7) {
      bw.full *= 0.35; bw.boxed *= 0.45; bw.long *= 0.3; bw.mutton *= 0.3;
      bw.clean *= 1.6; bw.goatee = (bw.goatee || 0) * 1.3; bw.moustache = (bw.moustache || 0) * 1.4;
    }
    const beardStyle = opts.beard || R.pick(bw);
    const style = BEARD_STYLES[beardStyle];
    const beard = {};
    for (const region of ['moustache', 'chin', 'cheeks', 'jaw', 'neck']) {
      if (style[region]) beard[region] = +R.range(style[region][0], style[region][1]).toFixed(1);
    }
    const cheekLine = R.range(-1, 1); // high (-1) to low (1) cheek line
    const neckLine = R.range(-1, 1);
    const patchy = clamp(her.patchy + R.gauss(0.08) + (ageBand === 'young' ? 0.12 : 0), 0, 0.85);

    // face shape: group tendency (subtle) + individual variation (larger)
    const morph = {};
    for (const k of MORPHS) morph[k] = +clamp(0.55 * (her.morph[k] || 0) + R.gauss(0.42), -1, 1).toFixed(3);
    if (opts.morph) Object.assign(morph, opts.morph);

    const eyes = R.pick(her.eyes);
    const brow = { thick: +clamp(R.range(0.82, 1.18) + 0.18 * age01, 0.7, 1.45).toFixed(3), grey: +clamp(grey * 0.65, 0, 1).toFixed(3) };

    return {
      v: PERSON_VERSION,
      seed: seed >>> 0,
      heritage: her.id,
      age: ageBand,
      years,
      skin: { tone: +skinT.toFixed(3), under },
      hair: { texture, curl: +curl.toFixed(3), colour: hairColour, grey: +grey.toFixed(3) },
      bald: { norwood, diffuse: +diffuse.toFixed(3), edge: +R.range(0, 1).toFixed(3) },
      beard: { style: beardStyle, mm: beard, grey: +beardGrey.toFixed(3), patchy: +patchy.toFixed(3), cheekLine: +cheekLine.toFixed(3), neckLine: +neckLine.toFixed(3),
        warm: +clamp(R.gauss(0.5) + 0.15, 0, 1).toFixed(3) },
      eyes,
      brow,
      morph,
    };
  }

  function validPerson(p) {
    return (
      !!p && typeof p === 'object' && p.v === PERSON_VERSION &&
      Number.isInteger(p.years) && p.years >= 16 && p.years <= 95 && AGE_BANDS[p.age] &&
      p.skin && Number.isFinite(p.skin.tone) && UNDERTONES[p.skin.under] &&
      p.hair && ['straight', 'wavy', 'curly', 'coily'].includes(p.hair.texture) && Number.isInteger(p.hair.colour) &&
      p.hair.colour >= 0 && p.hair.colour < HAIR_DARK.length && Number.isFinite(p.hair.grey) &&
      p.bald && NORWOOD_SHAPE[p.bald.norwood] && p.beard && BEARD_STYLES[p.beard.style] && EYES[p.eyes] && p.morph && p.brow
    );
  }

  // the colour of skin at tone t (0..9.4, fractional), with undertone
  function skinColour(p) {
    const t = clamp(p.skin.tone, 0, SKIN_TONES.length - 1);
    const i = Math.min(SKIN_TONES.length - 2, Math.floor(t)), f = t - i;
    const u = UNDERTONES[p.skin.under] || UNDERTONES.neutral;
    return [0, 1, 2].map((k) => (SKIN_TONES[i][k] * (1 - f) + SKIN_TONES[i + 1][k] * f) * u[k]);
  }

  Object.assign(HSC, {
    rng, clamp, smooth, makePerson, validPerson, skinColour,
    SKIN_TONES, UNDERTONES, HAIR_DARK, EYES, MORPHS, HERITAGE, NORWOOD_SHAPE, BEARD_STYLES, PERSON_VERSION,
  });
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Shader code driven by the current customer. All coordinates are the head mesh's own (un-morphed)
// object space: y up, +z toward the face, the scalp top around y = 3.9.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';

  // Uniforms shared by every material that draws the customer. Plain arrays work for vecN uniforms.
  HSC.U = {
    uBaldA: { value: [0, 0, 0, 0] }, // front recession, temple recession, crown radius, bridge loss
    uBaldB: { value: [0, 0, 0, 0] }, // horseshoe fringe drop, diffuse thinning, pattern seed, -
    uBrowA: { value: [1, 1, 0, 0] }, // brow thickness, brow density
    uBeard: { value: null }, // beard length grid (mm / 50)
    uSkinA: { value: [0.66, 0.385, 0.3, 0] }, // base albedo, darkness 0..1
    uLip: { value: [1.06, 0.78, 0.93] }, // lip colour relative to skin
    uCast: { value: [0.7, 0.73, 0.8, 1] }, // shaved-follicle cast colour, strength
    uHairDark: { value: [0.035, 0.024, 0.018] }, // hair colour where it covers skin (scalp)
    uBeardDark: { value: [0.035, 0.024, 0.018] }, // beard colour where it covers skin
    uBrowTint: { value: [0.085, 0.055, 0.04] },
    uAgeA: { value: [0, 0, 0, 0] }, // age 0..1, age spots, wrinkle depth, sallowness
    uStyleA: { value: [0.22, 0.56, 0.56, 0.5] }, // hang, forward, lift, top lift
    uStyleB: { value: [0.16, 0.1, 0.02, 1] }, // spread, sag, wave, wave frequency
    uStyleC: { value: [0, 0, 1, 1] }, // coil radius (x length), coil turns, shrinkage, strand thickness
    uGreyA: { value: [0, 0.6, 0.62, 0] }, // grey fraction, temple bias, grey brightness, -
    uBStyleA: { value: [0, 0.15, 0.45, 0.1] }, // beard: wave, wave frequency, lift, sag
    uBStyleB: { value: [0, 0, 1, 1] }, // beard: coil radius, coil turns, shrinkage, thickness
    uBeardTint: { value: [1, 1, 1] },
    uBeardGrey: { value: [0, 0.62, 0.3, 0] }, // grey fraction, grey brightness, patchiness, -
    uDebug: { value: 0 },
  };

  // Beard grid: a 128 x 64 map of the lower face, projected from a point inside the mouth.
  const BC = [0, 0.3, 0.3], AZR = 1.85, EL0 = -1.45, ELR = 2.25;
  HSC.BEARD_PROJ = { BC, AZR, EL0, ELR };

  // ---- shared declarations, injected into the game's common shader prelude ----
  HSC.glsl = {};
  HSC.glsl.decls = `
uniform vec4 uBaldA, uBaldB, uBrowA;
uniform sampler2D uBeard;
uniform float uDebug;
// Pattern baldness (Hamilton-Norwood): 1 where hair grows, 0 where it is gone, a soft thinning band between.
float baldDensity(vec3 p){
  if (uBaldA.x + uBaldA.y + uBaldA.z + uBaldB.x + uBaldB.y < .001) return 1.0;
  vec3 q = vec3(p.x, p.y - 2.1, p.z + .13);
  float th = atan(q.z, q.y);                  // 0 on top, + toward the face, - toward the nape
  float ph = atan(p.x, length(q.yz));         // left / right
  float aph = abs(ph);
  float wob = (n3(p * 2.7 + uBaldB.z) - .5) * .10 + (n3(p * 8.0 + uBaldB.z) - .5) * .035;
  // frontal and temporal recession: the hairline moves back from its natural line
  float templ = exp(-pow((aph - .58) / .22, 2.0));
  float rec = uBaldA.x + uBaldA.y * templ;
  float hairline = 1.13 - rec + wob;
  float front = smoothstep(hairline - .05, hairline + .07, th) * step(.001, rec) * smoothstep(2.35, 2.7, p.y);
  // crown (vertex) bald spot
  float cr = length(vec2(th + .27, ph * 1.05));
  float crown = (1.0 - smoothstep(uBaldA.z - .09, uBaldA.z + .02, cr + wob * .8)) * step(.001, uBaldA.z);
  // the bridge between them goes as the pattern advances
  float bw = mix(.25, .62, uBaldA.w) + wob;
  float bridge = uBaldA.w * smoothstep(-.3, -.15, th) * (1.0 - smoothstep(bw - .08, bw + .04, aph)) * smoothstep(2.35, 2.7, p.y);
  // horseshoe: only a fringe stays around the sides and back
  // the fringe sits low over the ears and rises toward the back of the head
  float fringe = 3.08 - uBaldB.x - .18 * smoothstep(.9, 1.5, aph) + .22 * smoothstep(-.2, -.9, th) * (1.0 - smoothstep(.6, 1.3, aph)) + wob * 1.4;
  float top = step(.001, uBaldB.x) * smoothstep(fringe - .06, fringe + .1, p.y);
  float b = max(max(front, crown), max(bridge, top));
  float d = 1.0 - b;
  // diffuse thinning over the top
  d *= 1.0 - uBaldB.y * smoothstep(2.9, 3.5, p.y) * (.55 + .45 * n3(p * 3.3 + 9.0));
  return clamp(d, 0.0, 1.0);
}
const vec3 BEARD_C = vec3(${BC.join(',')});
vec2 beardUV(vec3 p){
  vec3 d = p - BEARD_C;
  float az = atan(d.x, d.z);
  float el = atan(d.y, length(d.xz));
  return vec2(az / ${(2 * AZR).toFixed(4)} + .5, (el - (${EL0.toFixed(4)})) / ${ELR.toFixed(4)});
}
float beardMM(vec3 p){ return texture2D(uBeard, beardUV(p)).r * 50.0; }
float lipMask(vec3 p){
  float ax = abs(p.x), ly = p.y - .125;
  float lipW = 1.0 - smoothstep(.55, .72, ax);
  float upL = (1.0 - smoothstep(.55, .95, length(vec2(p.x / .66, (ly - .12) / .15)))) * step(.0, ly);
  float loL = (1.0 - smoothstep(.55, .95, length(vec2(p.x / .62, (ly + .13) / .21)))) * step(ly, .0);
  return max(upL, loL) * smoothstep(1.8, 2.2, p.z) * lipW;
}
// the area where a beard can grow (individual styles use part of it)
float beardZoneS(vec3 p, float soft){
  float ax = abs(p.x);
  float ang = atan(ax, p.z - .25);
  float yTop = mix(.53, 1.3, smoothstep(.3, 1.45, ang));
  float yBot = mix(-1.22, -.8, smoothstep(.85, 1.6, ang));
  float m = smoothstep(yBot - .04 * soft, yBot + .08 * soft, p.y) * (1.0 - smoothstep(yTop - .08 * soft, yTop + .03, p.y));
  m *= 1.0 - smoothstep(1.5 - .03 * soft, 1.64, ang);
  m *= 1.0 - smoothstep(.15, .5, lipMask(p));
  return m;
}
float beardZone(vec3 p){ return beardZoneS(p, 1.0); }
`;

  // ---- skin material (replaces the game's onBeforeCompile for the head) ----
  HSC.skinCompile = function (e, ctx) {
    Object.assign(e.uniforms, { uGrid: ctx.uGrid, uHairTint: ctx.uHairTint, uDensity: ctx.uDensity }, HSC.U);
    e.vertexShader = e.vertexShader
      .replace('#include <common>', `#include <common>
attribute vec3 hsBase;
varying vec3 vObj;`)
      .replace('#include <begin_vertex>', `#include <begin_vertex>
vObj = hsBase;`);
    e.fragmentShader = e.fragmentShader
      .replace('#include <common>', `#include <common>
varying vec3 vObj;
${ctx.Ql}
uniform vec4 uSkinA, uCast, uAgeA, uBeardGrey;
uniform vec3 uLip, uHairDark, uBeardDark, uBrowTint;
float skinBump(vec3 P){ return .55 * n3(P * 62.0) + .30 * n3(P * 118.0) + .15 * n3(P * 36.0); }
float segDist(vec2 p, vec2 a, vec2 b){ vec2 pa = p - a, ba = b - a; float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0); return length(pa - ba * h); }
// expression lines and folds that deepen with age (0 = none)
float wrinkles(vec3 P, float age){
  if (age < .02) return 0.0;
  float aX = abs(P.x), w = 0.0;
  // forehead: horizontal, slightly wavy lines
  float fh = smoothstep(2.12, 2.3, P.y) * (1.0 - smoothstep(2.72, 2.9, P.y)) * smoothstep(1.55, 1.95, P.z) * (1.0 - smoothstep(.85, 1.25, aX));
  float fl = pow(abs(sin(P.y * 26.0 + 2.6 * n3(P * vec3(1.6, .4, 1.6)) + .8 * sin(P.x * 2.3))), 22.0);
  float broken = smoothstep(.35, .65, n3(P * vec3(2.2, 9.0, 2.2) + 5.0));   // lines fade in and out along their length
  w += fh * fl * broken * smoothstep(.25, .85, age) * .7;
  // frown lines between the brows
  float gl = (1.0 - smoothstep(.0, .035, abs(aX - .13 - .05 * (P.y - 2.0)))) * smoothstep(1.85, 1.95, P.y) * (1.0 - smoothstep(2.15, 2.3, P.y)) * smoothstep(2.0, 2.2, P.z);
  w += gl * smoothstep(.3, .8, age) * .8;
  // crow's feet at the outer eye corners
  vec2 cf = vec2(aX - .98, P.y - 1.6);
  float cr = length(cf), ca = atan(cf.y, cf.x);
  float crow = (1.0 - smoothstep(.12, .36, cr)) * smoothstep(.04, .1, cr) * step(-.02, cf.x) * pow(abs(sin(ca * 7.0 + 2.0 * n3(P * 5.0))), 10.0);
  w += crow * smoothstep(.2, .75, age);
  // nasolabial folds (nose wing to mouth corner) and marionette lines (mouth corner down)
  vec2 xy = vec2(aX, P.y);
  float nl = 1.0 - smoothstep(.0, .045 + .02 * age, segDist(xy, vec2(.36, .66), vec2(.7, .02)));
  float ml = 1.0 - smoothstep(.0, .035, segDist(xy, vec2(.66, .0), vec2(.62, -.45)));
  w += nl * smoothstep(1.7, 2.1, P.z) * (.25 + .75 * smoothstep(.1, .8, age));
  w += ml * smoothstep(1.6, 1.95, P.z) * smoothstep(.55, .95, age);
  // under-eye lines
  vec2 ue = vec2((aX - .63) / .32, (P.y - 1.33) / .1);
  w += (1.0 - smoothstep(.0, .25, abs(length(ue) - 1.0))) * step(P.y, 1.4) * smoothstep(1.8, 2.05, P.z) * smoothstep(.3, .9, age) * .6;
  // neck rings
  float nk = .6 * pow(abs(sin(P.y * 22.0 + n3(P * 2.0) * 2.0)), 10.0) * smoothstep(-1.7, -1.35, P.y) * (1.0 - smoothstep(-1.05, -.9, P.y)) * smoothstep(.3, .9, P.z);
  w += nk * smoothstep(.45, 1.0, age) * .7;
  return clamp(w, 0.0, 1.0) * uAgeA.z;
}
`)
      .replace('#include <map_fragment>', `
      vec3 P = vObj; float aX = abs(P.x);
      vec3 base = uSkinA.rgb; float dark = uSkinA.w; float age = uAgeA.x;
      vec3 tone = base;
      tone *= 1.0 + .10 * (n3(P * 1.1) - .5);
      tone *= 1.0 + vec3(.11, -.03, -.03) * (n3(P * 2.6 + 4.0) - .5);
      tone *= 1.0 + vec3(.08, -.025, -.025) * (n3(P * 9.0 + 11.0) - .5);
      float pores = pow(n3(P * 85.0), 4.0);
      tone *= 1.0 - (.14 + .08 * age) * pores;
      // older skin: a little sallower and less even
      tone *= mix(vec3(1.0), vec3(1.0, .965, .92), uAgeA.w);
      tone *= 1.0 + .12 * age * (n3(P * 4.5 + 3.0) - .5);
      float fr = smoothstep(.2, 2.0, P.z);
      float flush = 1.0 - .75 * dark;   // redness reads much less on deeper skin
      float cheek = fr * (1.0 - smoothstep(.55, 1.5, aX - .35)) * smoothstep(-.4, .5, P.y) * (1.0 - smoothstep(1.3, 1.9, P.y));
      tone *= 1.0 + vec3(.12, -.05, -.05) * cheek * flush;
      float nose = 1.0 - smoothstep(.0, .5, length(vec3(P.x, P.y - .8, P.z - 2.5)));
      tone *= 1.0 + vec3(.11, -.05, -.05) * nose * flush;
      float ear = smoothstep(1.66, 1.85, aX) * (1.0 - smoothstep(2.2, 2.7, P.y));
      tone *= 1.0 + vec3(.14, -.05, -.03) * ear * flush;
      // lips + mouth line
      float ly = P.y - .125;
      float lipsM = lipMask(P);
      float lipTone = n3(P * 40.0);
      vec3 lipC = base * uLip * mix(vec3(1.0), vec3(.94, .87, .87), step(ly, .0)) * (.9 + .2 * lipTone);
      lipC *= 1.0 - .25 * (1.0 - smoothstep(.0, .06, abs(ly - .06)));
      tone = mix(tone, lipC, lipsM * .95);
      float mline = (1.0 - smoothstep(.0, .022, abs(ly + .035 * P.x * P.x * 2.0))) * (1.0 - smoothstep(.5, .66, aX)) * smoothstep(1.9, 2.3, P.z);
      tone *= 1.0 - .6 * mline;
      // nostrils
      float nost = 1.0 - smoothstep(.04, .13, length(vec3((aX - .21) * 1.2, (P.y - .60) * 1.6, P.z - 2.36)));
      tone *= 1.0 - .7 * nost;
      // eye sockets, lid creases, lash lines
      vec3 eC = vec3(aX - 0.628, P.y - 1.624, P.z - 1.627);
      float eyesock = 1.0 - smoothstep(.0, .8, length(eC));
      tone *= 1.0 - (.20 + .08 * age) * eyesock;
      vec2 eo = vec2(eC.x / .40, eC.y / .21);
      float ring = 1.0 - smoothstep(.0, .12, abs(length(eo) - 1.0));
      float upper = smoothstep(-.1, .5, eC.y);
      tone *= 1.0 - ring * (.25 + .35 * upper) * smoothstep(.4, 1.0, P.z);
      float crease = (1.0 - smoothstep(.0, .06, abs(length(vec2(eC.x / .46, (eC.y - .12) / .30)) - 1.0))) * upper;
      tone *= 1.0 - (.08 + .1 * age) * crease;
      // dark circles under the eyes
      float circ = (1.0 - smoothstep(.0, .3, length(vec2((aX - .62) / 1.3, P.y - 1.36)))) * smoothstep(1.8, 2.1, P.z);
      tone *= 1.0 - circ * (.06 + .1 * age) * vec3(.8, 1.0, 1.0);
      // eyebrows
      float bm = browMask(P) * uBrowA.y;
      float browHair = .72 + .5 * n3(P * vec3(95.0, 230.0, 95.0));
      tone = mix(tone, uBrowTint * browHair, clamp(bm * 1.25, 0.0, .94));
      // age spots on the sun-exposed upper face and scalp
      float sunlit = smoothstep(1.9, 2.6, P.y) * (smoothstep(1.2, 2.0, P.z) + smoothstep(3.0, 3.6, P.y)) + smoothstep(1.4, 1.75, aX) * smoothstep(1.3, 2.0, P.y) * .5;
      float spots = smoothstep(.76, .82, n3(P * 11.0 + 19.0)) * (.5 + .5 * n3(P * 37.0));
      tone *= mix(vec3(1.0), vec3(.9, .82, .74), clamp(spots * sunlit, 0.0, 1.0) * uAgeA.y);
      // beard area: shaved-follicle cast, follicle dots, and the stubble itself
      float bz = beardZone(P);
      float bmm = beardMM(P) * bz;
      float folF = 42.0;
      vec3 fc = floor(P * folF), ff = fract(P * folF);
      vec3 fj = .3 + .4 * vec3(hsh(fc), hsh(fc + 17.0), hsh(fc + 31.0));
      float fd = length(ff - fj);
      float faa = max(fwidth(fd), .02);
      float fol = (1.0 - smoothstep(.2 - faa, .2 + faa, fd)) * step(.25, hsh(fc + 5.0));
      float folAA = 1.0 - smoothstep(.25, .7, length(fwidth(P)) * folF);
      // the shave shadow fades out gradually toward the cheekbones and down the neck
      float bzs = beardZoneS(P, 4.0) * (.75 + .25 * n3(P * 3.0));
      tone = mix(tone, tone * uCast.rgb, bzs * .5 * uCast.w * (1.0 - .35 * uBeardGrey.z * n3(P * 6.0)));
      tone = mix(tone, tone * vec3(.45, .45, .5), bzs * uCast.w * mix(.05, .6 * fol, folAA));
      float bedge = smoothstep(.25, .75, n3(P * 7.0 + 2.0) * .6 + smoothstep(.0, 1.2, bmm) * .7);
      float bcov = smoothstep(.15, 2.0, bmm) * mix(.78, .95, smoothstep(1.5, 5.0, bmm));
      tone = mix(tone, uBeardDark * (.8 + .4 * n3(P * 90.0)), bz * bcov * bedge * mix(.75 + .25 * n3(P * 26.0), 1.0, smoothstep(2.0, 6.0, bmm)));
      // scalp / fade skin
      float Lh = hairLen(P);
      float hm = hairMask(P);
      float hm0 = hairMask0(P);
      float baldSkin = hm0 * (1.0 - baldDensity(P));
      float st = hm * smoothstep(1.0, 2.3, P.y);
      // scalp skin sees less sun than the face: a touch paler and less red, with soft blotchy mottling
      float sc = hm0 * smoothstep(1.2, 1.9, P.y);
      vec3 scalpC = base * vec3(.977, 1.026, 1.05);
      scalpC *= 1.0 + .07 * (n3(P * 2.2 + 7.0) - .5);
      scalpC *= 1.0 + vec3(.045, -.02, -.03) * (n3(P * 2.6 + 2.0) - .5);
      // a bald scalp is sun exposed: warmer, a little ruddier
      scalpC = mix(scalpC, base * vec3(1.03, .97, .94) * (1.0 + .06 * (n3(P * 3.0) - .5)), smoothstep(.2, .8, baldSkin));
      tone = mix(tone, scalpC, sc * .9);
      // hair still below the skin leaves a cool cast over the whole growth area, even on a clean shave
      float under = st * (.85 + .15 * n3(P * 5.0 + 3.0));
      tone = mix(tone, tone * uCast.rgb, under * .6 * uCast.w);
      tone = mix(tone, tone * vec3(.42, .42, .48), st * uCast.w * mix(.06, .7 * fol, folAA));
      tone = mix(tone, tone * vec3(.26, .19, .16), st * .88 * smoothstep(0.0,.12,gridValue(P)));
      tone = mix(tone, uHairDark, smoothstep(.06, .32, Lh) * .92);
      float wr = wrinkles(P, age);
      tone *= 1.0 - .32 * wr;
      if (uDebug > .5) tone = mix(tone, vec3(.9, .1, .1), bz * .7) + vec3(0.0, .25, 0.0) * step(.5, fract(beardUV(P).x * 16.0)) * bz;
      diffuseColor.rgb = tone;`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
      roughnessFactor = mix(roughnessFactor, .26, lipsM);
      roughnessFactor = mix(roughnessFactor, .44, smoothstep(2.2, 3.0, P.y) * fr * .6);
      float scR = hm * smoothstep(1.6, 3.2, P.y);
      roughnessFactor = mix(roughnessFactor, .40 + .14 * n3(P * 7.0 + 5.0), scR * .75);
      // a bald scalp shines
      roughnessFactor = mix(roughnessFactor, .3 + .1 * n3(P * 6.0), smoothstep(.3, .9, baldSkin) * .85);
      roughnessFactor = mix(roughnessFactor, min(1.0, roughnessFactor + .12), age);`)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
      {
        float hb = skinBump(vObj) * (1.0 + .6 * age);
        hb -= .25 * (st + bzs) * fol * folAA;
        hb -= 1.6 * wr;
        vec2 dh = vec2(dFdx(hb), dFdy(hb));
        vec3 q0 = dFdx(-vViewPosition), q1 = dFdy(-vViewPosition);
        vec3 R1 = cross(q1, normal), R2 = cross(normal, q0);
        float det = dot(q0, R1);
        vec3 grad = sign(det) * (dh.x * R1 + dh.y * R2);
        normal = normalize(abs(det) * normal - .0022 * grad * (1.0 - .6 * lipsM));
      }`);
  };

  // ---- strand shaders (scalp and beard share most of the code) ----
  const strandFrag = (t, tint, grey) => t + `
 uniform vec3 lA,lB,lC,cam;
 uniform vec4 uGreyA, uBeardGrey;
 uniform vec3 uBeardTint;
 varying vec3 vRoot,vTip,vTangent,vSeed;varying float vAlong,vEdge,vLength,vGrey;
 void main(){
  if(vLength<.0001||vSeed.z>uDensity)discard;
  float edge=abs(vEdge),aa=max(fwidth(edge),.03);if(edge>1.0-aa*.25)discard;
  vec3 tangent=normalize(vTangent),view=normalize(cam-vTip);
  vec3 root=vec3(.012,.008,.005),tip=mix(vec3(.045,.029,.017),vec3(.095,.066,.036),vSeed.x);
  vec3 base=mix(root,tip,smoothstep(0.0,.9,vAlong))*${tint};
  // unpigmented (grey / white) strands, a little yellowed toward the root
  vec3 white=mix(vec3(.30,.29,.27),vec3(.62,.61,.58),fract(vSeed.x*13.7))*${grey};
  base=mix(base,white*mix(vec3(.92,.88,.8),vec3(1.0),smoothstep(.0,.6,vAlong)),vGrey);
  float light=.58+.80*sqrt(max(0.0,1.0-pow(dot(tangent,lA),2.0)));
  vec3 halfA=normalize(view+lA),halfB=normalize(view+lB);
  float glint=pow(sqrt(max(0.0,1.0-pow(dot(tangent,halfA),2.0))),65.0)*mix(.08,.14,vGrey);
  float rim=pow(sqrt(max(0.0,1.0-pow(dot(tangent,halfB),2.0))),45.0)*.04;
  vec3 lit=base*light+vec3(1.0,.88,.68)*(glint+rim)*smoothstep(.05,.6,vAlong);
  gl_FragColor=vec4(lit,1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
 }`;

  HSC.glsl.strandVert = (t) => t + `
 attribute vec3 aRoot,aNormal,aSeed;
 uniform vec3 cam;uniform float uWidth;
 uniform vec4 uStyleA,uStyleB,uStyleC,uGreyA;
 varying vec3 vRoot,vTip,vTangent,vSeed;varying float vAlong,vEdge,vLength,vGrey;
 void main(){
  float HANG=uStyleA.x,FWD=uStyleA.y,LIFT=uStyleA.z,TOPLIFT=uStyleA.w,SPREAD=uStyleB.x,SAG=uStyleB.y,WAVE=uStyleB.z,WAVEF=uStyleB.w;
  vec3 n=normalize(aNormal);
  vec3 down=vec3(0.0,-1.0,0.0);down-=n*dot(down,n);
  // at the very top of the head "down along the surface" vanishes; fall back to a fixed backward direction
  vec3 back=vec3(0.0,0.0,-1.0);back-=n*dot(back,n);
  down=normalize(mix(back,down,smoothstep(.12,.5,length(down)))+vec3(.0001));
  vec3 fwd=vec3(0.0,.25,1.0);fwd-=n*dot(fwd,n);fwd=normalize(fwd+vec3(.0001));
  // combed flow: the top lies forward, the back and sides fall down; strands scatter where the two meet
  float topW=smoothstep(3.05,3.75,aRoot.y)*smoothstep(-1.1,.2,aRoot.z);
  vec3 flow=normalize(mix(down,fwd,topW)+vec3(.0001));
  vec3 tA=normalize(cross(n,flow)+vec3(.0001));
  float g=gridValue(aRoot),hm=hairMask(aRoot);
  float stock=smoothstep(.80,1.0,g);
  float top=smoothstep(3.22,3.62,aRoot.y);
  float crown=1.0-smoothstep(.0,.42,distance(aRoot,vec3(.12,3.65,-.55)));
  float L0=${(16 / 42).toFixed(6)};
  float jitter=1.0+(aSeed.x-.5)*mix(.08,.24,stock);
  float ragged=mix(.72+.38*aSeed.y,1.0,smoothstep(.55,.98,hm));
  float L=g*L0*hm*mix(1.0,jitter*ragged,stock)*uStyleC.z;
  float shortHair=1.0-smoothstep(.10,.45,g);
  float hang=(1.0-smoothstep(2.7,3.65,aRoot.y))*HANG;
  flow=normalize(mix(flow,down,hang));
  flow=normalize(mix(flow,fwd,top*FWD));
  float lift=mix(LIFT,.95,shortHair);
  lift=mix(lift,TOPLIFT,top);
  float scatter=clamp(4.0*topW*(1.0-topW),0.0,1.0);
  float spinA=(aSeed.x-.5)*6.2831*scatter*scatter*(3.0-2.0*scatter);
  // curly and coily hair has no combed direction: every strand turns its own way
  spinA+=(aSeed.x-.5)*6.2831*smoothstep(.0,.15,uStyleC.x);
  flow=normalize(flow*cos(spinA)+tA*sin(spinA));
  tA=normalize(cross(n,flow)+vec3(.0001));
  lift=mix(lift,.42,max(crown,scatter)*.7*(1.0-smoothstep(.0,.15,uStyleC.x)));
  vec3 dir=normalize(n*lift+flow*(1.0-lift*.75)+tA*(aSeed.z-.5)*SPREAD+flow*(aSeed.y-.5)*SPREAD*.6);
  float t=position.y;
  float sag=SAG*t*clamp(L/L0,0.0,1.6);
  vec3 curve=normalize(dir+flow*(.10*t)+down*sag);
  float wave=sin(t*6.2831*WAVEF+aSeed.x*6.2831)*WAVE*t;
  vec3 p=aRoot+n*.002+curve*(t*L)+tA*wave*L;
  // coils: a helix around the strand's path, opening up from the root
  vec3 b2=normalize(cross(curve,tA)+vec3(.0001));
  float coilR=uStyleC.x*L*(.75+.5*aSeed.z)*smoothstep(.0,.18,t);
  float ph=t*uStyleC.y*(.8+.4*aSeed.y)*6.2831+aSeed.x*6.2831;
  p+=(tA*cos(ph)+b2*sin(ph))*coilR;
  vec3 tang=normalize(curve*L+(-tA*sin(ph)+b2*cos(ph))*coilR*uStyleC.y*6.2831+vec3(.00001));
  vec3 view=normalize(cam-p),side=cross(tang,view);
  if(dot(side,side)<.00001)side=cross(tang,vec3(0.0,1.0,.001));side=normalize(side);
  float radius=.0062*uWidth*uStyleC.w*(.82+.36*aSeed.y)*mix(1.0,.28,pow(t,2.0));
  float facing=abs(dot(n,normalize(cam-aRoot)));
  radius*=mix(1.0,smoothstep(.04,.40,facing),shortHair);
  p+=side*position.x*radius;
  // greying starts at the temples and sides
  float templeW=smoothstep(1.1,1.6,abs(aRoot.x))*(1.0-smoothstep(2.9,3.5,aRoot.y));
  float gf=clamp(uGreyA.x*(1.0+uGreyA.y*(templeW-.35)),0.0,1.0);
  vGrey=step(fract(aSeed.z*7.31+aSeed.x*3.17),gf);
  vRoot=aRoot;vTip=p;vTangent=tang;vSeed=aSeed;vAlong=t;vEdge=position.x;vLength=L;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);
 }`;
  HSC.glsl.strandFrag = (t) => strandFrag(t, 'uHairTint', 'uGreyA.z');

  HSC.glsl.beardVert = (t) => t + `
 attribute vec3 aRoot,aNormal,aSeed,aBase;
 uniform vec3 cam;uniform float uWidth;
 uniform vec4 uBStyleA,uBStyleB,uBeardGrey;
 varying vec3 vRoot,vTip,vTangent,vSeed;varying float vAlong,vEdge,vLength,vGrey;
 void main(){
  vec3 n=normalize(aNormal);
  vec3 B=aBase;float ax=abs(B.x);
  float mm=beardMM(B)*smoothstep(.05,.35,beardZone(B));
  // patchy growth on the cheeks and neck for lighter beards
  float cheekW=smoothstep(.45,.9,atan(ax,B.z-.25))*(1.0-smoothstep(-.2,.2,B.y-.9*(1.0-smoothstep(.0,1.0,ax))));
  float ptch=smoothstep(uBeardGrey.z-.15,uBeardGrey.z+.15,n3(B*3.4+aSeed.z*.3)+(1.0-cheekW)*.35);
  float keep=mix(1.0,ptch,uBeardGrey.z>.01?1.0:0.0);
  float L=mm/42.0*(.82+.36*aSeed.x)*uBStyleB.z*keep;
  // growth direction: down the face; outward on the moustache; down the neck under the jaw
  vec3 down=vec3(0.0,-1.0,0.0);down-=n*dot(down,n);
  vec3 outw=vec3(sign(B.x),-.9,.0);outw-=n*dot(outw,n);
  float must=smoothstep(.15,.3,B.y)*(1.0-smoothstep(.5,.62,B.y))*(1.0-smoothstep(.55,.85,ax));
  vec3 flow=normalize(mix(down,outw,must*.55)+vec3(.0001));
  vec3 tA=normalize(cross(n,flow)+vec3(.0001));
  float spin=(aSeed.y-.5)*.9+(aSeed.x-.5)*6.2831*smoothstep(.0,.15,uBStyleB.x);
  flow=normalize(flow*cos(spin)+tA*sin(spin));
  tA=normalize(cross(n,flow)+vec3(.0001));
  // short stubble stands up; longer hair lies down and starts to hang
  float lift=mix(.85,uBStyleA.z,smoothstep(1.0,8.0,mm));
  vec3 dir=normalize(n*lift+flow*(1.0-lift*.7)+tA*(aSeed.z-.5)*.3);
  float t=position.y;
  vec3 curve=normalize(dir+vec3(0.0,-1.0,0.0)*uBStyleA.w*t*smoothstep(8.0,30.0,mm));
  float wave=sin(t*6.2831*uBStyleA.y*(1.0+mm/15.0)+aSeed.x*6.2831)*uBStyleA.x*t;
  vec3 p=aRoot+n*.002+curve*(t*L)+tA*wave*L;
  vec3 b2=normalize(cross(curve,tA)+vec3(.0001));
  float coilR=uBStyleB.x*L*(.7+.6*aSeed.z)*smoothstep(.0,.2,t);
  float ph=t*uBStyleB.y*(.8+.4*aSeed.y)*6.2831+aSeed.x*6.2831;
  p+=(tA*cos(ph)+b2*sin(ph))*coilR;
  vec3 tang=normalize(curve*L+(-tA*sin(ph)+b2*cos(ph))*coilR*uBStyleB.y*6.2831+vec3(.00001));
  vec3 view=normalize(cam-p),side=cross(tang,view);
  if(dot(side,side)<.00001)side=cross(tang,vec3(0.0,1.0,.001));side=normalize(side);
  float radius=.0058*uWidth*uBStyleB.w*(.82+.36*aSeed.y)*mix(1.0,.3,pow(t,2.0));
  float facing=abs(dot(n,normalize(cam-aRoot)));
  radius*=mix(1.0,smoothstep(.04,.4,facing),1.0-smoothstep(1.5,5.0,mm));
  p+=side*position.x*radius;
  // the chin greys first
  float chinW=1.0-smoothstep(.2,.6,ax);
  vGrey=step(fract(aSeed.z*7.31+aSeed.x*3.17),clamp(uBeardGrey.x*(1.0+.4*(chinW-.4)),0.0,1.0));
  vRoot=aRoot;vTip=p;vTangent=tang;vSeed=aSeed;vAlong=t;vEdge=position.x;vLength=L;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);
 }`;
  HSC.glsl.beardFrag = (t) => strandFrag(t, 'uHairTint*uBeardTint', 'uBeardGrey.y');
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// CPU-side face geometry: the beard grid (mirrors the shader's beardUV / beardZone exactly), the
// beard's per-cell surface positions, beard strand roots, and per-customer face-shape morphs.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const { clamp, smooth } = HSC;
  const { BC, AZR, EL0, ELR } = HSC.BEARD_PROJ;

  // beard length levels (mm); state.beard stores indices into this table
  const BEARD_MM = [0, 0.5, 1, 1.5, 2, 3, 4.5, 6, 8, 10, 13, 16, 20, 25, 30, 40, 50];
  const GUARD_MM = { 1: 3, 2: 6, 3: 10, 4: 13 };
  const levelOf = (mm) => {
    let best = 0;
    for (let i = 0; i < BEARD_MM.length; i++) if (Math.abs(BEARD_MM[i] - mm) < Math.abs(BEARD_MM[best] - mm)) best = i;
    return best;
  };
  const GUARD_LEVEL = Object.fromEntries(Object.entries(GUARD_MM).map(([g, mm]) => [g, levelOf(mm)]));

  function beardUV(x, y, z) {
    const dx = x - BC[0], dy = y - BC[1], dz = z - BC[2];
    const az = Math.atan2(dx, dz), el = Math.atan2(dy, Math.hypot(dx, dz));
    return [az / (2 * AZR) + 0.5, (el - EL0) / ELR];
  }
  function beardCell(x, y, z) {
    const [u, v] = beardUV(x, y, z);
    if (!(u >= 0 && u <= 1 && v >= 0 && v <= 1)) return -1;
    return Math.min(63, Math.floor(v * 64)) * 128 + Math.min(127, Math.floor(u * 128));
  }
  function lipMask(x, y, z) {
    const ax = Math.abs(x), ly = y - 0.125;
    const lipW = 1 - smooth(0.55, 0.72, ax);
    const upL = (1 - smooth(0.55, 0.95, Math.hypot(x / 0.66, (ly - 0.12) / 0.15))) * (ly >= 0 ? 1 : 0);
    const loL = (1 - smooth(0.55, 0.95, Math.hypot(x / 0.62, (ly + 0.13) / 0.21))) * (ly <= 0 ? 1 : 0);
    return Math.max(upL, loL) * smooth(1.8, 2.2, z) * lipW;
  }
  function beardZone(x, y, z) {
    const ax = Math.abs(x);
    const ang = Math.atan2(ax, z - 0.25);
    const yTop = 0.53 + (1.3 - 0.53) * smooth(0.3, 1.45, ang);
    const yBot = -1.22 + (-0.8 + 1.22) * smooth(0.85, 1.6, ang);
    let m = smooth(yBot - 0.04, yBot + 0.08, y) * (1 - smooth(yTop - 0.08, yTop + 0.03, y));
    m *= 1 - smooth(1.5, 1.64, ang);
    m *= 1 - smooth(0.15, 0.5, lipMask(x, y, z));
    return m;
  }

  // beard style regions, from the cell's (un-morphed) position
  function beardRegion(x, y, z, person) {
    const ax = Math.abs(x);
    const ang = Math.atan2(ax, z - 0.25);
    const cheekShift = 0.1 * (person.beard.cheekLine || 0);
    const neckShift = 0.1 * (person.beard.neckLine || 0);
    const jawY = -0.92 + 0.42 * smooth(0.5, 1.5, ang);
    if (y < -1.22 + 0.42 * smooth(0.85, 1.6, ang) + 0.12 + neckShift * (1 - smooth(0.6, 1.3, ang))) return null; // below the neckline
    const rag = 0.05 * Math.sin(x * 23.1 + y * 7.3) + 0.04 * Math.sin(z * 31.7 - x * 11.9);
    const yTop = 0.53 + 0.77 * smooth(0.3, 1.45, ang) + cheekShift * smooth(0.4, 1.2, ang) * (ang > 0.5 ? 1 : 0) + rag * smooth(0.4, 0.9, ang);
    if (y > yTop) return null;
    if (y > 0.26 && ax < 0.8 && ang < 0.65) return 'moustache';
    if (ax < 0.5 && y < 0.02 && z > 0.9 && y > jawY - 0.3) return 'chin';
    if (y < jawY - 0.12) return 'neck';
    if (Math.abs(y - jawY) < 0.2) return 'jaw';
    return 'cheeks';
  }

  // ---------------- geometry helpers ----------------
  function canonIds(P) {
    const ids = new Map(), canon = new Int32Array(P.length / 3);
    for (let v = 0; v < canon.length; v++) {
      const k = Math.round(P[v * 3] * 1e4) + ',' + Math.round(P[v * 3 + 1] * 1e4) + ',' + Math.round(P[v * 3 + 2] * 1e4);
      let c = ids.get(k);
      if (c === undefined) ids.set(k, (c = ids.size));
      canon[v] = c;
    }
    return { canon, count: ids.size };
  }
  function areaNormals(P, I, canon, count) {
    const acc = new Float32Array(count * 3);
    for (let k = 0; k < I.length; k += 3) {
      const a = I[k] * 3, b = I[k + 1] * 3, c = I[k + 2] * 3;
      const e1x = P[b] - P[a], e1y = P[b + 1] - P[a + 1], e1z = P[b + 2] - P[a + 2];
      const e2x = P[c] - P[a], e2y = P[c + 1] - P[a + 1], e2z = P[c + 2] - P[a + 2];
      const nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
      for (const v of [I[k], I[k + 1], I[k + 2]]) {
        const o = canon[v] * 3;
        acc[o] += nx; acc[o + 1] += ny; acc[o + 2] += nz;
      }
    }
    for (let o = 0; o < acc.length; o += 3) {
      const l = Math.hypot(acc[o], acc[o + 1], acc[o + 2]) || 1;
      acc[o] /= l; acc[o + 1] /= l; acc[o + 2] /= l;
    }
    return acc;
  }

  // ---------------- face-shape morphs ----------------
  const eyeC = [0.628, 1.624, 1.627];
  const G = (x, y, z, c, r) => {
    const a = (x - c[0]) / r[0], b = (y - c[1]) / r[1], d = (z - c[2]) / r[2];
    return Math.exp(-(a * a + b * b + d * d));
  };
  // displacement of a base-mesh point for a customer; zero on the scalp, around the eyeballs and on the neck
  function morphDelta(x, y, z, m, age, scalp) {
    const ax = Math.abs(x), sx = x < 0 ? -1 : 1;
    const guard =
      (1 - smooth(0.0, 0.03, scalp)) *
      smooth(0.37, 0.5, Math.hypot(ax - eyeC[0], y - eyeC[1], z - eyeC[2])) *
      smooth(-1.6, -1.2, y);
    if (guard <= 0) return null;
    let dx = 0, dy = 0, dz = 0, g;
    g = G(ax, y, z, [0, 0.7, 2.35], [0.42, 0.3, 0.36]); dx += x * 0.32 * m.noseW * g;
    g = G(ax, y, z, [0, 1.25, 2.4], [0.18, 0.38, 0.35]); dz += 0.08 * m.noseBridge * g;
    g = G(ax, y, z, [0, 0.82, 2.6], [0.2, 0.18, 0.25]); dz += 0.06 * m.noseTip * g; dy -= 0.025 * m.noseTip * g;
    g = G(ax, y, z, [0, 0.12, 2.2], [0.62, 0.25, 0.3]); dz += 0.05 * m.lips * g; dy += (y - 0.125) * 0.3 * m.lips * g;
    g = G(ax, y, z, [1.05, -0.35, 1.0], [0.55, 0.55, 0.8]); dx += x * 0.1 * m.jaw * g;
    g = G(ax, y, z, [0, -0.72, 1.95], [0.42, 0.32, 0.42]); dz += 0.09 * m.chin * g; dy -= 0.035 * m.chin * g;
    g = G(ax, y, z, [1.15, 1.15, 1.65], [0.38, 0.32, 0.42]); dx += sx * 0.065 * m.cheek * g; dz += 0.03 * m.cheek * g;
    g = G(ax, y, z, [0.6, 2.05, 2.05], [0.5, 0.13, 0.25]); dz += 0.045 * m.brow * g;
    // age: jowls and under-eye bags
    const a2 = age * age;
    g = G(ax, y, z, [0.95, -0.5, 1.55], [0.35, 0.28, 0.4]); dy -= 0.07 * a2 * g; dx += sx * 0.03 * a2 * g;
    g = G(ax, y, z, [0.62, 1.3, 1.98], [0.22, 0.07, 0.18]); dz += 0.025 * a2 * g;
    if (!dx && !dy && !dz) return null;
    return [dx * guard, dy * guard, dz * guard];
  }

  // ---------------- beard surface (built once on the un-morphed head) ----------------
  // Cells are a linear combination of mesh vertices, so after a morph each cell's position is
  // recomputed cheaply. Only the outermost surface counts: the mesh also has a closed mouth cavity.
  function buildBeardSurface(P, I) {
    const tris = [];
    for (let k = 0; k < I.length; k += 3) {
      const vs = [I[k], I[k + 1], I[k + 2]];
      if (vs.some((v) => beardZone(P[v * 3], P[v * 3 + 1], P[v * 3 + 2]) > 0.01)) tris.push(k);
    }
    const samples = [];
    const maxR = new Float32Array(8192);
    const radius = (x, y, z) => Math.hypot(x - BC[0], y - BC[1], z - BC[2]);
    for (const k of tris) {
      const a = I[k], b = I[k + 1], c = I[k + 2];
      const pa = [P[a * 3], P[a * 3 + 1], P[a * 3 + 2]], pb = [P[b * 3], P[b * 3 + 1], P[b * 3 + 2]], pc = [P[c * 3], P[c * 3 + 1], P[c * 3 + 2]];
      const edge = Math.max(Math.hypot(pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]), Math.hypot(pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]), Math.hypot(pc[0] - pb[0], pc[1] - pb[1], pc[2] - pb[2]));
      const n = Math.max(2, Math.min(12, Math.ceil(edge / 0.03)));
      for (let i = 0; i <= n; i++) for (let j = 0; j <= n - i; j++) {
        const wa = 1 - (i + j) / n, wb = i / n, wc = j / n;
        const x = pa[0] * wa + pb[0] * wb + pc[0] * wc, y = pa[1] * wa + pb[1] * wb + pc[1] * wc, z = pa[2] * wa + pb[2] * wb + pc[2] * wc;
        if (beardZone(x, y, z) < 0.02) continue;
        const cell = beardCell(x, y, z);
        if (cell < 0) continue;
        const r = radius(x, y, z);
        if (r > maxR[cell]) maxR[cell] = r;
        samples.push(cell, r, a, b, c, wa, wb, wc);
      }
    }
    // gather outermost samples per cell as vertex weights
    const lists = Array.from({ length: 8192 }, () => new Map());
    for (let s = 0; s < samples.length; s += 8) {
      const cell = samples[s];
      if (samples[s + 1] < maxR[cell] - 0.07) continue;
      const m = lists[cell];
      for (let q = 0; q < 3; q++) m.set(samples[s + 2 + q], (m.get(samples[s + 2 + q]) || 0) + samples[s + 5 + q]);
    }
    // index triangles by the grid cells they cover, so each gap-filling ray tests only a few
    const bins = new Map();
    for (const k of tris) {
      let u0 = 1e9, u1 = -1e9, v0 = 1e9, v1 = -1e9;
      for (let q = 0; q < 3; q++) {
        const v = I[k + q] * 3, [u, w] = beardUV(P[v], P[v + 1], P[v + 2]);
        u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, w); v1 = Math.max(v1, w);
      }
      if (u1 - u0 > 0.5) continue; // wraps around behind the projection centre: never part of the beard
      const cx0 = Math.max(0, Math.floor(u0 * 128) - 1), cx1 = Math.min(127, Math.floor(u1 * 128) + 1);
      const cy0 = Math.max(0, Math.floor(v0 * 64) - 1), cy1 = Math.min(63, Math.floor(v1 * 64) + 1);
      for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) {
        const c = cy * 128 + cx;
        let l = bins.get(c);
        if (!l) bins.set(c, (l = []));
        l.push(k);
      }
    }
    // cells too small to catch a sample: cast a ray from the projection centre, keep the farthest hit
    const filled = lists.map((m) => m.size > 0), tried = new Uint8Array(8192);
    for (let pass = 0, grew = true; grew && pass < 6; pass++) {
      grew = false;
      const next = filled.slice();
      for (let cell = 0; cell < 8192; cell++) {
        if (filled[cell] || tried[cell]) continue;
        const cx = cell & 127, cy = cell >> 7;
        let nb = false;
        for (let dy = -1; dy <= 1 && !nb; dy++) for (let dx = -1; dx <= 1; dx++) {
          const yy = cy + dy, xx = cx + dx;
          if (yy >= 0 && yy < 64 && xx >= 0 && xx < 128 && filled[yy * 128 + xx]) { nb = true; break; }
        }
        if (!nb) continue;
        tried[cell] = 1;
        const az = ((cx + 0.5) / 128 - 0.5) * 2 * AZR, el = (cy + 0.5) / 64 * ELR + EL0;
        const d = [Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el)];
        let best = -1, hit = null;
        for (const k of bins.get(cell) || []) {
          const a = I[k] * 3, b = I[k + 1] * 3, c = I[k + 2] * 3;
          const e1 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], e2 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
          const px = d[1] * e2[2] - d[2] * e2[1], py = d[2] * e2[0] - d[0] * e2[2], pz = d[0] * e2[1] - d[1] * e2[0];
          const det = e1[0] * px + e1[1] * py + e1[2] * pz;
          if (Math.abs(det) < 1e-9) continue;
          const iv = 1 / det, tx = BC[0] - P[a], ty = BC[1] - P[a + 1], tz = BC[2] - P[a + 2];
          const u = (tx * px + ty * py + tz * pz) * iv;
          if (u < 0 || u > 1) continue;
          const qx = ty * e1[2] - tz * e1[1], qy = tz * e1[0] - tx * e1[2], qz = tx * e1[1] - ty * e1[0];
          const v = (d[0] * qx + d[1] * qy + d[2] * qz) * iv;
          if (v < 0 || u + v > 1) continue;
          const t = (e2[0] * qx + e2[1] * qy + e2[2] * qz) * iv;
          if (t > best) { best = t; hit = [k, 1 - u - v, u, v]; }
        }
        if (!hit) continue;
        const [k, wa, wb, wc] = hit;
        const hx = BC[0] + d[0] * best, hy = BC[1] + d[1] * best, hz = BC[2] + d[2] * best;
        if (beardZone(hx, hy, hz) < 0.02) continue;
        const m = lists[cell];
        m.set(I[k], (m.get(I[k]) || 0) + wa); m.set(I[k + 1], (m.get(I[k + 1]) || 0) + wb); m.set(I[k + 2], (m.get(I[k + 2]) || 0) + wc);
        maxR[cell] = Math.max(maxR[cell], best);
        next[cell] = true;
        grew = true;
      }
      for (let c = 0; c < 8192; c++) filled[c] = next[c];
    }
    // flatten
    const offs = new Int32Array(8193), verts = [], wts = [];
    for (let c = 0; c < 8192; c++) {
      offs[c] = verts.length;
      let tot = 0;
      for (const w of lists[c].values()) tot += w;
      for (const [v, w] of lists[c]) { verts.push(v); wts.push(w / tot); }
    }
    offs[8192] = verts.length;
    return { tris, maxR, offs, verts: Int32Array.from(verts), wts: Float32Array.from(wts) };
  }

  // positions of all beard cells for the current (possibly morphed) vertex positions
  function beardCellPositions(S, P) {
    const pos = new Float32Array(8192 * 3), has = new Uint8Array(8192);
    for (let c = 0; c < 8192; c++) {
      if (S.offs[c] === S.offs[c + 1]) continue;
      has[c] = 1;
      for (let i = S.offs[c]; i < S.offs[c + 1]; i++) {
        const v = S.verts[i] * 3, w = S.wts[i];
        pos[c * 3] += P[v] * w; pos[c * 3 + 1] += P[v + 1] * w; pos[c * 3 + 2] += P[v + 2] * w;
      }
    }
    // spatial buckets for the clipper
    const size = 0.22, buckets = new Map();
    for (let c = 0; c < 8192; c++) {
      if (!has[c]) continue;
      const k = Math.floor(pos[c * 3] / size) + ',' + Math.floor(pos[c * 3 + 1] / size) + ',' + Math.floor(pos[c * 3 + 2] / size);
      let l = buckets.get(k);
      if (!l) buckets.set(k, (l = []));
      l.push(c);
    }
    return { positions: pos, has, spatial: { size, buckets } };
  }

  // beard strand roots: fixed (triangle, barycentric) picks on the outer beard area
  function sampleBeardRoots(P, I, S, count, seed) {
    const R = HSC.rng(seed);
    const areas = [];
    let total = 0;
    for (const k of S.tris) {
      const a = I[k] * 3, b = I[k + 1] * 3, c = I[k + 2] * 3;
      const e1 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], e2 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
      total += 0.5 * Math.hypot(e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]);
      areas.push(total);
    }
    const tri = new Int32Array(count * 3), bary = new Float32Array(count * 3), base = new Float32Array(count * 3);
    let made = 0, guard = 0;
    while (made < count && guard++ < count * 40) {
      const x = R.next() * total;
      let lo = 0, hi = areas.length - 1;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (areas[mid] < x) lo = mid + 1; else hi = mid; }
      const k = S.tris[lo];
      const r1 = Math.sqrt(R.next()), r2 = R.next();
      const w = [1 - r1, r1 * (1 - r2), r1 * r2];
      const vs = [I[k], I[k + 1], I[k + 2]];
      const p = [0, 1, 2].map((q) => vs.reduce((s, v, j) => s + P[v * 3 + q] * w[j], 0));
      if (beardZone(...p) < 0.06) continue;
      const cell = beardCell(...p);
      if (cell < 0 || Math.hypot(p[0] - BC[0], p[1] - BC[1], p[2] - BC[2]) < S.maxR[cell] - 0.07) continue;
      tri.set(vs, made * 3); bary.set(w, made * 3); base.set(p, made * 3);
      made++;
    }
    return { count: made, tri, bary, base };
  }

  // the starting beard (length levels per cell) for a customer
  function beardStart(person, S, P) {
    const out = new Array(8192).fill(0);
    if (!S || !person) return out;
    const mm = person.beard.mm || {};
    const style = HSC.BEARD_STYLES[person.beard.style] || {};
    if (!Object.keys(mm).length) return out;
    const cells = beardCellPositions(S, P).positions;
    const raw = new Float32Array(8192);
    for (let c = 0; c < 8192; c++) {
      if (S.offs[c] === S.offs[c + 1]) continue;
      const x = cells[c * 3], y = cells[c * 3 + 1], z = cells[c * 3 + 2];
      if (beardZone(x, y, z) < 0.05) continue;
      let region = beardRegion(x, y, z, person);
      if (!region) continue;
      // a van dyke keeps the chin tuft separate from the moustache
      if (style.chinOnly && region === 'chin' && Math.abs(x) > 0.36) continue;
      // jaw/chin-only styles let a chin region borrow the jaw length and vice versa
      let v = mm[region];
      if (v == null && region === 'jaw' && mm.cheeks) v = mm.cheeks;
      if (v == null && region === 'neck' && person.beard.style === 'chinstrap') v = null;
      if (v == null) continue;
      raw[c] = v;
    }
    // soften length steps between regions (not the outer edges)
    for (let it = 0; it < 2; it++) {
      const src = raw.slice();
      for (let c = 0; c < 8192; c++) {
        if (!src[c]) continue;
        const cx = c & 127, cy = c >> 7;
        let s = 0, n = 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const yy = cy + dy, xx = cx + dx;
          if (yy < 0 || yy > 63 || xx < 0 || xx > 127) continue;
          const v = src[yy * 128 + xx];
          if (v) { s += v; n++; }
        }
        raw[c] = s / n;
      }
    }
    for (let c = 0; c < 8192; c++) if (raw[c] > 0) out[c] = Math.max(1, levelOf(raw[c]));
    return out;
  }

  Object.assign(HSC, {
    BEARD_MM, GUARD_LEVEL, beardUV, beardCell, beardZone, lipMask, beardRegion, canonIds, areaNormals, morphDelta,
    buildBeardSurface, beardCellPositions, sampleBeardRoots, beardStart,
  });
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Renderer glue: attaches to the game's head mesh and materials, then applies a customer.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const { clamp, smooth } = HSC;

  // the game's hair colour presets (uHairTint per colour index)
  const TINTS = [
    [0.3, 0.32, 0.38], [0.48, 0.48, 0.52], [0.72, 0.68, 0.64], [1, 1, 1], [1.55, 1.36, 1.16], [2.3, 1.95, 1.55],
    [3.1, 2.65, 1.95], [4, 3.35, 2.05], [5.1, 4.45, 3.1], [2.4, 1.25, 0.8], [4, 1.8, 0.75], [2.1, 3.15, 5.2],
  ];
  const STRAND_STYLE = {
    straight: (c) => ({ A: [0.22, 0.56, 0.56, 0.5], B: [0.16, 0.1, 0.02, 1], C: [0, 0, 1, 1] }),
    wavy: (c) => ({ A: [0.18, 0.4, 0.62, 0.6], B: [0.2, 0.08, 0.07 + 0.05 * c, 1.4 + 0.6 * c], C: [0, 0, 0.92, 1.05] }),
    curly: (c) => ({ A: [0.1, 0.2, 0.75, 0.8], B: [0.28, 0.04, 0, 1], C: [0.1 + 0.06 * c, 1.6 + 1.0 * c, 0.72 - 0.1 * c, 1.15] }),
    coily: (c) => ({ A: [0.03, 0.05, 0.9, 0.95], B: [0.36, 0, 0, 1], C: [0.16 + 0.08 * c, 3 + 2.5 * c, 0.5 - 0.08 * c, 1.35] }),
  };
  const BEARD_STYLE = {
    straight: { A: [0.04, 0.6, 0.45, 0.12], B: [0, 0, 1, 1] },
    wavy: { A: [0.07, 0.9, 0.5, 0.1], B: [0.03, 1.2, 0.95, 1.05] },
    curly: { A: [0, 1, 0.6, 0.05], B: [0.12, 1.8, 0.75, 1.1] },
    coily: { A: [0, 1, 0.75, 0.02], B: [0.2, 3.5, 0.55, 1.25] },
  };
  const lerp = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  const mul = (a, b) => a.map((v, i) => v * b[i]);

  let ctx = null;
  const st = {};

  HSC.attach = function (c) {
    try {
      ctx = c;
      const T = c.T, Pt = c.Pt;
      const P = Pt.attributes.position.array;
      st.base = Float32Array.from(P);
      st.N0 = Float32Array.from(Pt.attributes.normal.array);
      st.coarse = Pt.userData.coarse;
      st.coarseBase = Float32Array.from(st.coarse.pos);
      Pt.setAttribute('hsBase', new T.It(st.base, 3));
      const ci = HSC.canonIds(st.base);
      st.canon = ci.canon; st.canonCount = ci.count;
      st.nBase = HSC.areaNormals(st.base, Pt.index.array, st.canon, st.canonCount);
      // scalp mask per vertex, to keep morphs off the scalp
      st.scalp = new Float32Array(P.length / 3);
      for (let v = 0; v < st.scalp.length; v++) st.scalp[v] = c.Na(P[v * 3], P[v * 3 + 1], P[v * 3 + 2]);
      st.scalpC = new Float32Array(st.coarseBase.length / 3);
      for (let v = 0; v < st.scalpC.length; v++) st.scalpC[v] = c.Na(st.coarseBase[v * 3], st.coarseBase[v * 3 + 1], st.coarseBase[v * 3 + 2]);

      // beard length grid texture
      st.beardData = new Uint8Array(8192);
      const tex = new T.uu(st.beardData, 128, 64, T.Jn, T.cr);
      tex.minFilter = tex.magFilter = T.or;
      tex.needsUpdate = true;
      st.beardTex = tex;
      HSC.U.uBeard.value = tex;

      // beard surface + strands
      st.surface = HSC.buildBeardSurface(st.base, Pt.index.array);
      st.roots = HSC.sampleBeardRoots(st.base, Pt.index.array, st.surface, 14000, 0xbea7d);
      st.beardCells = HSC.beardCellPositions(st.surface, st.base);
      HSC.beardSurface = st.beardCells;
      st.beardMesh = makeBeardMesh(c, st.roots);
      c.vt.add(st.beardMesh);
      HSC.ready = true;
    } catch (err) {
      console.error('customers: attach failed', err);
      HSC.ready = false;
    }
  };

  function makeBeardMesh(c, roots) {
    const T = c.T, n = roots.count;
    const g = new T.af();
    const pos = [], idx = [];
    const SEG = 8;
    for (let s = 0; s <= SEG; s++) {
      pos.push(-1, s / SEG, 0, 1, s / SEG, 0);
      if (s < SEG) { const u = s * 2; idx.push(u, u + 1, u + 2, u + 1, u + 3, u + 2); }
    }
    g.setAttribute('position', new T.mt(pos, 3));
    g.setIndex(idx);
    st.aRoot = new Float32Array(n * 3);
    st.aNormal = new Float32Array(n * 3);
    const seeds = new Float32Array(n * 3), R = HSC.rng(911);
    for (let i = 0; i < n * 3; i++) seeds[i] = R.next();
    g.setAttribute('aRoot', new T.Ra(st.aRoot, 3));
    g.setAttribute('aNormal', new T.Ra(st.aNormal, 3));
    g.setAttribute('aBase', new T.Ra(roots.base.subarray(0, n * 3), 3));
    g.setAttribute('aSeed', new T.Ra(seeds, 3));
    g.instanceCount = n;
    updateRoots(st.base, st.N0);
    const mat = new T.fr({
      vertexShader: HSC.glsl.beardVert(c.Ql),
      fragmentShader: HSC.glsl.beardFrag(c.Ql),
      uniforms: Object.assign({ uGrid: c.uGrid, uHairTint: c.uHairTint, uDensity: c.uDensity, uWidth: { value: 1 } }, c.light, HSC.U),
      side: T.$t,
    });
    const mesh = new T.Ze(g, mat);
    mesh.frustumCulled = false;
    mesh.renderOrder = 1;
    mesh.visible = false;
    return mesh;
  }

  function updateRoots(P, N) {
    const r = st.roots;
    for (let i = 0; i < r.count; i++) {
      let nx = 0, ny = 0, nz = 0, x = 0, y = 0, z = 0;
      for (let j = 0; j < 3; j++) {
        const v = r.tri[i * 3 + j] * 3, w = r.bary[i * 3 + j];
        x += P[v] * w; y += P[v + 1] * w; z += P[v + 2] * w;
        nx += N[v] * w; ny += N[v + 1] * w; nz += N[v + 2] * w;
      }
      const l = Math.hypot(nx, ny, nz) || 1;
      st.aRoot.set([x, y, z], i * 3);
      st.aNormal.set([nx / l, ny / l, nz / l], i * 3);
    }
    if (st.beardMesh) {
      st.beardMesh.geometry.attributes.aRoot.needsUpdate = true;
      st.beardMesh.geometry.attributes.aNormal.needsUpdate = true;
    }
  }

  // ---- face-shape morph applied to the smooth mesh and the coarse picking mesh ----
  function applyMorph(person) {
    const Pt = ctx.Pt;
    const P = Pt.attributes.position.array, N = Pt.attributes.normal.array, I = Pt.index.array;
    const age = clamp((person.years - 18) / 62, 0, 1);
    const m = person.morph;
    let moved = false;
    for (let v = 0; v < P.length / 3; v++) {
      const x = st.base[v * 3], y = st.base[v * 3 + 1], z = st.base[v * 3 + 2];
      const d = HSC.morphDelta(x, y, z, m, age, st.scalp[v]);
      P[v * 3] = x + (d ? d[0] : 0); P[v * 3 + 1] = y + (d ? d[1] : 0); P[v * 3 + 2] = z + (d ? d[2] : 0);
      if (d) moved = true;
    }
    const C = st.coarse.pos;
    for (let v = 0; v < C.length / 3; v++) {
      const x = st.coarseBase[v * 3], y = st.coarseBase[v * 3 + 1], z = st.coarseBase[v * 3 + 2];
      const d = HSC.morphDelta(x, y, z, m, age, st.scalpC[v]);
      C[v * 3] = x + (d ? d[0] : 0); C[v * 3 + 1] = y + (d ? d[1] : 0); C[v * 3 + 2] = z + (d ? d[2] : 0);
    }
    // normals: the original (artist) normals plus the change the morph makes to the geometric normals
    if (moved) {
      const nm = HSC.areaNormals(P, I, st.canon, st.canonCount);
      for (let v = 0; v < N.length / 3; v++) {
        const c = st.canon[v] * 3;
        const x = st.N0[v * 3] + nm[c] - st.nBase[c], y = st.N0[v * 3 + 1] + nm[c + 1] - st.nBase[c + 1], z = st.N0[v * 3 + 2] + nm[c + 2] - st.nBase[c + 2];
        const l = Math.hypot(x, y, z) || 1;
        N[v * 3] = x / l; N[v * 3 + 1] = y / l; N[v * 3 + 2] = z / l;
      }
    } else N.set(st.N0);
    Pt.attributes.position.needsUpdate = true;
    Pt.attributes.normal.needsUpdate = true;
    Pt.computeBoundingSphere();
    updateRoots(P, N);
    st.beardCells = HSC.beardCellPositions(st.surface, P);
    HSC.beardSurface = st.beardCells;
  }

  // ---- iris texture ----
  function drawEyes(person) {
    const cv = ctx.eyeCanvas, tex = ctx.eyeTexture;
    if (!cv || !tex) return;
    const e = cv.getContext('2d');
    const R = HSC.rng(person.seed ^ 0x51ed);
    const stops = HSC.EYES[person.eyes] || HSC.EYES.blue;
    const old = person.years >= 60;
    e.setTransform(1, 0, 0, 1, 0, 0);
    e.scale(0.5, 0.5);
    e.fillStyle = old ? '#ebe1d0' : '#efe7e0';
    e.fillRect(0, 0, 2048, 1024);
    for (let o = 0; o < 70 + (old ? 40 : 0); o++) {
      const s = (R.next() < 0.5 ? 0.05 + R.next() * 0.12 : 0.38 + R.next() * 0.12) * 2048, l = (0.25 + R.next() * 0.5) * 1024;
      e.strokeStyle = `rgba(190,90,85,${0.05 + R.next() * 0.12})`;
      e.lineWidth = 1.5;
      e.beginPath(); e.moveTo(s, l);
      e.bezierCurveTo(s + 30, l + 20 * (R.next() - 0.5), s + 60, l + 40 * (R.next() - 0.5), s + 90 * (R.next() < 0.5 ? 1 : -1), l + 30 * (R.next() - 0.5));
      e.stroke();
    }
    const i = 150;
    e.save();
    e.translate(512, 512);
    e.scale(1, 300 / i);
    e.fillStyle = 'rgba(40,30,28,.28)';
    e.beginPath(); e.arc(0, 0, i * 1.08, 0, 7); e.fill();
    const gr = e.createRadialGradient(0, 0, 10, 0, 0, i);
    gr.addColorStop(0, '#060606'); gr.addColorStop(0.2, '#060606');
    gr.addColorStop(0.24, stops[0]); gr.addColorStop(0.5, stops[1]); gr.addColorStop(0.78, stops[2]); gr.addColorStop(0.93, stops[3]);
    gr.addColorStop(1, '#0b0b0b');
    e.fillStyle = gr;
    e.beginPath(); e.arc(0, 0, i, 0, 7); e.fill();
    const fib = stops[0].match(/\w\w/g).map((h) => parseInt(h, 16));
    for (let o = 0; o < 160; o++) {
      const s = R.next() * 6.283, l = i * (0.32 + R.next() * 0.1), cc = i * (0.62 + R.next() * 0.33);
      const k = 0.9 + R.next() * 0.35;
      e.strokeStyle = `rgba(${Math.min(255, fib[0] * k) | 0},${Math.min(255, fib[1] * k) | 0},${Math.min(255, fib[2] * k) | 0},${0.1 + R.next() * 0.22})`;
      e.lineWidth = 1.6;
      e.beginPath(); e.moveTo(Math.cos(s) * l, Math.sin(s) * l); e.lineTo(Math.cos(s) * cc, Math.sin(s) * cc); e.stroke();
    }
    if (old) {
      // arcus: a pale ring at the edge of the iris
      e.strokeStyle = 'rgba(215,215,205,.4)';
      e.lineWidth = 9;
      e.beginPath(); e.arc(0, 0, i * 0.95, 0, 7); e.stroke();
    }
    e.restore();
    tex.needsUpdate = true;
  }

  // ---- apply a customer ----
  HSC.setPerson = function (person) {
    if (!ctx || !HSC.validPerson(person)) return;
    const key = JSON.stringify(person);
    if (st.key === key) return;
    st.key = key;
    const U = HSC.U;
    const age = clamp((person.years - 18) / 62, 0, 1);
    const dark = clamp(person.skin.tone / 9.4, 0, 1);
    const skin = HSC.skinColour(person);
    U.uSkinA.value = [...skin, dark];
    U.uLip.value = lerp([1.06, 0.78, 0.93], [0.86, 0.7, 0.8], smooth(0.2, 0.8, dark));
    const tint = TINTS[person.hair.colour] || TINTS[1];
    const greyCol = [0.2, 0.2, 0.19];
    const hairDark = lerp(mul([0.035, 0.024, 0.018], tint), greyCol, person.hair.grey * 0.85);
    U.uHairDark.value = hairDark;
    // beards often grow in warmer than the scalp hair, visibly so only on brown, blond and red hair
    const warmable = person.hair.colour >= 3 && person.hair.colour <= 10 ? 1 : 0;
    const beardTint = lerp([1, 1, 1], [1.28, 0.95, 0.78], person.beard.warm * 0.55 * warmable);
    U.uBeardTint.value = beardTint;
    U.uBeardDark.value = lerp(mul(mul([0.035, 0.024, 0.018], tint), beardTint), greyCol, person.beard.grey * 0.85);
    U.uBrowTint.value = lerp(mul([0.085, 0.055, 0.04], tint), [0.36, 0.35, 0.33], person.brow.grey);
    U.uBrowA.value = [person.brow.thick, clamp(0.9 + 0.15 * age, 0, 1.2), 0, 0];
    // how strongly shaved follicles show through: dark hair on light skin shows most, grey hair least
    const hairLum = 0.2126 * hairDark[0] + 0.7152 * hairDark[1] + 0.0722 * hairDark[2];
    const castStrength = (0.2 + 0.8 * (1 - smooth(0.02, 0.14, hairLum))) * (1 - 0.45 * dark) * (1 - 0.55 * person.hair.grey);
    U.uCast.value = [...lerp([0.7, 0.73, 0.8], [0.8, 0.79, 0.8], dark), clamp(castStrength, 0.1, 1)];
    U.uAgeA.value = [age, smooth(0.5, 1, age) * (1 - 0.6 * dark), 1, age * 0.6];
    // hair texture
    const ss = STRAND_STYLE[person.hair.texture](person.hair.curl);
    U.uStyleA.value = ss.A; U.uStyleB.value = ss.B; U.uStyleC.value = ss.C;
    const bs = BEARD_STYLE[person.hair.texture];
    U.uBStyleA.value = bs.A; U.uBStyleB.value = bs.B;
    U.uGreyA.value = [person.hair.grey, 0.6, 0.6 + 0.1 * age, 0];
    U.uBeardGrey.value = [person.beard.grey, 0.66, person.beard.patchy, 0];
    // baldness
    const nw = HSC.NORWOOD_SHAPE[person.bald.norwood] || HSC.NORWOOD_SHAPE[1];
    const k = 0.85 + 0.3 * person.bald.edge;
    U.uBaldA.value = [nw[0] * k, nw[1] * k, nw[2] * k, nw[3]];
    U.uBaldB.value = [nw[4], person.bald.diffuse, (person.seed % 97) * 0.37, 0];
    // skin sheen follows the skin tone
    if (ctx.Gi && ctx.Gi.sheenColor) {
      const sc = lerp([1, 0.27, 0.19], [0.42, 0.28, 0.22], dark);
      ctx.Gi.sheenColor.setRGB(sc[0], sc[1], sc[2]);
      ctx.Gi.sheen = 0.6 - 0.2 * dark;
    }
    try { applyMorph(person); } catch (err) { console.error('customers: morph failed', err); }
    try { drawEyes(person); } catch (err) { console.error('customers: eyes failed', err); }
  };

  HSC.setBeard = function (levels) {
    if (!st.beardTex) return;
    let any = false;
    for (let c = 0; c < 8192; c++) {
      const v = levels && levels[c] ? HSC.BEARD_MM[levels[c]] || 0 : 0;
      st.beardData[c] = Math.round((v / 50) * 255);
      if (v >= 0.5) any = true;
    }
    st.beardTex.needsUpdate = true;
    if (st.beardMesh) st.beardMesh.visible = any;
  };

  // clipper picking: is this (morphed) hit on the beard? returns grid coords like the scalp's u/v
  HSC.beardHit = function (x, y, z, triStart, fine) {
    if (!ctx || !st.surface) return null;
    let bx = x, by = y, bz = z;
    if (fine) {
      // map the hit back onto the un-morphed head through the hit triangle's barycentrics
      const P = ctx.Pt.attributes.position.array, I = ctx.Pt.index.array;
      const a = I[triStart] * 3, b = I[triStart + 1] * 3, c = I[triStart + 2] * 3;
      const v0 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], v1 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]], v2 = [x - P[a], y - P[a + 1], z - P[a + 2]];
      const d00 = v0[0] * v0[0] + v0[1] * v0[1] + v0[2] * v0[2], d01 = v0[0] * v1[0] + v0[1] * v1[1] + v0[2] * v1[2], d11 = v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2];
      const d20 = v2[0] * v0[0] + v2[1] * v0[1] + v2[2] * v0[2], d21 = v2[0] * v1[0] + v2[1] * v1[1] + v2[2] * v1[2];
      const den = d00 * d11 - d01 * d01 || 1;
      const wb = (d11 * d20 - d01 * d21) / den, wc = (d00 * d21 - d01 * d20) / den, wa = 1 - wb - wc;
      const B = st.base;
      bx = B[a] * wa + B[b] * wb + B[c] * wc; by = B[a + 1] * wa + B[b + 1] * wb + B[c + 1] * wc; bz = B[a + 2] * wa + B[b + 2] * wb + B[c + 2] * wc;
    }
    if (HSC.beardZone(bx, by, bz) < 0.2) return null;
    const cell = HSC.beardCell(bx, by, bz);
    if (cell < 0 || !st.beardCells.has[cell]) return null;
    const [u, v] = HSC.beardUV(bx, by, bz);
    return { kind: 'beard', u, v };
  };

  // follow the game's automatic detail level (it lowers scalp strand counts when frames run slow)
  HSC.setDetail = function (f) {
    if (!st.beardMesh || !st.roots) return;
    const k = Math.max(0.55, Math.min(1, f));
    const n = Math.max(1, Math.round(st.roots.count * k));
    st.beardMesh.geometry.instanceCount = n;
    st.beardMesh.material.uniforms.uWidth.value = Math.sqrt(st.roots.count / n);
  };

  HSC.beardStartFor = (person) => (st.surface ? HSC.beardStart(person, st.surface, st.base) : new Array(8192).fill(0));
  HSC.debugState = st;
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Game-state side: the customer record and beard grid live in the saved session.
//   state.look.person    the customer (see people.js)
//   state.beard          beard length level per grid cell (index into BEARD_MM)
//   state.startBeard     the beard the customer walked in with
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const LEVELS = () => HSC.BEARD_MM.length;
  const checked = new WeakSet();
  const okBeard = (a) => {
    if (checked.has(a)) return true;
    const ok = Array.isArray(a) && a.length === 8192 && a.every((v) => Number.isInteger(v) && v >= 0 && v < LEVELS());
    if (ok) checked.add(a);
    return ok;
  };

  // make sure the session has a customer and beard for the current job (deterministic per job)
  HSC.ensure = function (s) {
    if (!s || !s.look) return s;
    let person = s.look.person;
    const fresh = !HSC.debugOverride && (!HSC.validPerson(person) || person.job !== s.jobId);
    if (fresh) {
      const seed = ((s.seed >>> 0) ^ Math.imul((s.jobId | 0) + 1, 0x9e3779b1)) >>> 0;
      person = Object.assign(HSC.makePerson(seed || 1), { job: s.jobId });
    }
    // test hook: show a specific customer (never set by the game)
    let forced = false;
    if (HSC.debugOverride) {
      forced = s.look.person !== HSC.debugOverride;
      person = HSC.debugOverride;
    }
    let beard = s.beard, startBeard = s.startBeard;
    if (fresh || forced || !okBeard(beard) || !okBeard(startBeard) || beard.some((v, i) => v > startBeard[i])) {
      startBeard = HSC.beardStartFor(person);
      beard = startBeard.slice();
      checked.add(startBeard);
      checked.add(beard);
    }
    if (!fresh && !forced && beard === s.beard && startBeard === s.startBeard && s.look.colour === person.hair.colour) return s;
    return Object.assign({}, s, { look: Object.assign({}, s.look, { person, colour: person.hair.colour }), beard, startBeard });
  };

  // a clipper stroke on the beard: every cell under the blade is cut down to the guard length
  HSC.cutBeard = function (s, points, surface) {
    const none = { state: s, changed: false, changedCells: 0, removedLength: 0, intensity: 0 };
    if (!s || s.status !== 'cutting' || s.interactionMode !== 'cut' || !surface || !Array.isArray(points) || !points.length) return none;
    const guard = HSC.GUARD_LEVEL[s.selectedGuard];
    if (guard == null || !okBeard(s.beard)) return none;
    const BLADE_W = 0.56, BLADE_D = 0.1;
    // walk from the previous blade position to the current one in small steps
    const steps = [];
    const valid = points.filter((p) => p && Array.isArray(p.position) && Array.isArray(p.normal));
    for (let i = 0; i < valid.length; i++) {
      const b = valid[i], a = i ? valid[i - 1] : null;
      if (!a) { steps.push(b); continue; }
      const d = Math.hypot(b.position[0] - a.position[0], b.position[1] - a.position[1], b.position[2] - a.position[2]);
      const n = Math.max(1, Math.min(40, Math.ceil(d / 0.03)));
      for (let k = 1; k <= n; k++) {
        const t = k / n, lerp = (u, v) => u.map((x, j) => x + (v[j] - x) * t);
        steps.push({ position: lerp(a.position, b.position), normal: lerp(a.normal, b.normal), bladeAcross: lerp(a.bladeAcross || [1, 0, 0], b.bladeAcross || [1, 0, 0]), bladeAlong: lerp(a.bladeAlong || [0, 1, 0], b.bladeAlong || [0, 1, 0]) });
      }
    }
    const next = s.beard.slice();
    const changed = new Set();
    let removed = 0;
    const { positions: pos, spatial } = surface;
    const reach = Math.hypot(BLADE_W / 2, BLADE_D / 2, 0.1);
    const unit = (v) => { const l = Math.hypot(...v) || 1; return v.map((x) => x / l); };
    for (const p of steps) {
      const g = p.position, across = unit(p.bladeAcross), along = unit(p.bladeAlong), nrm = unit(p.normal);
      const lo = g.map((x) => Math.floor((x - reach) / spatial.size)), hi = g.map((x) => Math.floor((x + reach) / spatial.size));
      for (let i = lo[0]; i <= hi[0]; i++) for (let j = lo[1]; j <= hi[1]; j++) for (let k = lo[2]; k <= hi[2]; k++) {
        const list = spatial.buckets.get(i + ',' + j + ',' + k);
        if (!list) continue;
        for (const c of list) {
          const d = [pos[c * 3] - g[0], pos[c * 3 + 1] - g[1], pos[c * 3 + 2] - g[2]];
          const dot = (v) => d[0] * v[0] + d[1] * v[1] + d[2] * v[2];
          if (Math.abs(dot(across)) > BLADE_W / 2 || Math.abs(dot(along)) > BLADE_D / 2 || Math.abs(dot(nrm)) > 0.1) continue;
          if (next[c] > guard) {
            removed += HSC.BEARD_MM[next[c]] - HSC.BEARD_MM[guard];
            next[c] = guard;
            changed.add(c);
          }
        }
      }
    }
    if (!changed.size) return none;
    checked.add(next);
    return {
      state: Object.assign({}, s, { beard: next, cutStrokeCount: s.cutStrokeCount + 1 }),
      changed: true,
      changedCells: changed.size,
      removedLength: removed,
      intensity: Math.min(1, removed / Math.max(1, changed.size * 16)),
    };
  };
})(globalThis.HSC || (globalThis.HSC = {}));


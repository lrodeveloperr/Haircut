/* Haircut Studio customers: generated people, skin, hair textures, baldness, trimmable beards, face shapes. */
// ---------------------------------------------------------------------------------------------
// Detail level: "high" for capable devices, "low" for weaker phones (fewer and simpler hair strands,
// fewer falling clippings, 1x resolution, no MSAA, cheaper skin shading).
// Setting: "auto" (default: detected from the device, and dropped to low mid-game if frames stay slow
// even after the game's own adaptive quality), or forced "low" / "high". Saved via platform storage.
// For testing, ?detail=low or ?detail=high in the page URL forces a level.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const KEY = 'skin-fade-studio-detail-v1';
  const PROFILES = {
    high: { maxStrands: 30000, minStrands: 16000, segments: 8, beardSegments: 8, beardMax: 1, clipMax: 4000, clipRate: 1, pixelMax: 2, pixelMin: 1.1, antialias: true, shaderLow: false },
    low: { maxStrands: 14000, minStrands: 9000, segments: 5, beardSegments: 4, beardMax: 0.45, clipMax: 1200, clipRate: 0.5, pixelMax: 1, pixelMin: 0.85, antialias: false, shaderLow: true },
  };
  const D = (HSC.detail = Object.assign({ setting: 'auto', level: 'high', detected: null, why: [] }, PROFILES.high));
  D.pixelRatio = () => Math.max(D.pixelMin, Math.min(D.pixelMax, globalThis.devicePixelRatio || 1));

  function forcedByUrl() {
    try {
      const q = new URLSearchParams(globalThis.location.search).get('detail');
      return q === 'low' || q === 'high' ? q : null;
    } catch (e) { return null; }
  }
  function detect() {
    const why = [];
    const mem = globalThis.navigator && navigator.deviceMemory;
    if (mem && mem <= 3) why.push('memory ' + mem + 'GB');
    const cores = globalThis.navigator && navigator.hardwareConcurrency;
    if (cores && cores <= 4) why.push(cores + ' cores');
    let gpu = '';
    try {
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl');
      if (gl) {
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        gpu = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
        if (gl.getParameter(gl.MAX_TEXTURE_SIZE) < 4096) why.push('small textures');
        const lose = gl.getExtension('WEBGL_lose_context');
        if (lose) lose.loseContext();
      }
    } catch (e) {}
    if (/Mali-(4|T\d)|Mali-G(31|51|52|57|68)\b|Adreno \(TM\) (3\d\d|4\d\d|50\d|51\d|52\d|60\d|61\d)|PowerVR|SGX|Vivante|SwiftShader|llvmpipe/i.test(gpu)) why.push('gpu ' + gpu);
    return { level: why.length ? 'low' : 'high', why, gpu };
  }

  function apply(level) {
    Object.assign(D, PROFILES[level]);
    D.level = level;
    try { HSC.onDetailChange && HSC.onDetailChange(); } catch (e) { console.error('customers: detail change failed', e); }
  }
  const effective = () => forcedByUrl() || (D.setting === 'auto' ? D.detected : D.setting);

  // decided synchronously when the script loads, so the game is built at the right level
  const d = detect();
  D.detected = d.level;
  D.why = d.why;
  D.gpu = d.gpu;
  apply(effective());

  // the saved setting arrives before the renderer is created
  HSC.initDetail = async function (client) {
    D.client = client;
    try {
      const s = client && client.loadProgress ? await client.loadProgress(KEY, 'auto') : 'auto';
      if (s === 'auto' || s === 'low' || s === 'high') D.setting = s;
    } catch (e) {}
    if (effective() !== D.level) apply(effective());
  };
  HSC.setDetailSetting = function (s) {
    if (s !== 'auto' && s !== 'low' && s !== 'high') return;
    D.setting = s;
    try { D.client && D.client.saveProgress && D.client.saveProgress(KEY, s).catch(() => {}); } catch (e) {}
    if (effective() !== D.level) {
      apply(effective());
      HSC.detailBudget && HSC.detailBudget();
    }
  };

  // auto: if frames stay slow at the game's lowest adaptive quality, switch to low for good
  let slow = 0;
  HSC.detailWatch = function (frameMs, strands, pixel) {
    if (D.setting !== 'auto' || D.level === 'low' || forcedByUrl()) return;
    const atFloor = strands <= D.minStrands + 1 && pixel <= D.pixelMin + 0.06;
    slow = frameMs > 30 && atFloor ? slow + 1 : 0;
    if (slow >= 3) {
      slow = 0;
      D.detected = 'low';
      apply('low');
      HSC.detailBudget && HSC.detailBudget();
    }
  };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Customer generator. Every customer is a plain, serialisable record derived deterministically from
// a seed, so a saved session always brings back the same person.
//
// Heritage groups only steer *correlated* traits (skin tone range, hair texture, natural hair colour,
// eye colour, beard density, how common pattern baldness is, and small average face-shape tendencies).
// Individual variation is always larger than the group tendency, and face-shape offsets are kept
// subtle so nobody is drawn as a caricature. Group ids are internal and never shown to the player.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';

  const PERSON_VERSION = 1;

  // small deterministic PRNG (mulberry32)
  function rng(seed) {
    // scramble the seed first (murmur3 finaliser) so nearby seeds give unrelated people
    let a = seed >>> 0;
    a = Math.imul(a ^ (a >>> 16), 0x85ebca6b);
    a = Math.imul(a ^ (a >>> 13), 0xc2b2ae35);
    a = (a ^ (a >>> 16)) >>> 0 || 1;
    const next = () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    return {
      next,
      range: (lo, hi) => lo + (hi - lo) * next(),
      int: (lo, hi) => lo + Math.floor(next() * (hi - lo + 1)),
      // approximately normal (sum of uniforms)
      gauss: (sd = 1) => (next() + next() + next() + next() - 2) * 1.732 * sd,
      pick(weights) {
        const entries = Object.entries(weights).filter(([, w]) => w > 0);
        let total = 0;
        for (const [, w] of entries) total += w;
        let x = next() * total;
        for (const [k, w] of entries) {
          if ((x -= w) < 0) return k;
        }
        return entries[entries.length - 1][0];
      },
    };
  }
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const smooth = (e0, e1, x) => {
    const t = clamp((x - e0) / (e1 - e0), 0, 1);
    return t * t * (3 - 2 * t);
  };

  // ---- skin: 10 tones from very fair to very deep, linear albedo used directly by the skin shader ----
  const SKIN_TONES = [
    [0.7, 0.425, 0.345],
    [0.66, 0.385, 0.3],
    [0.615, 0.37, 0.27],
    [0.56, 0.345, 0.235],
    [0.485, 0.298, 0.19],
    [0.4, 0.24, 0.15],
    [0.31, 0.182, 0.112],
    [0.225, 0.128, 0.082],
    [0.155, 0.088, 0.058],
    [0.105, 0.06, 0.042],
  ];
  const UNDERTONES = {
    pink: [1.03, 0.97, 1.0],
    neutral: [1, 1, 1],
    olive: [0.98, 1.02, 0.94],
    golden: [1.03, 1.0, 0.85],
    red: [1.04, 0.96, 0.95],
  };

  // ---- hair colour: index into the game's 12 colour presets ----
  const HAIR = {
    jet: 0, softBlack: 1, vdb: 2, db: 3, mb: 4, lb: 5, dblonde: 6, gblonde: 7, lblonde: 8, auburn: 9, ginger: 10, silver: 11,
  };
  // stubble / brow tint per preset (dark-end colour of the hair, linear)
  const HAIR_DARK = [
    [0.012, 0.011, 0.012], [0.018, 0.016, 0.016], [0.026, 0.019, 0.014], [0.035, 0.024, 0.018], [0.05, 0.034, 0.022],
    [0.075, 0.052, 0.033], [0.1, 0.075, 0.045], [0.14, 0.1, 0.05], [0.2, 0.16, 0.1], [0.08, 0.035, 0.018],
    [0.13, 0.05, 0.02], [0.18, 0.18, 0.18],
  ];

  const EYES = {
    blue: ['#a8c4d6', '#5d90b3', '#34688d', '#1d3c55'],
    grey: ['#c4cdd2', '#8b9aa3', '#5f6e78', '#36424a'],
    green: ['#b5c49a', '#6f8e55', '#4d6b3a', '#2c3f22'],
    hazel: ['#c9b27a', '#8d7a45', '#5f5a33', '#3a331c'],
    lbrown: ['#b38a5a', '#7d5631', '#5a3b1f', '#33200f'],
    brown: ['#8a6038', '#5a3a1e', '#3d2612', '#22150a'],
    dbrown: ['#5a3c22', '#3a2412', '#26170b', '#140c06'],
  };

  // morph keys, each in [-1, 1]; see faces.js for what they do
  const MORPHS = ['noseW', 'noseBridge', 'noseTip', 'lips', 'jaw', 'chin', 'cheek', 'brow'];

  // The four customer classes. Skin tone range, hair textures (with their curl sub-types), natural hair and
  // eye colours, beard growth and how common pattern baldness is all follow the class; age then decides
  // greying and baldness stage.
  const HERITAGE = [
    { id: 'white', w: 25, skin: [0, 3.2], under: { pink: 3, neutral: 3, olive: 2, red: 1 },
      tex: { straight: 55, wavy: 30, curly: 15 },
      hair: { jet: 0.5, softBlack: 2, vdb: 4, db: 6, mb: 5, lb: 4, dblonde: 3, gblonde: 2, lblonde: 1.2, auburn: 1, ginger: 1 },
      eyes: { blue: 4, grey: 1, green: 2, hazel: 2.5, lbrown: 1.5, brown: 3.5 }, greyOnset: 34, bald: 1, beard: 1.05, patchy: 0.08,
      morph: { noseW: -0.2, noseBridge: 0.35, noseTip: 0.12, lips: -0.15, jaw: 0.1, chin: 0.12, cheek: -0.05, brow: 0.3 } },
    { id: 'black', w: 25, skin: [5.6, 9.4], under: { neutral: 3, golden: 1, red: 1 },
      tex: { coily: 85, curly: 15 },
      hair: { jet: 8, softBlack: 3 },
      eyes: { dbrown: 8, brown: 2 }, greyOnset: 40, bald: 0.7, beard: 0.9, patchy: 0.15,
      morph: { noseW: 0.5, noseBridge: -0.2, noseTip: -0.08, lips: 0.55, jaw: 0.1, chin: 0, cheek: 0.2, brow: 0.1 } },
    { id: 'east-asian', w: 25, skin: [1, 3.8], under: { golden: 4, neutral: 1 },
      tex: { straight: 90, wavy: 10 },
      hair: { jet: 7, softBlack: 4, vdb: 1 },
      eyes: { dbrown: 7, brown: 3 }, greyOnset: 37, bald: 0.6, beard: 0.45, patchy: 0.45,
      morph: { noseW: 0.15, noseBridge: -0.5, noseTip: -0.2, lips: 0.1, jaw: 0.2, chin: -0.1, cheek: 0.4, brow: -0.4 } },
    { id: 'south-asian', w: 25, skin: [3.6, 7.2], under: { golden: 3, neutral: 2 },
      tex: { straight: 40, wavy: 50, curly: 10 },
      hair: { jet: 6, softBlack: 4, vdb: 2 },
      eyes: { brown: 6, dbrown: 4, hazel: 0.6, lbrown: 0.6, green: 0.2 }, greyOnset: 33, bald: 0.9, beard: 1.1, patchy: 0.12,
      morph: { noseW: 0.2, noseBridge: 0.15, noseTip: 0.1, lips: 0.2, jaw: 0, chin: -0.05, cheek: 0.1, brow: 0.1 } },
  ];

  const AGE_BANDS = {
    young: { w: 40, years: [18, 30] },
    middle: { w: 35, years: [31, 55] },
    old: { w: 25, years: [56, 84] },
  };

  // ---- natural hair colour by class, adjusted by age --------------------------------------------
  // White: UK Biobank (white British adults): light brown 41%, dark brown 37%, blond 11.5%, red 4.6%,
  // black 4.2%. Blond darkens through childhood into the 20s, so it is a little more common among young
  // men and less among older ones. Black, East Asian and South Asian hair is almost always black /
  // soft black, with a little very dark brown (more often in South Asians).
  const HAIR_BY_CLASS = {
    white: {
      base: { jet: 1, softBlack: 3.2, vdb: 12, db: 25, mb: 24, lb: 17, dblonde: 6.5, gblonde: 3, lblonde: 1.5, auburn: 2, ginger: 2.6 },
      young: { lb: 1.1, dblonde: 1.3, gblonde: 1.4, lblonde: 1.5 },
      old: { dblonde: 0.75, gblonde: 0.6, lblonde: 0.5, ginger: 0.9 },
    },
    black: { base: { jet: 70, softBlack: 28, vdb: 2 } },
    'east-asian': { base: { jet: 55, softBlack: 40, vdb: 5 } },
    'south-asian': { base: { jet: 55, softBlack: 35, vdb: 9, db: 1 } },
  };

  // ---- greying by class -------------------------------------------------------------------------
  // Average onset: mid-30s White, late 30s East Asian, mid-40s Black; at 50 only 6-23% of people are
  // half grey, so it builds slowly. Premature greying (before ~25) is reported in roughly a quarter or
  // more of young South Asian adults. Beards usually grey ahead of the scalp, often chin first.
  const GREY_BY_CLASS = {
    white: { onset: 34, sd: 8, span: 44, premature: 0.06 },
    black: { onset: 44, sd: 9, span: 50, premature: 0.03 },
    'east-asian': { onset: 38, sd: 8, span: 47, premature: 0.06 },
    'south-asian': { onset: 34, sd: 8, span: 45, premature: 0.3 },
  };
  const GREY_PATTERNS = { temples: 45, even: 30, front: 12, crown: 13 };
  const GREY_TONES = { silver: 45, pewter: 30, white: 25 }; // how the unpigmented hair reads
  const BEARD_GREY_PATTERNS = { chin: 50, even: 35, sides: 15 };

  // ---- hair loss by class -----------------------------------------------------------------------
  // Pattern baldness is most common in White men (and very common in Indian population studies), about
  // a third as common in East Asian men (14-20% vs ~50%) and thought to be about a third lower in Black
  // men. East Asian men show relatively more crown / diffuse loss and less frontal recession; in Black
  // men crown-first loss (including scarring crown alopecia) is relatively common.
  const NORWOOD = {
    young: { 1: 52, 2: 28, 3: 11, '3v': 4, 4: 3, 5: 1.5, 6: 0.4, 7: 0.1 },
    middle: { 1: 24, 2: 22, 3: 15, '3v': 10, 4: 11, 5: 8, 6: 6, 7: 4 },
    old: { 1: 12, 2: 13, 3: 12, '3v': 10, 4: 12, 5: 13, 6: 14, 7: 14 },
  };
  const BALD_BY_CLASS = {
    white: { prevalence: 1, types: { norwood: 85, 'norwood-a': 5, crown: 7, diffuse: 3 } },
    'south-asian': { prevalence: 1, types: { norwood: 80, 'norwood-a': 5, crown: 10, diffuse: 5 } },
    'east-asian': { prevalence: 0.45, types: { norwood: 50, 'norwood-a': 5, crown: 25, diffuse: 20 } },
    black: { prevalence: 0.65, types: { norwood: 55, 'norwood-a': 5, crown: 30, diffuse: 10 } },
  };
  // alopecia areata: round smooth patches, any class, most often in young men; sometimes in the beard
  const AREATA_BY_AGE = { young: 0.03, middle: 0.015, old: 0.01 };
  // [front recession, temple recession, crown radius, bridge loss, horseshoe (fringe drop)] in radians-ish
  const NORWOOD_SHAPE = {
    1: [0, 0, 0, 0, 0],
    2: [0.02, 0.1, 0, 0, 0],
    3: [0.05, 0.2, 0, 0, 0],
    '3v': [0.05, 0.2, 0.17, 0, 0],
    4: [0.14, 0.27, 0.23, 0, 0],
    5: [0.26, 0.34, 0.3, 0.5, 0],
    6: [0.46, 0.42, 0.36, 1, 0],
    7: [0.62, 0.5, 0.44, 1, 0.3],
  };
  const STAGE_LEVEL = { 1: 0, 2: 1, 3: 2, '3v': 2.5, 4: 3, 5: 4, 6: 5, 7: 6 };
  // the baldness shape for any hair-loss type: [front, temple, crown, bridge, fringe, diffuse]
  function baldShape(b) {
    const s = NORWOOD_SHAPE[b.norwood] || NORWOOD_SHAPE[1];
    const lv = STAGE_LEVEL[b.norwood] || 0;
    const k = 0.85 + 0.3 * (b.edge || 0);
    switch (b.type) {
      case 'norwood-a': // the hairline moves straight back, no M-shaped temples
        return [(s[0] * 1.2 + s[1] * 0.55) * k, 0.02, s[2] * 0.6 * k, s[3], s[4], b.diffuse || 0];
      case 'crown': // vertex loss spreading outward from the crown, hairline kept
        return [0, 0.02 * lv, (0.08 + 0.065 * lv) * k, 0, 0, b.diffuse || 0];
      case 'diffuse': // thinning over the whole top, frontal hairline kept
        return [0, 0.03 * lv, 0.04 * lv, 0, 0, Math.min(0.8, 0.18 + 0.1 * lv + (b.diffuse || 0))];
      default:
        return [s[0] * k, s[1] * k, s[2] * k, s[3], s[4], b.diffuse || 0];
    }
  }

  // ---- facial hair --------------------------------------------------------------------------------
  // regions and lengths (mm); flags shape special styles (see faces.js beardStart)
  const BEARD_STYLES = {
    clean: {},
    stubble: { moustache: [0.8, 2], chin: [0.8, 2], cheeks: [0.8, 2], neck: [0.5, 1.5], jaw: [0.8, 2] },
    moustache: { moustache: [8, 16] }, // chevron
    pencil: { moustache: [2, 4], pencil: true },
    walrus: { moustache: [20, 30] },
    horseshoe: { moustache: [10, 16], horseshoe: true },
    goatee: { moustache: [6, 12], chin: [8, 16] },
    vandyke: { moustache: [8, 14], chin: [10, 20], chinOnly: true },
    chinstrap: { jaw: [4, 8], chin: [4, 8] },
    shenandoah: { chin: [13, 25], cheeks: [10, 16], jaw: [13, 22], neck: [8, 13] }, // full beard, no moustache
    boxed: { moustache: [6, 10], chin: [8, 13], cheeks: [6, 10], jaw: [8, 13], neck: [3, 6] },
    full: { moustache: [10, 16], chin: [13, 22], cheeks: [10, 16], jaw: [13, 22], neck: [8, 13] },
    long: { moustache: [13, 20], chin: [30, 50], cheeks: [16, 25], jaw: [25, 40], neck: [16, 25] },
    mutton: { cheeks: [10, 16], jaw: [8, 13] },
  };
  // Baseline by age (UK YouGov): ~46% clean-shaven; beard + moustache 34%, stubble 13%, beard only 4%,
  // moustache only 2%. Young men lean to stubble, middle-aged men to beards, most men over 60 shave,
  // and moustache-only peaks at 40-59.
  const BEARD_BY_AGE = {
    young: { clean: 33, stubble: 26, boxed: 13, full: 9, goatee: 6, chinstrap: 3, vandyke: 2, moustache: 1.5, pencil: 0.5, shenandoah: 1.5, long: 1, horseshoe: 0.3 },
    middle: { clean: 40, stubble: 14, boxed: 12, full: 11, goatee: 6, vandyke: 3, moustache: 4, pencil: 1, walrus: 1, horseshoe: 1, shenandoah: 2.5, long: 2, mutton: 1, chinstrap: 1.5 },
    old: { clean: 60, stubble: 5, full: 7, boxed: 4, long: 3, moustache: 9, walrus: 3, pencil: 1, horseshoe: 1, goatee: 3, shenandoah: 2.5, mutton: 1.5 },
  };
  // class leanings (weak evidence; kept mild): lighter, patchier beard growth and more shaving among
  // East Asian men; moustaches and long full beards more common among South Asian men; short boxed
  // beards, goatees and chinstraps more common among Black men.
  const BEARD_CLASS_MULT = {
    white: {},
    'east-asian': { clean: 1.8, stubble: 1.1, full: 0.35, boxed: 0.45, long: 0.3, mutton: 0.3, shenandoah: 0.3, goatee: 1.3, moustache: 1.3, pencil: 1.5, walrus: 0.4 },
    'south-asian': { moustache: 2.5, walrus: 1.5, pencil: 1.5, full: 1.3, long: 2.5, horseshoe: 1.2 },
    black: { boxed: 1.3, goatee: 1.4, chinstrap: 1.8, vandyke: 1.2, long: 0.6, walrus: 0.6, stubble: 1.1 },
  };

  function makePerson(seed, opts = {}) {
    const R = rng(seed);
    const weights = {};
    HERITAGE.forEach((h, i) => (weights[i] = h.w));
    const her = HERITAGE[opts.heritage != null ? opts.heritage : +R.pick(weights)];
    const cls = her.id;

    const ageBand = opts.age || R.pick(Object.fromEntries(Object.entries(AGE_BANDS).map(([k, v]) => [k, v.w])));
    const [y0, y1] = AGE_BANDS[ageBand].years;
    const years = R.int(y0, y1);
    const age01 = clamp((years - 18) / (80 - 18), 0, 1);

    const skinT = R.range(her.skin[0], her.skin[1]);
    const under = R.pick(her.under);
    const texture = opts.texture || R.pick(her.tex);
    // curl tightness inside the texture family (e.g. 3a..3c, 4a..4c)
    const curl = R.next();

    // natural hair colour
    const hc = HAIR_BY_CLASS[cls] || HAIR_BY_CLASS.white;
    const hw = Object.assign({}, hc.base);
    for (const [k, m] of Object.entries(hc[ageBand] || {})) if (hw[k]) hw[k] *= m;
    const hairColour = opts.hairColour != null ? opts.hairColour : HAIR[R.pick(hw)];

    // greying
    const gc = GREY_BY_CLASS[cls] || GREY_BY_CLASS.white;
    const onset = gc.onset + R.gauss(gc.sd);
    let grey = Math.min(0.97, Math.pow(clamp((years - onset) / gc.span, 0, 1), 1.1));
    // premature: a scattering of grey before ~30
    if (years <= 30 && R.next() < gc.premature) grey = Math.max(grey, R.range(0.02, 0.1));
    if (opts.grey != null) grey = opts.grey;
    const greyPattern = opts.greyPattern || R.pick(GREY_PATTERNS);
    const greyTone = R.pick(Object.assign({}, GREY_TONES, { white: GREY_TONES.white * (0.6 + age01) }));
    // the beard usually greys ahead of the scalp, sometimes level with it, occasionally behind
    const lead = R.pick({ ahead: 70, level: 20, behind: 10 });
    let beardGrey = lead === 'ahead' ? (grey > 0.005 || years > onset - 3 ? Math.min(1, grey * 1.3 + 0.05) : 0) : lead === 'level' ? grey : grey * 0.7;
    if (opts.beardGrey != null) beardGrey = opts.beardGrey;
    const beardGreyPattern = R.pick(BEARD_GREY_PATTERNS);

    // hair loss
    const bc = BALD_BY_CLASS[cls] || BALD_BY_CLASS.white;
    const nwTable = Object.assign({}, NORWOOD[ageBand]);
    for (const k of Object.keys(nwTable)) if (k !== '1') nwTable[k] *= bc.prevalence;
    // opts.noLoss: a full head of hair (no pattern loss, thinning or patches)
    let norwood = opts.noLoss ? '1' : opts.norwood != null ? String(opts.norwood) : R.pick(nwTable);
    let baldType = opts.noLoss ? 'none' : opts.baldType || (norwood === '1' ? 'none' : R.pick(bc.types));
    if (baldType !== 'none' && norwood === '1') norwood = '3';
    const diffuse = !opts.noLoss && R.next() < 0.04 + 0.08 * age01 ? R.range(0.12, 0.4) * (0.4 + age01) : 0;
    // alopecia areata patches (scalp, sometimes beard)
    const patches = [];
    if (opts.areata || (!opts.noLoss && R.next() < AREATA_BY_AGE[ageBand])) {
      const n = 1 + Math.floor(R.next() * 2.4);
      for (let i = 0; i < n; i++) {
        if (R.next() < 0.25) {
          // beard area (alopecia barbae): cheek / jaw / chin
          const sx = R.next() < 0.5 ? -1 : 1;
          patches.push([+(sx * R.range(0.4, 1.2)).toFixed(3), +R.range(-0.75, 0.25).toFixed(3), +R.range(1.3, 1.9).toFixed(3), +R.range(0.12, 0.2).toFixed(3)]);
        } else {
          // scalp: a point on the head shell around (0, 2.1, -0.13)
          const th = R.range(-1.4, 1.0), ph = R.range(-1.15, 1.15), rr = 1.75;
          const x = Math.sin(ph) * rr, yz = Math.cos(ph) * rr;
          patches.push([+x.toFixed(3), +(2.1 + Math.cos(th) * yz).toFixed(3), +(-0.13 + Math.sin(th) * yz).toFixed(3), +R.range(0.14, 0.3).toFixed(3)]);
        }
      }
    }

    // facial hair
    const bw = Object.assign({}, BEARD_BY_AGE[ageBand]);
    for (const [k, m] of Object.entries(BEARD_CLASS_MULT[cls] || {})) if (bw[k] != null) bw[k] *= m;
    const beardStyle = opts.beard || R.pick(bw);
    const style = BEARD_STYLES[beardStyle];
    const beard = {};
    for (const region of ['moustache', 'chin', 'cheeks', 'jaw', 'neck']) {
      if (style[region]) beard[region] = +R.range(style[region][0], style[region][1]).toFixed(1);
    }
    const cheekLine = R.range(-1, 1); // high (-1) to low (1) cheek line
    const neckLine = R.range(-1, 1);
    const patchy = clamp(her.patchy + R.gauss(0.08) + (ageBand === 'young' ? 0.12 : 0), 0, 0.85);

    // face shape: group tendency (subtle) + individual variation (larger)
    const morph = {};
    for (const k of MORPHS) morph[k] = +clamp(0.55 * (her.morph[k] || 0) + R.gauss(0.42), -1, 1).toFixed(3);
    if (opts.morph) Object.assign(morph, opts.morph);

    const eyes = R.pick(her.eyes);
    const brow = { thick: +clamp(R.range(0.82, 1.18) + 0.18 * age01, 0.7, 1.45).toFixed(3), grey: +clamp(grey * 0.65, 0, 1).toFixed(3) };

    return {
      v: PERSON_VERSION,
      seed: seed >>> 0,
      heritage: her.id,
      age: ageBand,
      years,
      skin: { tone: +skinT.toFixed(3), under },
      hair: {
        texture, type: { straight: '1', wavy: '2', curly: '3', coily: '4' }[texture] + 'abc'[Math.min(2, Math.floor(curl * 3))],
        curl: +curl.toFixed(3), colour: hairColour, grey: +grey.toFixed(3), greyPattern, greyTone,
      },
      bald: { type: baldType, norwood, diffuse: +diffuse.toFixed(3), edge: +R.range(0, 1).toFixed(3), patches },
      beard: { style: beardStyle, mm: beard, grey: +beardGrey.toFixed(3), greyPattern: beardGreyPattern, patchy: +patchy.toFixed(3),
        cheekLine: +cheekLine.toFixed(3), neckLine: +neckLine.toFixed(3), warm: +clamp(R.gauss(0.5) + 0.15, 0, 1).toFixed(3) },
      eyes,
      brow,
      morph,
    };
  }

  // a saved customer is only used when every field the game reads has the right type (own keys only, so
  // "constructor" and friends are not table entries); anything else is regenerated from the seed
  const own = (t, k) => typeof k === 'string' && Object.prototype.hasOwnProperty.call(t, k);
  const isObj = (o) => !!o && typeof o === 'object' && !Array.isArray(o);
  const num = Number.isFinite;
  const nums = (o, keys) => isObj(o) && Object.keys(o).length <= 16 && Object.entries(o).every(([k, v]) => num(v) && (!keys || keys.includes(k)));
  const str = (v) => typeof v === 'string' && v.length < 40;
  function validPerson(p) {
    try {
      return (
        isObj(p) && p.v === PERSON_VERSION && Number.isInteger(p.seed) &&
        Number.isInteger(p.years) && p.years >= 16 && p.years <= 95 && own(AGE_BANDS, p.age) &&
        isObj(p.skin) && num(p.skin.tone) && own(UNDERTONES, p.skin.under) &&
        isObj(p.hair) && ['straight', 'wavy', 'curly', 'coily'].includes(p.hair.texture) && Number.isInteger(p.hair.colour) &&
        p.hair.colour >= 0 && p.hair.colour < HAIR_DARK.length && num(p.hair.grey) && num(p.hair.curl) && str(p.hair.greyPattern) && str(p.hair.greyTone) &&
        isObj(p.bald) && own(NORWOOD_SHAPE, p.bald.norwood) && str(p.bald.type) && num(p.bald.diffuse) && num(p.bald.edge) &&
        Array.isArray(p.bald.patches) && p.bald.patches.length <= 64 && p.bald.patches.every((q) => Array.isArray(q) && q.length === 4 && q.every(num)) &&
        isObj(p.beard) && own(BEARD_STYLES, p.beard.style) && nums(p.beard.mm, ['moustache', 'chin', 'cheeks', 'jaw', 'neck']) &&
        ['grey', 'patchy', 'cheekLine', 'neckLine', 'warm'].every((k) => num(p.beard[k])) && str(p.beard.greyPattern) &&
        own(EYES, p.eyes) && nums(p.brow) && num(p.brow.thick) && num(p.brow.grey) && nums(p.morph, MORPHS)
      );
    } catch (e) {
      return false;
    }
  }

  // the colour of skin at tone t (0..9.4, fractional), with undertone
  function skinColour(p) {
    const t = clamp(p.skin.tone, 0, SKIN_TONES.length - 1);
    const i = Math.min(SKIN_TONES.length - 2, Math.floor(t)), f = t - i;
    const u = UNDERTONES[p.skin.under] || UNDERTONES.neutral;
    return [0, 1, 2].map((k) => (SKIN_TONES[i][k] * (1 - f) + SKIN_TONES[i + 1][k] * f) * u[k]);
  }

  Object.assign(HSC, {
    rng, clamp, smooth, makePerson, validPerson, skinColour,
    SKIN_TONES, UNDERTONES, HAIR_DARK, EYES, MORPHS, HERITAGE, NORWOOD_SHAPE, BEARD_STYLES, PERSON_VERSION, baldShape,
  });
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Shader code driven by the current customer. All coordinates are the head mesh's own (un-morphed)
// object space: y up, +z toward the face, the scalp top around y = 3.9.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';

  // Uniforms shared by every material that draws the customer. Plain arrays work for vecN uniforms.
  HSC.U = {
    uBaldA: { value: [0, 0, 0, 0] }, // front recession, temple recession, crown radius, bridge loss
    uBaldB: { value: [0, 0, 0, 0] }, // horseshoe fringe drop, diffuse thinning, pattern seed, -
    uBrowA: { value: [1, 1, 0, 0] }, // brow thickness, brow density
    uBeard: { value: null }, // beard length grid (mm / 50)
    uSkinA: { value: [0.66, 0.385, 0.3, 0] }, // base albedo, darkness 0..1
    uLip: { value: [1.06, 0.78, 0.93] }, // lip colour relative to skin
    uCast: { value: [0.7, 0.73, 0.8, 1] }, // shaved-follicle cast colour, strength
    uHairDark: { value: [0.035, 0.024, 0.018] }, // hair colour where it covers skin (scalp)
    uBeardDark: { value: [0.035, 0.024, 0.018] }, // beard colour where it covers skin
    uBrowTint: { value: [0.085, 0.055, 0.04] },
    uAgeA: { value: [0, 0, 0, 0] }, // age 0..1, age spots, wrinkle depth, sallowness
    uStyleA: { value: [0.22, 0.56, 0.56, 0.5] }, // hang, forward, lift, top lift
    uStyleB: { value: [0.16, 0.1, 0.02, 1] }, // spread, sag, wave, wave frequency
    uStyleC: { value: [0, 0, 1, 1] }, // coil radius (x length), coil turns, shrinkage, strand thickness
    uGreyA: { value: [0, 0.6, 0.62, 0] }, // grey fraction, -, grey brightness, -
    uGreyB: { value: [1.2, 0, 0, 0.4] }, // where the scalp greys first: temples, front, crown, average
    uBeardGreyB: { value: [1, 0, 0, 0.4] }, // where the beard greys first: chin, sides, moustache, average
    uBeardLip: { value: 0.4 }, // how far the moustache may hang over the upper lip: 0 lip edge .. 1 mouth line
    uAreata: { value: new Float32Array(12) }, // up to 3 alopecia areata patches: centre xyz, radius
    uBStyleA: { value: [0, 0.15, 0.45, 0.1] }, // beard: wave, wave frequency, lift, sag
    uBStyleB: { value: [0, 0, 1, 1] }, // beard: coil radius, coil turns, shrinkage, thickness
    uBeardTint: { value: [1, 1, 1] },
    uBeardGrey: { value: [0, 0.62, 0.3, 0] }, // grey fraction, grey brightness, patchiness, -
    uLift: { value: 0 }, // extra sheen and rim light on the hair (0..1), the same for every customer
    uDebug: { value: 0 },
  };

  // Beard grid: a 128 x 64 map of the lower face, projected from a point inside the mouth.
  const BC = [0, 0.3, 0.3], AZR = 1.85, EL0 = -1.45, ELR = 2.25;
  HSC.BEARD_PROJ = { BC, AZR, EL0, ELR };

  // ---- shared declarations, injected into the game's common shader prelude ----
  HSC.glsl = {};
  HSC.glsl.decls = `
uniform vec4 uBaldA, uBaldB, uBrowA;
uniform vec4 uAreata[3];
// alopecia areata: round, smooth patches (scalp or beard) with a slightly irregular edge
float areataKeep(vec3 p){
  float k = 1.0;
  for (int i = 0; i < 3; i++) {
    vec4 a = uAreata[i];
    if (a.w > .001) k *= smoothstep(a.w * .72, a.w * 1.08, distance(p, a.xyz) + (n3(p * 7.0 + float(i)) - .5) * a.w * .35);
  }
  return k;
}
uniform sampler2D uBeard;
uniform float uDebug;
// Pattern baldness (Hamilton-Norwood): 1 where hair grows, 0 where it is gone, a soft thinning band between.
float baldDensity(vec3 p){
  if (uBaldA.x + uBaldA.y + uBaldA.z + uBaldB.x + uBaldB.y < .001) return areataKeep(p);
  vec3 q = vec3(p.x, p.y - 2.1, p.z + .13);
  float th = atan(q.z, q.y);                  // 0 on top, + toward the face, - toward the nape
  float ph = atan(p.x, length(q.yz));         // left / right
  float aph = abs(ph);
  float wob = (n3(p * 2.7 + uBaldB.z) - .5) * .10 + (n3(p * 8.0 + uBaldB.z) - .5) * .035;
  // frontal and temporal recession: the hairline moves back from its natural line
  float templ = exp(-pow((aph - .58) / .22, 2.0));
  float rec = uBaldA.x + uBaldA.y * templ;
  float hairline = 1.13 - rec + wob;
  float front = smoothstep(hairline - .07, hairline + .1, th) * step(.001, rec) * smoothstep(2.35, 2.7, p.y);
  // crown (vertex) bald spot
  // the crown thins outward from a bald centre: a wide band of sparse, finer hair, slightly oval and uneven
  float cr = length(vec2((th + .27) * .85, ph * 1.08));
  float crown = (1.0 - smoothstep(uBaldA.z * .45, uBaldA.z * 1.2 + .03, cr + wob * 1.3)) * step(.001, uBaldA.z);
  // the bridge between them goes as the pattern advances
  float bw = mix(.25, .62, uBaldA.w) + wob;
  float bridge = uBaldA.w * smoothstep(-.3, -.15, th) * (1.0 - smoothstep(bw - .08, bw + .04, aph)) * smoothstep(2.35, 2.7, p.y);
  // horseshoe: only a fringe stays around the sides and back
  // the fringe sits low over the ears and rises toward the back of the head
  float fringe = 3.08 - uBaldB.x - .18 * smoothstep(.9, 1.5, aph) + .22 * smoothstep(-.2, -.9, th) * (1.0 - smoothstep(.6, 1.3, aph)) + wob * 1.4;
  float top = step(.001, uBaldB.x) * smoothstep(fringe - .06, fringe + .1, p.y);
  float b = max(max(front, crown), max(bridge, top));
  float d = 1.0 - b;
  // diffuse thinning over the top
  d *= 1.0 - uBaldB.y * smoothstep(2.9, 3.5, p.y) * (.55 + .45 * n3(p * 3.3 + 9.0));
  return clamp(d, 0.0, 1.0) * areataKeep(p);
}
const vec3 BEARD_C = vec3(${BC.join(',')});
vec2 beardUV(vec3 p){
  vec3 d = p - BEARD_C;
  float az = atan(d.x, d.z);
  float el = atan(d.y, length(d.xz));
  return vec2(az / ${(2 * AZR).toFixed(4)} + .5, (el - (${EL0.toFixed(4)})) / ${ELR.toFixed(4)});
}
float beardMM(vec3 p){ return texture2D(uBeard, beardUV(p)).r * 50.0; }
float lipMask(vec3 p){
  float ax = abs(p.x), ly = p.y - .125;
  float lipW = 1.0 - smoothstep(.55, .72, ax);
  float upL = (1.0 - smoothstep(.55, .95, length(vec2(p.x / .66, (ly - .12) / .15)))) * step(.0, ly);
  float loL = (1.0 - smoothstep(.55, .95, length(vec2(p.x / .62, (ly + .13) / .21)))) * step(ly, .0);
  return max(upL, loL) * smoothstep(1.8, 2.2, p.z) * lipW;
}
// the area where a beard can grow (individual styles use part of it)
float beardZoneS(vec3 p, float soft){
  float ax = abs(p.x);
  float ang = atan(ax, p.z - .25);
  float yTop = mix(.53, 1.45, smoothstep(.3, 1.45, ang));
  float yBot = mix(-1.22, -.8, smoothstep(.85, 1.6, ang));
  float m = smoothstep(yBot - .04 * soft, yBot + .08 * soft, p.y) * (1.0 - smoothstep(yTop - .08 * soft, yTop + .03, p.y));
  m *= 1.0 - smoothstep(1.5 - .03 * soft, 1.64, ang);
  m *= 1.0 - smoothstep(.15, .5, lipMask(p));
  return m;
}
float beardZone(vec3 p){ return beardZoneS(p, 1.0); }
`;

  // ---- skin material (replaces the game's onBeforeCompile for the head) ----
  HSC.skinCompile = function (e, ctx) {
    Object.assign(e.uniforms, { uGrid: ctx.uGrid, uHairTint: ctx.uHairTint, uDensity: ctx.uDensity }, HSC.U);
    e.vertexShader = e.vertexShader
      .replace('#include <common>', `#include <common>
attribute vec3 hsBase;
varying vec3 vObj;`)
      .replace('#include <begin_vertex>', `#include <begin_vertex>
vObj = hsBase;`);
    e.fragmentShader = e.fragmentShader
      .replace('#include <common>', `#include <common>
varying vec3 vObj;
${ctx.Ql}
uniform vec4 uSkinA, uCast, uAgeA, uBeardGrey;
uniform vec3 uLip, uHairDark, uBeardDark, uBrowTint;
#ifdef HSC_LOW
float skinBump(vec3 P){ return n3(P * 62.0); }
#else
float skinBump(vec3 P){ return .55 * n3(P * 62.0) + .30 * n3(P * 118.0) + .15 * n3(P * 36.0); }
#endif
float segDist(vec2 p, vec2 a, vec2 b){ vec2 pa = p - a, ba = b - a; float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0); return length(pa - ba * h); }
// expression lines and folds that deepen with age (0 = none)
float wrinkles(vec3 P, float age){
  if (age < .02) return 0.0;
  float aX = abs(P.x), w = 0.0;
  // forehead: horizontal, slightly wavy lines
  float fh = smoothstep(2.12, 2.3, P.y) * (1.0 - smoothstep(2.72, 2.9, P.y)) * smoothstep(1.55, 1.95, P.z) * (1.0 - smoothstep(.85, 1.25, aX));
  float fl = pow(abs(sin(P.y * 26.0 + 2.6 * n3(P * vec3(1.6, .4, 1.6)) + .8 * sin(P.x * 2.3))), 22.0);
  float broken = smoothstep(.35, .65, n3(P * vec3(2.2, 9.0, 2.2) + 5.0));   // lines fade in and out along their length
  w += fh * fl * broken * smoothstep(.25, .85, age) * .7;
  // frown lines between the brows
  float gl = (1.0 - smoothstep(.0, .035, abs(aX - .13 - .05 * (P.y - 2.0)))) * smoothstep(1.85, 1.95, P.y) * (1.0 - smoothstep(2.15, 2.3, P.y)) * smoothstep(2.0, 2.2, P.z);
  w += gl * smoothstep(.3, .8, age) * .8;
  // crow's feet at the outer eye corners
  vec2 cf = vec2(aX - .98, P.y - 1.6);
  float cr = length(cf), ca = atan(cf.y, cf.x);
  float crow = (1.0 - smoothstep(.12, .36, cr)) * smoothstep(.04, .1, cr) * step(-.02, cf.x) * pow(abs(sin(ca * 7.0 + 2.0 * n3(P * 5.0))), 10.0);
  w += crow * smoothstep(.2, .75, age);
  // nasolabial folds (nose wing to mouth corner) and marionette lines (mouth corner down)
  vec2 xy = vec2(aX, P.y);
  float nl = 1.0 - smoothstep(.0, .045 + .02 * age, segDist(xy, vec2(.36, .66), vec2(.7, .02)));
  float ml = 1.0 - smoothstep(.0, .035, segDist(xy, vec2(.66, .0), vec2(.62, -.45)));
  w += nl * smoothstep(1.7, 2.1, P.z) * (.25 + .75 * smoothstep(.1, .8, age));
  w += ml * smoothstep(1.6, 1.95, P.z) * smoothstep(.55, .95, age);
  // under-eye lines
  vec2 ue = vec2((aX - .63) / .32, (P.y - 1.33) / .1);
  w += (1.0 - smoothstep(.0, .25, abs(length(ue) - 1.0))) * step(P.y, 1.4) * smoothstep(1.8, 2.05, P.z) * smoothstep(.3, .9, age) * .6;
  // neck rings
  float nk = .6 * pow(abs(sin(P.y * 22.0 + n3(P * 2.0) * 2.0)), 10.0) * smoothstep(-1.7, -1.35, P.y) * (1.0 - smoothstep(-1.05, -.9, P.y)) * smoothstep(.3, .9, P.z);
  w += nk * smoothstep(.45, 1.0, age) * .7;
  return clamp(w, 0.0, 1.0) * uAgeA.z;
}
`)
      .replace('#include <map_fragment>', `
      vec3 P = vObj; float aX = abs(P.x);
      vec3 base = uSkinA.rgb; float dark = uSkinA.w; float age = uAgeA.x;
      vec3 tone = base;
      tone *= 1.0 + .10 * (n3(P * 1.1) - .5);
      tone *= 1.0 + vec3(.11, -.03, -.03) * (n3(P * 2.6 + 4.0) - .5);
      tone *= 1.0 + vec3(.08, -.025, -.025) * (n3(P * 9.0 + 11.0) - .5);
      float pores = pow(n3(P * 85.0), 4.0);
      tone *= 1.0 - (.14 + .08 * age) * pores;
      // older skin: a little sallower and less even
      tone *= mix(vec3(1.0), vec3(1.0, .965, .92), uAgeA.w);
      tone *= 1.0 + .12 * age * (n3(P * 4.5 + 3.0) - .5);
      float fr = smoothstep(.2, 2.0, P.z);
      float flush = 1.0 - .75 * dark;   // redness reads much less on deeper skin
      float cheek = fr * (1.0 - smoothstep(.55, 1.5, aX - .35)) * smoothstep(-.4, .5, P.y) * (1.0 - smoothstep(1.3, 1.9, P.y));
      tone *= 1.0 + vec3(.12, -.05, -.05) * cheek * flush;
      float nose = 1.0 - smoothstep(.0, .5, length(vec3(P.x, P.y - .8, P.z - 2.5)));
      tone *= 1.0 + vec3(.11, -.05, -.05) * nose * flush;
      float ear = smoothstep(1.66, 1.85, aX) * (1.0 - smoothstep(2.2, 2.7, P.y));
      tone *= 1.0 + vec3(.14, -.05, -.03) * ear * flush;
      // lips + mouth line
      float ly = P.y - .125;
      float lipsM = lipMask(P);
      float lipTone = n3(P * 40.0);
      vec3 lipC = base * uLip * mix(vec3(1.0), vec3(.94, .87, .87), step(ly, .0)) * (.9 + .2 * lipTone);
      lipC *= 1.0 - .25 * (1.0 - smoothstep(.0, .06, abs(ly - .06)));
      tone = mix(tone, lipC, lipsM * .95);
      float mline = (1.0 - smoothstep(.0, .022, abs(ly + .035 * P.x * P.x * 2.0))) * (1.0 - smoothstep(.5, .66, aX)) * smoothstep(1.9, 2.3, P.z);
      tone *= 1.0 - .6 * mline;
      // nostrils
      float nost = 1.0 - smoothstep(.04, .13, length(vec3((aX - .21) * 1.2, (P.y - .60) * 1.6, P.z - 2.36)));
      tone *= 1.0 - .7 * nost;
      // eye sockets, lid creases, lash lines
      vec3 eC = vec3(aX - 0.628, P.y - 1.624, P.z - 1.627);
      float eyesock = 1.0 - smoothstep(.0, .8, length(eC));
      tone *= 1.0 - (.20 + .08 * age) * eyesock;
      vec2 eo = vec2(eC.x / .40, eC.y / .21);
      float ring = 1.0 - smoothstep(.0, .12, abs(length(eo) - 1.0));
      float upper = smoothstep(-.1, .5, eC.y);
      tone *= 1.0 - ring * (.25 + .35 * upper) * smoothstep(.4, 1.0, P.z);
      float crease = (1.0 - smoothstep(.0, .06, abs(length(vec2(eC.x / .46, (eC.y - .12) / .30)) - 1.0))) * upper;
      tone *= 1.0 - (.08 + .1 * age) * crease;
      // dark circles under the eyes
      float circ = (1.0 - smoothstep(.0, .3, length(vec2((aX - .62) / 1.3, P.y - 1.36)))) * smoothstep(1.8, 2.1, P.z);
      tone *= 1.0 - circ * (.06 + .1 * age) * vec3(.8, 1.0, 1.0);
      // eyebrows
      float bm = browMask(P) * uBrowA.y;
      float browHair = .72 + .5 * n3(P * vec3(95.0, 230.0, 95.0));
      tone = mix(tone, uBrowTint * browHair, clamp(bm * 1.25, 0.0, .94));
      // age spots on the sun-exposed upper face and scalp
      float sunlit = smoothstep(1.9, 2.6, P.y) * (smoothstep(1.2, 2.0, P.z) + smoothstep(3.0, 3.6, P.y)) + smoothstep(1.4, 1.75, aX) * smoothstep(1.3, 2.0, P.y) * .5;
      float spots = smoothstep(.76, .82, n3(P * 11.0 + 19.0)) * (.5 + .5 * n3(P * 37.0));
      tone *= mix(vec3(1.0), vec3(.9, .82, .74), clamp(spots * sunlit, 0.0, 1.0) * uAgeA.y);
      // beard area: shaved-follicle cast, follicle dots, and the stubble itself
      float bz = beardZone(P) * areataKeep(P);
      float bmm = beardMM(P) * bz;
      #ifdef HSC_LOW
      // low detail: follicles only as their average tone
      float fol = 0.0, folAA = 0.0;
      #else
      float folF = 42.0;
      vec3 fc = floor(P * folF), ff = fract(P * folF);
      vec3 fj = .3 + .4 * vec3(hsh(fc), hsh(fc + 17.0), hsh(fc + 31.0));
      float fd = length(ff - fj);
      float faa = max(fwidth(fd), .02);
      float fol = (1.0 - smoothstep(.2 - faa, .2 + faa, fd)) * step(.25, hsh(fc + 5.0));
      float folAA = 1.0 - smoothstep(.25, .7, length(fwidth(P)) * folF);
      #endif
      // the shave shadow fades out gradually toward the cheekbones and down the neck
      float bzs = beardZoneS(P, 4.0) * (.75 + .25 * n3(P * 3.0));
      tone = mix(tone, tone * uCast.rgb, bzs * .5 * uCast.w * (1.0 - .35 * uBeardGrey.z * n3(P * 6.0)));
      tone = mix(tone, tone * vec3(.45, .45, .5), bzs * uCast.w * mix(.05, .6 * fol, folAA));
      float bedge = smoothstep(.25, .75, n3(P * 7.0 + 2.0) * .6 + smoothstep(.0, 1.2, bmm) * .7);
      // even shadow of short stubble, fuller as it grows; only a soft, low-frequency variation
      float bcov = smoothstep(.1, 1.2, bmm) * mix(.72, .95, smoothstep(1.5, 5.0, bmm));
      tone = mix(tone, uBeardDark * (.85 + .3 * n3(P * 38.0)), bz * bcov * bedge * mix(.82 + .18 * n3(P * 14.0), 1.0, smoothstep(2.0, 6.0, bmm)));
      // scalp / fade skin
      float Lh = hairLen(P);
      float hm = hairMask(P);
      float hm0 = hairMask0(P);
      float baldSkin = hm0 * (1.0 - baldDensity(P));
      float st = hm * smoothstep(1.0, 2.3, P.y);
      // scalp skin sees less sun than the face: a touch paler and less red, with soft blotchy mottling
      float sc = hm0 * smoothstep(1.2, 1.9, P.y);
      vec3 scalpC = base * vec3(.977, 1.026, 1.05);
      scalpC *= 1.0 + .07 * (n3(P * 2.2 + 7.0) - .5);
      scalpC *= 1.0 + vec3(.045, -.02, -.03) * (n3(P * 2.6 + 2.0) - .5);
      // a bald scalp is sun exposed: warmer, a little ruddier
      scalpC = mix(scalpC, base * vec3(1.03, .97, .94) * (1.0 + .06 * (n3(P * 3.0) - .5)), smoothstep(.2, .8, baldSkin));
      tone = mix(tone, scalpC, sc * .9);
      // hair still below the skin leaves a cool cast over the whole growth area, even on a clean shave
      float under = st * (.85 + .15 * n3(P * 5.0 + 3.0));
      tone = mix(tone, tone * uCast.rgb, under * .6 * uCast.w);
      tone = mix(tone, tone * vec3(.42, .42, .48), st * uCast.w * mix(.06, .7 * fol, folAA));
      tone = mix(tone, tone * vec3(.26, .19, .16), st * .88 * smoothstep(0.0,.12,gridValue(P)));
      tone = mix(tone, uHairDark, smoothstep(.06, .32, Lh) * .92);
      float wr = wrinkles(P, age);
      tone *= 1.0 - .32 * wr;
      if (uDebug > .5) tone = mix(tone, vec3(.9, .1, .1), bz * .7) + vec3(0.0, .25, 0.0) * step(.5, fract(beardUV(P).x * 16.0)) * bz;
      diffuseColor.rgb = tone;`)
      .replace('#include <lights_physical_fragment>', `#include <lights_physical_fragment>
      #ifdef USE_SHEEN
        material.sheenColor *= 1.0 - .8 * smoothstep(.2, .8, baldSkin);
      #endif`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
      roughnessFactor = mix(roughnessFactor, .26, lipsM);
      roughnessFactor = mix(roughnessFactor, .44, smoothstep(2.2, 3.0, P.y) * fr * .6);
      float scR = hm * smoothstep(1.6, 3.2, P.y);
      roughnessFactor = mix(roughnessFactor, .40 + .14 * n3(P * 7.0 + 5.0), scR * .75);
      // a bald scalp shines
      roughnessFactor = mix(roughnessFactor, .3 + .1 * n3(P * 6.0), smoothstep(.3, .9, baldSkin) * .85);
      roughnessFactor = mix(roughnessFactor, min(1.0, roughnessFactor + .12), age);`)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
      {
        float hb = skinBump(vObj) * (1.0 + .6 * age);
        hb -= .25 * (st + bzs) * fol * folAA;
        hb -= 1.6 * wr;
        vec2 dh = vec2(dFdx(hb), dFdy(hb));
        vec3 q0 = dFdx(-vViewPosition), q1 = dFdy(-vViewPosition);
        vec3 R1 = cross(q1, normal), R2 = cross(normal, q0);
        float det = dot(q0, R1);
        vec3 grad = sign(det) * (dh.x * R1 + dh.y * R2);
        normal = normalize(abs(det) * normal - .0022 * grad * (1.0 - .6 * lipsM));
      }`);
  };

  // ---- strand shaders (scalp and beard share most of the code) ----
  const strandFrag = (t, tint, grey) => t + `
 uniform vec3 lA,lB,lC,cam;
 uniform vec4 uGreyA, uBeardGrey;
 uniform vec3 uBeardTint;
 uniform float uLift;
 varying vec3 vRoot,vTip,vTangent,vSeed;varying float vAlong,vEdge,vLength,vGrey;
 void main(){
  if(vLength<.0001||vSeed.z>uDensity)discard;
  float edge=abs(vEdge),aa=max(fwidth(edge),.03);if(edge>1.0-aa*.25)discard;
  vec3 tangent=normalize(vTangent),view=normalize(cam-vTip);
  vec3 root=vec3(.012,.008,.005),tip=mix(vec3(.045,.029,.017),vec3(.095,.066,.036),vSeed.x);
  vec3 base=mix(root,tip,smoothstep(0.0,.9,vAlong))*${tint};
  // unpigmented (grey / white) strands, a little yellowed toward the root
  vec3 white=mix(vec3(.30,.29,.27),vec3(.62,.61,.58),fract(vSeed.x*13.7))*${grey};
  base=mix(base,white*mix(vec3(.92,.88,.8),vec3(1.0),smoothstep(.0,.6,vAlong)),vGrey);
  float light=.58+.80*sqrt(max(0.0,1.0-pow(dot(tangent,lA),2.0)));
  vec3 halfA=normalize(view+lA),halfB=normalize(view+lB);
  // a broad sheen and a bright rim, as under a barber's ring light, so dark hair reads on dark skin;
  // light hair already reads and keeps its normal sheen
  float lf=uLift*(1.0-smoothstep(.03,.14,dot(base,vec3(.3,.59,.11))));
  float glint=pow(sqrt(max(0.0,1.0-pow(dot(tangent,halfA),2.0))),mix(65.0,42.0,lf))*mix(.08,.14,vGrey)*(1.0+.6*lf);
  float rim=pow(sqrt(max(0.0,1.0-pow(dot(tangent,halfB),2.0))),mix(45.0,32.0,lf))*.04*(1.0+1.5*lf);
  // the hair's own colour is lifted (a warm brown-black, not white highlights, which read as grey)
  vec3 lit=base*light*(1.0+2.2*lf)+vec3(1.0,.86,.66)*(glint+rim)*smoothstep(.05,.6,vAlong);
  gl_FragColor=vec4(lit,1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
 }`;

  HSC.glsl.strandVert = (t) => t + `
 attribute vec3 aRoot,aNormal,aSeed;
 uniform vec3 cam;uniform float uWidth;
 uniform vec4 uStyleA,uStyleB,uStyleC,uGreyA,uGreyB;
 varying vec3 vRoot,vTip,vTangent,vSeed;varying float vAlong,vEdge,vLength,vGrey;
 void main(){
  float HANG=uStyleA.x,FWD=uStyleA.y,LIFT=uStyleA.z,TOPLIFT=uStyleA.w,SPREAD=uStyleB.x,SAG=uStyleB.y,WAVE=uStyleB.z,WAVEF=uStyleB.w;
  vec3 n=normalize(aNormal);
  vec3 down=vec3(0.0,-1.0,0.0);down-=n*dot(down,n);
  // at the very top of the head "down along the surface" vanishes; fall back to a fixed backward direction
  vec3 back=vec3(0.0,0.0,-1.0);back-=n*dot(back,n);
  down=normalize(mix(back,down,smoothstep(.12,.5,length(down)))+vec3(.0001));
  vec3 fwd=vec3(0.0,.25,1.0);fwd-=n*dot(fwd,n);fwd=normalize(fwd+vec3(.0001));
  // combed flow: the top lies forward, the back and sides fall down; strands scatter where the two meet
  float topW=smoothstep(3.05,3.75,aRoot.y)*smoothstep(-1.1,.2,aRoot.z);
  vec3 flow=normalize(mix(down,fwd,topW)+vec3(.0001));
  vec3 tA=normalize(cross(n,flow)+vec3(.0001));
  float g=gridValue(aRoot),hm=hairMask(aRoot);
  float stock=smoothstep(.80,1.0,g);
  float top=smoothstep(3.22,3.62,aRoot.y);
  float crown=1.0-smoothstep(.0,.42,distance(aRoot,vec3(.12,3.65,-.55)));
  float L0=${(16 / 42).toFixed(6)};
  float jitter=1.0+(aSeed.x-.5)*mix(.08,.24,stock);
  float ragged=mix(.72+.38*aSeed.y,1.0,smoothstep(.55,.98,hm));
  float L=g*L0*hm*mix(1.0,jitter*ragged,stock)*uStyleC.z;
  float shortHair=1.0-smoothstep(.10,.45,g);
  float hang=(1.0-smoothstep(2.7,3.65,aRoot.y))*HANG;
  flow=normalize(mix(flow,down,hang));
  flow=normalize(mix(flow,fwd,top*FWD));
  float lift=mix(LIFT,.95,shortHair);
  lift=mix(lift,TOPLIFT,top);
  float scatter=clamp(4.0*topW*(1.0-topW),0.0,1.0);
  float spinA=(aSeed.x-.5)*6.2831*scatter*scatter*(3.0-2.0*scatter);
  // curly and coily hair has no combed direction: every strand turns its own way
  spinA+=(aSeed.x-.5)*6.2831*smoothstep(.0,.15,uStyleC.x);
  flow=normalize(flow*cos(spinA)+tA*sin(spinA));
  tA=normalize(cross(n,flow)+vec3(.0001));
  lift=mix(lift,.42,max(crown,scatter)*.7*(1.0-smoothstep(.0,.15,uStyleC.x)));
  vec3 dir=normalize(n*lift+flow*(1.0-lift*.75)+tA*(aSeed.z-.5)*SPREAD+flow*(aSeed.y-.5)*SPREAD*.6);
  float t=position.y;
  float sag=SAG*t*clamp(L/L0,0.0,1.6);
  vec3 curve=normalize(dir+flow*(.10*t)+down*sag);
  float wave=sin(t*6.2831*WAVEF+aSeed.x*6.2831)*WAVE*t;
  vec3 p=aRoot+n*.002+curve*(t*L)+tA*wave*L;
  // coils: a helix around the strand's path, opening up from the root
  vec3 b2=normalize(cross(curve,tA)+vec3(.0001));
  float coilR=uStyleC.x*L*(.75+.5*aSeed.z)*smoothstep(.0,.18,t);
  float ph=t*uStyleC.y*(.8+.4*aSeed.y)*6.2831+aSeed.x*6.2831;
  p+=(tA*cos(ph)+b2*sin(ph))*coilR;
  vec3 tang=normalize(curve*L+(-tA*sin(ph)+b2*cos(ph))*coilR*uStyleC.y*6.2831+vec3(.00001));
  vec3 view=normalize(cam-p),side=cross(tang,view);
  if(dot(side,side)<.00001)side=cross(tang,vec3(0.0,1.0,.001));side=normalize(side);
  float radius=.0062*uWidth*uStyleC.w*(.82+.36*aSeed.y)*mix(1.0,.28,pow(t,2.0));
  float facing=abs(dot(n,normalize(cam-aRoot)));
  radius*=mix(1.0,smoothstep(.04,.40,facing),shortHair);
  p+=side*position.x*radius;
  // greying starts at the temples and sides
  // where greying starts depends on the person: temples, frontal hairline, crown, or evenly (salt and pepper)
  float gTemple=smoothstep(1.1,1.6,abs(aRoot.x))*(1.0-smoothstep(2.9,3.5,aRoot.y));
  float gFront=smoothstep(.6,1.6,aRoot.z)*smoothstep(2.6,3.2,aRoot.y);
  float gCrown=(1.0-smoothstep(-.9,-.2,aRoot.z))*smoothstep(2.6,3.4,aRoot.y);
  float gBias=dot(uGreyB.xyz,vec3(gTemple,gFront,gCrown))-uGreyB.w;
  float gf=clamp(uGreyA.x*(1.0+gBias*(1.0-uGreyA.x)*1.6),0.0,1.0);
  vGrey=step(fract(aSeed.z*7.31+aSeed.x*3.17),gf);
  vRoot=aRoot;vTip=p;vTangent=tang;vSeed=aSeed;vAlong=t;vEdge=position.x;vLength=L;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);
 }`;
  HSC.glsl.strandFrag = (t) => strandFrag(t, 'uHairTint', 'uGreyA.z');

  HSC.glsl.beardVert = (t) => t + `
 attribute vec3 aRoot,aNormal,aSeed,aBase;
 uniform vec3 cam;uniform float uWidth;
 uniform vec4 uBStyleA,uBStyleB,uBeardGrey,uBeardGreyB;
 uniform float uBeardLip;
 varying vec3 vRoot,vTip,vTangent,vSeed;varying float vAlong,vEdge,vLength,vGrey;
 void main(){
  vec3 n=normalize(aNormal);
  vec3 B=aBase;float ax=abs(B.x);
  float mm=beardMM(B)*smoothstep(.05,.35,beardZone(B));
  // patchy growth on the cheeks and neck for lighter beards
  float cheekW=smoothstep(.45,.9,atan(ax,B.z-.25))*(1.0-smoothstep(-.2,.2,B.y-.9*(1.0-smoothstep(.0,1.0,ax))));
  float ptch=smoothstep(uBeardGrey.z-.15,uBeardGrey.z+.15,n3(B*3.4+aSeed.z*.3)+(1.0-cheekW)*.35);
  float keep=mix(1.0,ptch,uBeardGrey.z>.01?1.0:0.0)*areataKeep(B);
  float L=mm/42.0*(.82+.36*aSeed.x)*uBStyleB.z*keep;
  // growth direction: down the face; outward on the moustache; down the neck under the jaw
  vec3 down=vec3(0.0,-1.0,0.0);down-=n*dot(down,n);
  vec3 outw=vec3(sign(B.x),-.9,.0);outw-=n*dot(outw,n);
  float must=smoothstep(.15,.3,B.y)*(1.0-smoothstep(.5,.62,B.y))*(1.0-smoothstep(.55,.85,ax));
  // in front of the ear (sideburn and back of the jaw) beard hair grows straight down and a little
  // forward along the jaw, toward the chin; it never sweeps back toward the ear
  float rear=smoothstep(.8,1.3,atan(ax,B.z-.25));
  vec3 fd=vec3(0.0,-1.0,.4);fd-=n*dot(fd,n);
  vec3 flow=normalize(mix(mix(down,outw,must*.55),normalize(fd+vec3(.0001)),rear)+vec3(.0001));
  vec3 tA=normalize(cross(n,flow)+vec3(.0001));
  float spin=((aSeed.y-.5)*.9+(aSeed.x-.5)*6.2831*smoothstep(.0,.15,uBStyleB.x))*(1.0-.8*rear);
  flow=normalize(flow*cos(spin)+tA*sin(spin));
  // nothing points backward there
  flow.z=mix(flow.z,max(flow.z,.08),rear);flow-=n*dot(flow,n);flow=normalize(flow+vec3(.0001));
  tA=normalize(cross(n,flow)+vec3(.0001));
  // short stubble stands up; longer hair lies down and starts to hang, closest to the face by the ear
  float lift=mix(.85,uBStyleA.z,smoothstep(1.0,8.0,mm));
  lift=mix(lift,min(lift,.24),rear*smoothstep(2.0,6.0,mm));
  // around the mouth: the mouth line (in un-morphed head coordinates) and how close this root is to it
  float yMouth=.125-.07*B.x*B.x;
  float mouthW=(1.0-smoothstep(.62,.8,ax))*smoothstep(1.55,1.85,B.z);
  float above=step(yMouth,B.y)*mouthW;
  float below=(1.0-step(yMouth,B.y))*mouthW*(1.0-smoothstep(.12,.45,yMouth-B.y));
  // beside the mouth corners hair grows down and outward, away from the mouth
  float cornerW=(1.0-smoothstep(.16,.42,length(vec3(ax-.66,B.y-.095,(B.z-1.95)*.6))))*smoothstep(1.4,1.75,B.z);
  vec3 od=vec3(sign(B.x)*.75,-1.0,-.1);od-=n*dot(od,n);
  flow=normalize(mix(flow,normalize(od+vec3(.0001)),cornerW));
  tA=normalize(cross(n,flow)+vec3(.0001));
  // moustache hair is combed down to lie along the upper lip
  lift=mix(lift,min(lift,.2),above*smoothstep(2.0,6.0,mm));
  vec3 dir=normalize(n*lift+flow*(1.0-lift*.7)+tA*(aSeed.z-.5)*.3);
  float t=position.y;
  float sagK=max(uBStyleA.w,.3*rear)*smoothstep(6.0,30.0,mm);
  // hair just under the lower lip grows down, away from the mouth
  dir=normalize(mix(dir,vec3(dir.x,min(dir.y,-.55),dir.z),below));
  vec3 curve=normalize(dir+vec3(0.0,-1.0,0.0)*sagK*t);
  // a moustache stops at its trimmed line on the upper lip and never reaches into the mouth:
  // cap the strand so its tip (where it hangs lowest, at t = 1) stays above that line
  vec3 tipDir=normalize(dir+vec3(0.0,-1.0,0.0)*sagK);
  float lipTop=yMouth+.27-.13*B.x*B.x;
  float yEnd=mix(lipTop,yMouth+.03,uBeardLip);
  float fall=max(.2,-tipDir.y);
  float Lcap=max(0.0,(B.y-yEnd)/fall);
  L=mix(L,min(L,Lcap),above);
  float wave=sin(t*6.2831*uBStyleA.y*(1.0+mm/15.0)+aSeed.x*6.2831)*uBStyleA.x*t;
  vec3 p=aRoot+n*.002+curve*(t*L)+tA*wave*L;
  vec3 b2=normalize(cross(curve,tA)+vec3(.0001));
  float coilR=uBStyleB.x*L*(.7+.6*aSeed.z)*smoothstep(.0,.2,t)*(1.0-.75*max(max(above,below),cornerW));
  float ph=t*uBStyleB.y*(.8+.4*aSeed.y)*6.2831+aSeed.x*6.2831;
  p+=(tA*cos(ph)+b2*sin(ph))*coilR;
  vec3 tang=normalize(curve*L+(-tA*sin(ph)+b2*cos(ph))*coilR*uBStyleB.y*6.2831+vec3(.00001));
  vec3 view=normalize(cam-p),side=cross(tang,view);
  if(dot(side,side)<.00001)side=cross(tang,vec3(0.0,1.0,.001));side=normalize(side);
  float radius=.0058*uWidth*uBStyleB.w*(.82+.36*aSeed.y)*mix(1.0,.3,pow(t,2.0));
  float facing=abs(dot(n,normalize(cam-aRoot)));
  radius*=mix(1.0,smoothstep(.04,.4,facing),1.0-smoothstep(1.5,5.0,mm));
  p+=side*position.x*radius;
  // the chin greys first
  // the beard greys chin first, sides first, or evenly
  float bChin=(1.0-smoothstep(.2,.6,ax))*(1.0-must);
  float bSides=smoothstep(.7,1.2,ax);
  float bBias=dot(uBeardGreyB.xyz,vec3(bChin,bSides,must))-uBeardGreyB.w;
  float bgf=clamp(uBeardGrey.x*(1.0+bBias*(1.0-uBeardGrey.x)*1.6),0.0,1.0);
  vGrey=step(fract(aSeed.z*7.31+aSeed.x*3.17),bgf);
  vRoot=aRoot;vTip=p;vTangent=tang;vSeed=aSeed;vAlong=t;vEdge=position.x;vLength=L;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);
 }`;
  HSC.glsl.beardFrag = (t) => strandFrag(t, 'uHairTint*uBeardTint', 'uBeardGrey.y');
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// CPU-side face geometry: the beard grid (mirrors the shader's beardUV / beardZone exactly), the
// beard's per-cell surface positions, beard strand roots, and per-customer face-shape morphs.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const { clamp, smooth } = HSC;
  const { BC, AZR, EL0, ELR } = HSC.BEARD_PROJ;

  // beard length levels (mm); state.beard stores indices into this table
  const BEARD_MM = [0, 0.5, 1, 1.5, 2, 3, 4.5, 6, 8, 10, 13, 16, 20, 25, 30, 40, 50];
  const GUARD_MM = { 0: 0.5, 1: 3, 2: 6, 3: 10, 4: 13 };
  const levelOf = (mm) => {
    let best = 0;
    for (let i = 0; i < BEARD_MM.length; i++) if (Math.abs(BEARD_MM[i] - mm) < Math.abs(BEARD_MM[best] - mm)) best = i;
    return best;
  };
  const GUARD_LEVEL = Object.fromEntries(Object.entries(GUARD_MM).map(([g, mm]) => [g, levelOf(mm)]));

  function beardUV(x, y, z) {
    const dx = x - BC[0], dy = y - BC[1], dz = z - BC[2];
    const az = Math.atan2(dx, dz), el = Math.atan2(dy, Math.hypot(dx, dz));
    return [az / (2 * AZR) + 0.5, (el - EL0) / ELR];
  }
  function beardCell(x, y, z) {
    const [u, v] = beardUV(x, y, z);
    if (!(u >= 0 && u <= 1 && v >= 0 && v <= 1)) return -1;
    return Math.min(63, Math.floor(v * 64)) * 128 + Math.min(127, Math.floor(u * 128));
  }
  function lipMask(x, y, z) {
    const ax = Math.abs(x), ly = y - 0.125;
    const lipW = 1 - smooth(0.55, 0.72, ax);
    const upL = (1 - smooth(0.55, 0.95, Math.hypot(x / 0.66, (ly - 0.12) / 0.15))) * (ly >= 0 ? 1 : 0);
    const loL = (1 - smooth(0.55, 0.95, Math.hypot(x / 0.62, (ly + 0.13) / 0.21))) * (ly <= 0 ? 1 : 0);
    return Math.max(upL, loL) * smooth(1.8, 2.2, z) * lipW;
  }
  function beardZone(x, y, z) {
    const ax = Math.abs(x);
    const ang = Math.atan2(ax, z - 0.25);
    const yTop = 0.53 + (1.45 - 0.53) * smooth(0.3, 1.45, ang);
    const yBot = -1.22 + (-0.8 + 1.22) * smooth(0.85, 1.6, ang);
    let m = smooth(yBot - 0.04, yBot + 0.08, y) * (1 - smooth(yTop - 0.08, yTop + 0.03, y));
    m *= 1 - smooth(1.5, 1.64, ang);
    m *= 1 - smooth(0.15, 0.5, lipMask(x, y, z));
    return m;
  }

  // beard style regions, from the cell's (un-morphed) position
  function beardRegion(x, y, z, person) {
    const ax = Math.abs(x);
    const ang = Math.atan2(ax, z - 0.25);
    const cheekShift = 0.1 * (person.beard.cheekLine || 0);
    const neckShift = 0.1 * (person.beard.neckLine || 0);
    const jawY = -0.92 + 0.42 * smooth(0.5, 1.5, ang);
    if (y < -1.22 + 0.42 * smooth(0.85, 1.6, ang) + 0.12 + neckShift * (1 - smooth(0.6, 1.3, ang))) return null; // below the neckline
    const rag = 0.05 * Math.sin(x * 23.1 + y * 7.3) + 0.04 * Math.sin(z * 31.7 - x * 11.9);
    const yTop = 0.53 + 0.92 * smooth(0.3, 1.45, ang) + cheekShift * smooth(0.4, 1.2, ang) * (ang > 0.5 ? 1 : 0) + rag * smooth(0.4, 0.9, ang);
    if (y > yTop) return null;
    if (y > 0.26 && ax < 0.8 && ang < 0.65) return 'moustache';
    if (ax < 0.5 && y < 0.02 && z > 0.9 && y > jawY - 0.3) return 'chin';
    if (y < jawY - 0.12) return 'neck';
    if (Math.abs(y - jawY) < 0.2) return 'jaw';
    return 'cheeks';
  }

  // ---------------- geometry helpers ----------------
  function canonIds(P) {
    const ids = new Map(), canon = new Int32Array(P.length / 3);
    for (let v = 0; v < canon.length; v++) {
      const k = Math.round(P[v * 3] * 1e4) + ',' + Math.round(P[v * 3 + 1] * 1e4) + ',' + Math.round(P[v * 3 + 2] * 1e4);
      let c = ids.get(k);
      if (c === undefined) ids.set(k, (c = ids.size));
      canon[v] = c;
    }
    return { canon, count: ids.size };
  }
  function areaNormals(P, I, canon, count) {
    const acc = new Float32Array(count * 3);
    for (let k = 0; k < I.length; k += 3) {
      const a = I[k] * 3, b = I[k + 1] * 3, c = I[k + 2] * 3;
      const e1x = P[b] - P[a], e1y = P[b + 1] - P[a + 1], e1z = P[b + 2] - P[a + 2];
      const e2x = P[c] - P[a], e2y = P[c + 1] - P[a + 1], e2z = P[c + 2] - P[a + 2];
      const nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
      for (const v of [I[k], I[k + 1], I[k + 2]]) {
        const o = canon[v] * 3;
        acc[o] += nx; acc[o + 1] += ny; acc[o + 2] += nz;
      }
    }
    for (let o = 0; o < acc.length; o += 3) {
      const l = Math.hypot(acc[o], acc[o + 1], acc[o + 2]) || 1;
      acc[o] /= l; acc[o + 1] /= l; acc[o + 2] /= l;
    }
    return acc;
  }

  // ---------------- face-shape morphs ----------------
  const eyeC = [0.628, 1.624, 1.627];
  const G = (x, y, z, c, r) => {
    const a = (x - c[0]) / r[0], b = (y - c[1]) / r[1], d = (z - c[2]) / r[2];
    return Math.exp(-(a * a + b * b + d * d));
  };
  // displacement of a base-mesh point for a customer; zero on the scalp, around the eyeballs and on the neck
  function morphDelta(x, y, z, m, age, scalp) {
    const ax = Math.abs(x), sx = x < 0 ? -1 : 1;
    const guard =
      (1 - smooth(0.0, 0.03, scalp)) *
      smooth(0.37, 0.5, Math.hypot(ax - eyeC[0], y - eyeC[1], z - eyeC[2])) *
      smooth(-1.6, -1.2, y);
    if (guard <= 0) return null;
    let dx = 0, dy = 0, dz = 0, g;
    g = G(ax, y, z, [0, 0.7, 2.35], [0.42, 0.3, 0.36]); dx += x * 0.32 * m.noseW * g;
    g = G(ax, y, z, [0, 1.25, 2.4], [0.18, 0.38, 0.35]); dz += 0.08 * m.noseBridge * g;
    g = G(ax, y, z, [0, 0.82, 2.6], [0.2, 0.18, 0.25]); dz += 0.06 * m.noseTip * g; dy -= 0.025 * m.noseTip * g;
    g = G(ax, y, z, [0, 0.12, 2.2], [0.62, 0.25, 0.3]); dz += 0.05 * m.lips * g; dy += (y - 0.125) * 0.3 * m.lips * g;
    g = G(ax, y, z, [1.05, -0.35, 1.0], [0.55, 0.55, 0.8]); dx += x * 0.1 * m.jaw * g;
    g = G(ax, y, z, [0, -0.72, 1.95], [0.42, 0.32, 0.42]); dz += 0.09 * m.chin * g; dy -= 0.035 * m.chin * g;
    g = G(ax, y, z, [1.15, 1.15, 1.65], [0.38, 0.32, 0.42]); dx += sx * 0.065 * m.cheek * g; dz += 0.03 * m.cheek * g;
    g = G(ax, y, z, [0.6, 2.05, 2.05], [0.5, 0.13, 0.25]); dz += 0.045 * m.brow * g;
    // age: jowls and under-eye bags
    const a2 = age * age;
    g = G(ax, y, z, [0.95, -0.5, 1.55], [0.35, 0.28, 0.4]); dy -= 0.07 * a2 * g; dx += sx * 0.03 * a2 * g;
    g = G(ax, y, z, [0.62, 1.3, 1.98], [0.22, 0.07, 0.18]); dz += 0.025 * a2 * g;
    if (!dx && !dy && !dz) return null;
    return [dx * guard, dy * guard, dz * guard];
  }

  // ---------------- beard surface (built once on the un-morphed head) ----------------
  // Cells are a linear combination of mesh vertices, so after a morph each cell's position is
  // recomputed cheaply. Only the outermost surface counts: the mesh also has a closed mouth cavity.
  function buildBeardSurface(P, I) {
    const tris = [];
    for (let k = 0; k < I.length; k += 3) {
      const vs = [I[k], I[k + 1], I[k + 2]];
      if (vs.some((v) => beardZone(P[v * 3], P[v * 3 + 1], P[v * 3 + 2]) > 0.01)) tris.push(k);
    }
    const samples = [];
    const maxR = new Float32Array(8192);
    const radius = (x, y, z) => Math.hypot(x - BC[0], y - BC[1], z - BC[2]);
    for (const k of tris) {
      const a = I[k], b = I[k + 1], c = I[k + 2];
      const pa = [P[a * 3], P[a * 3 + 1], P[a * 3 + 2]], pb = [P[b * 3], P[b * 3 + 1], P[b * 3 + 2]], pc = [P[c * 3], P[c * 3 + 1], P[c * 3 + 2]];
      const edge = Math.max(Math.hypot(pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]), Math.hypot(pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]), Math.hypot(pc[0] - pb[0], pc[1] - pb[1], pc[2] - pb[2]));
      const n = Math.max(2, Math.min(12, Math.ceil(edge / 0.03)));
      for (let i = 0; i <= n; i++) for (let j = 0; j <= n - i; j++) {
        const wa = 1 - (i + j) / n, wb = i / n, wc = j / n;
        const x = pa[0] * wa + pb[0] * wb + pc[0] * wc, y = pa[1] * wa + pb[1] * wb + pc[1] * wc, z = pa[2] * wa + pb[2] * wb + pc[2] * wc;
        if (beardZone(x, y, z) < 0.02) continue;
        const cell = beardCell(x, y, z);
        if (cell < 0) continue;
        const r = radius(x, y, z);
        if (r > maxR[cell]) maxR[cell] = r;
        samples.push(cell, r, a, b, c, wa, wb, wc);
      }
    }
    // gather outermost samples per cell as vertex weights
    const lists = Array.from({ length: 8192 }, () => new Map());
    for (let s = 0; s < samples.length; s += 8) {
      const cell = samples[s];
      if (samples[s + 1] < maxR[cell] - 0.07) continue;
      const m = lists[cell];
      for (let q = 0; q < 3; q++) m.set(samples[s + 2 + q], (m.get(samples[s + 2 + q]) || 0) + samples[s + 5 + q]);
    }
    // index triangles by the grid cells they cover, so each gap-filling ray tests only a few
    const bins = new Map();
    for (const k of tris) {
      let u0 = 1e9, u1 = -1e9, v0 = 1e9, v1 = -1e9;
      for (let q = 0; q < 3; q++) {
        const v = I[k + q] * 3, [u, w] = beardUV(P[v], P[v + 1], P[v + 2]);
        u0 = Math.min(u0, u); u1 = Math.max(u1, u); v0 = Math.min(v0, w); v1 = Math.max(v1, w);
      }
      if (u1 - u0 > 0.5) continue; // wraps around behind the projection centre: never part of the beard
      const cx0 = Math.max(0, Math.floor(u0 * 128) - 1), cx1 = Math.min(127, Math.floor(u1 * 128) + 1);
      const cy0 = Math.max(0, Math.floor(v0 * 64) - 1), cy1 = Math.min(63, Math.floor(v1 * 64) + 1);
      for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) {
        const c = cy * 128 + cx;
        let l = bins.get(c);
        if (!l) bins.set(c, (l = []));
        l.push(k);
      }
    }
    // cells too small to catch a sample: cast a ray from the projection centre, keep the farthest hit
    const filled = lists.map((m) => m.size > 0), tried = new Uint8Array(8192);
    for (let pass = 0, grew = true; grew && pass < 6; pass++) {
      grew = false;
      const next = filled.slice();
      for (let cell = 0; cell < 8192; cell++) {
        if (filled[cell] || tried[cell]) continue;
        const cx = cell & 127, cy = cell >> 7;
        let nb = false;
        for (let dy = -1; dy <= 1 && !nb; dy++) for (let dx = -1; dx <= 1; dx++) {
          const yy = cy + dy, xx = cx + dx;
          if (yy >= 0 && yy < 64 && xx >= 0 && xx < 128 && filled[yy * 128 + xx]) { nb = true; break; }
        }
        if (!nb) continue;
        tried[cell] = 1;
        const az = ((cx + 0.5) / 128 - 0.5) * 2 * AZR, el = (cy + 0.5) / 64 * ELR + EL0;
        const d = [Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el)];
        let best = -1, hit = null;
        for (const k of bins.get(cell) || []) {
          const a = I[k] * 3, b = I[k + 1] * 3, c = I[k + 2] * 3;
          const e1 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], e2 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
          const px = d[1] * e2[2] - d[2] * e2[1], py = d[2] * e2[0] - d[0] * e2[2], pz = d[0] * e2[1] - d[1] * e2[0];
          const det = e1[0] * px + e1[1] * py + e1[2] * pz;
          if (Math.abs(det) < 1e-9) continue;
          const iv = 1 / det, tx = BC[0] - P[a], ty = BC[1] - P[a + 1], tz = BC[2] - P[a + 2];
          const u = (tx * px + ty * py + tz * pz) * iv;
          if (u < 0 || u > 1) continue;
          const qx = ty * e1[2] - tz * e1[1], qy = tz * e1[0] - tx * e1[2], qz = tx * e1[1] - ty * e1[0];
          const v = (d[0] * qx + d[1] * qy + d[2] * qz) * iv;
          if (v < 0 || u + v > 1) continue;
          const t = (e2[0] * qx + e2[1] * qy + e2[2] * qz) * iv;
          if (t > best) { best = t; hit = [k, 1 - u - v, u, v]; }
        }
        if (!hit) continue;
        const [k, wa, wb, wc] = hit;
        const hx = BC[0] + d[0] * best, hy = BC[1] + d[1] * best, hz = BC[2] + d[2] * best;
        if (beardZone(hx, hy, hz) < 0.02) continue;
        const m = lists[cell];
        m.set(I[k], (m.get(I[k]) || 0) + wa); m.set(I[k + 1], (m.get(I[k + 1]) || 0) + wb); m.set(I[k + 2], (m.get(I[k + 2]) || 0) + wc);
        maxR[cell] = Math.max(maxR[cell], best);
        next[cell] = true;
        grew = true;
      }
      for (let c = 0; c < 8192; c++) filled[c] = next[c];
    }
    // flatten
    const offs = new Int32Array(8193), verts = [], wts = [];
    for (let c = 0; c < 8192; c++) {
      offs[c] = verts.length;
      let tot = 0;
      for (const w of lists[c].values()) tot += w;
      for (const [v, w] of lists[c]) { verts.push(v); wts.push(w / tot); }
    }
    offs[8192] = verts.length;
    return { tris, maxR, offs, verts: Int32Array.from(verts), wts: Float32Array.from(wts) };
  }

  // positions of all beard cells for the current (possibly morphed) vertex positions
  function beardCellPositions(S, P) {
    const pos = new Float32Array(8192 * 3), has = new Uint8Array(8192);
    for (let c = 0; c < 8192; c++) {
      if (S.offs[c] === S.offs[c + 1]) continue;
      has[c] = 1;
      for (let i = S.offs[c]; i < S.offs[c + 1]; i++) {
        const v = S.verts[i] * 3, w = S.wts[i];
        pos[c * 3] += P[v] * w; pos[c * 3 + 1] += P[v + 1] * w; pos[c * 3 + 2] += P[v + 2] * w;
      }
    }
    // spatial buckets for the clipper
    const size = 0.22, buckets = new Map();
    for (let c = 0; c < 8192; c++) {
      if (!has[c]) continue;
      const k = Math.floor(pos[c * 3] / size) + ',' + Math.floor(pos[c * 3 + 1] / size) + ',' + Math.floor(pos[c * 3 + 2] / size);
      let l = buckets.get(k);
      if (!l) buckets.set(k, (l = []));
      l.push(c);
    }
    return { positions: pos, has, spatial: { size, buckets } };
  }

  // beard strand roots: fixed (triangle, barycentric) picks on the outer beard area
  function sampleBeardRoots(P, I, S, count, seed) {
    const R = HSC.rng(seed);
    const areas = [];
    let total = 0;
    for (const k of S.tris) {
      const a = I[k] * 3, b = I[k + 1] * 3, c = I[k + 2] * 3;
      const e1 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], e2 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]];
      total += 0.5 * Math.hypot(e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]);
      areas.push(total);
    }
    const tri = new Int32Array(count * 3), bary = new Float32Array(count * 3), base = new Float32Array(count * 3);
    let made = 0, guard = 0;
    while (made < count && guard++ < count * 40) {
      const x = R.next() * total;
      let lo = 0, hi = areas.length - 1;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (areas[mid] < x) lo = mid + 1; else hi = mid; }
      const k = S.tris[lo];
      const r1 = Math.sqrt(R.next()), r2 = R.next();
      const w = [1 - r1, r1 * (1 - r2), r1 * r2];
      const vs = [I[k], I[k + 1], I[k + 2]];
      const p = [0, 1, 2].map((q) => vs.reduce((s, v, j) => s + P[v * 3 + q] * w[j], 0));
      if (beardZone(...p) < 0.06) continue;
      const cell = beardCell(...p);
      if (cell < 0 || Math.hypot(p[0] - BC[0], p[1] - BC[1], p[2] - BC[2]) < S.maxR[cell] - 0.07) continue;
      tri.set(vs, made * 3); bary.set(w, made * 3); base.set(p, made * 3);
      made++;
    }
    return { count: made, tri, bary, base };
  }

  // the starting beard (length levels per cell) for a customer
  function beardStart(person, S, P) {
    const out = new Array(8192).fill(0);
    if (!S || !person) return out;
    const mm = person.beard.mm || {};
    const style = HSC.BEARD_STYLES[person.beard.style] || {};
    if (!Object.keys(mm).length) return out;
    const cells = beardCellPositions(S, P).positions;
    const raw = new Float32Array(8192);
    for (let c = 0; c < 8192; c++) {
      if (S.offs[c] === S.offs[c + 1]) continue;
      const x = cells[c * 3], y = cells[c * 3 + 1], z = cells[c * 3 + 2];
      if (beardZone(x, y, z) < 0.05) continue;
      let region = beardRegion(x, y, z, person);
      // horseshoe: the moustache runs down past the mouth corners to the jaw
      if (style.horseshoe && region && region !== 'moustache' && region !== 'neck') {
        const ax = Math.abs(x), jawY = -0.92 + 0.42 * smooth(0.5, 1.5, Math.atan2(ax, z - 0.25));
        if (ax > 0.46 && ax < 0.74 && y < 0.3 && y > jawY - 0.02 && z > 1.2) region = 'moustache';
      }
      if (!region) continue;
      // pencil: a thin line just above the lip
      if (style.pencil && region === 'moustache' && (y > 0.37 || Math.abs(x) > 0.62)) continue;
      // a van dyke keeps the chin tuft separate from the moustache
      if (style.chinOnly && region === 'chin' && Math.abs(x) > 0.36) continue;
      // jaw/chin-only styles let a chin region borrow the jaw length and vice versa
      let v = mm[region];
      if (v == null && region === 'jaw' && mm.cheeks) v = mm.cheeks;
      if (v == null && region === 'neck' && person.beard.style === 'chinstrap') v = null;
      if (v == null) continue;
      raw[c] = v;
    }
    // soften length steps between regions (not the outer edges)
    for (let it = 0; it < 2; it++) {
      const src = raw.slice();
      for (let c = 0; c < 8192; c++) {
        if (!src[c]) continue;
        const cx = c & 127, cy = c >> 7;
        let s = 0, n = 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const yy = cy + dy, xx = cx + dx;
          if (yy < 0 || yy > 63 || xx < 0 || xx > 127) continue;
          const v = src[yy * 128 + xx];
          if (v) { s += v; n++; }
        }
        raw[c] = s / n;
      }
    }
    for (let c = 0; c < 8192; c++) if (raw[c] > 0) out[c] = Math.max(1, levelOf(raw[c]));
    return out;
  }

  Object.assign(HSC, {
    BEARD_MM, GUARD_LEVEL, beardUV, beardCell, beardZone, lipMask, beardRegion, canonIds, areaNormals, morphDelta,
    buildBeardSurface, beardCellPositions, sampleBeardRoots, beardStart,
  });
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Renderer glue: attaches to the game's head mesh and materials, then applies a customer.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const { clamp, smooth } = HSC;
  const LIFT = 0.6, EXPOSURE = 1.2;

  // the game's hair colour presets (uHairTint per colour index)
  const TINTS = [
    [0.3, 0.32, 0.38], [0.48, 0.48, 0.52], [0.72, 0.68, 0.64], [1, 1, 1], [1.55, 1.36, 1.16], [2.3, 1.95, 1.55],
    [3.1, 2.65, 1.95], [4, 3.35, 2.05], [5.1, 4.45, 3.1], [2.4, 1.25, 0.8], [4, 1.8, 0.75], [2.1, 3.15, 5.2],
  ];
  const STRAND_STYLE = {
    straight: (c) => ({ A: [0.22, 0.56, 0.56, 0.5], B: [0.16, 0.1, 0.02, 1], C: [0, 0, 1, 1] }),
    wavy: (c) => ({ A: [0.18, 0.4, 0.62, 0.6], B: [0.2, 0.08, 0.07 + 0.05 * c, 1.4 + 0.6 * c], C: [0, 0, 0.92, 1.05] }),
    curly: (c) => ({ A: [0.1, 0.2, 0.75, 0.8], B: [0.28, 0.04, 0, 1], C: [0.1 + 0.06 * c, 1.6 + 1.0 * c, 0.72 - 0.1 * c, 1.15] }),
    coily: (c) => ({ A: [0.03, 0.05, 0.9, 0.95], B: [0.36, 0, 0, 1], C: [0.16 + 0.08 * c, 3 + 2.5 * c, 0.5 - 0.08 * c, 1.35] }),
  };
  const BEARD_STYLE = {
    straight: { A: [0.04, 0.6, 0.45, 0.12], B: [0, 0, 1, 1] },
    wavy: { A: [0.07, 0.9, 0.5, 0.1], B: [0.03, 1.2, 0.95, 1.05] },
    curly: { A: [0, 1, 0.6, 0.05], B: [0.12, 1.8, 0.75, 1.1] },
    coily: { A: [0, 1, 0.75, 0.02], B: [0.2, 3.5, 0.55, 1.25] },
  };
  const lerp = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
  const mul = (a, b) => a.map((v, i) => v * b[i]);

  let ctx = null;
  const st = {};

  HSC.attach = function (c) {
    try {
      ctx = c;
      const T = c.T, Pt = c.Pt;
      const P = Pt.attributes.position.array;
      st.base = Float32Array.from(P);
      st.N0 = Float32Array.from(Pt.attributes.normal.array);
      st.coarse = Pt.userData.coarse;
      st.coarseBase = Float32Array.from(st.coarse.pos);
      Pt.setAttribute('hsBase', new T.It(st.base, 3));
      const ci = HSC.canonIds(st.base);
      st.canon = ci.canon; st.canonCount = ci.count;
      st.nBase = HSC.areaNormals(st.base, Pt.index.array, st.canon, st.canonCount);
      // scalp mask per vertex, to keep morphs off the scalp
      st.scalp = new Float32Array(P.length / 3);
      for (let v = 0; v < st.scalp.length; v++) st.scalp[v] = c.Na(P[v * 3], P[v * 3 + 1], P[v * 3 + 2]);
      st.scalpC = new Float32Array(st.coarseBase.length / 3);
      for (let v = 0; v < st.scalpC.length; v++) st.scalpC[v] = c.Na(st.coarseBase[v * 3], st.coarseBase[v * 3 + 1], st.coarseBase[v * 3 + 2]);

      // beard length grid texture
      st.beardData = new Uint8Array(8192);
      const tex = new T.uu(st.beardData, 128, 64, T.Jn, T.cr);
      tex.minFilter = tex.magFilter = T.or;
      tex.needsUpdate = true;
      st.beardTex = tex;
      HSC.U.uBeard.value = tex;

      // beard surface + strands
      st.surface = HSC.buildBeardSurface(st.base, Pt.index.array);
      st.roots = HSC.sampleBeardRoots(st.base, Pt.index.array, st.surface, 14000, 0xbea7d);
      st.beardCells = HSC.beardCellPositions(st.surface, st.base);
      HSC.beardSurface = st.beardCells;
      st.beardMesh = makeBeardMesh(c, st.roots);
      c.vt.add(st.beardMesh);
      try { HSC.attachClippings && HSC.attachClippings(c); } catch (err) { console.error('customers: clippings attach failed', err); }
      try { HSC.attachGown && c.robe && HSC.attachGown(c.robe, c.T); } catch (err) { console.error('customers: gown attach failed', err); }
      HSC.ready = true;
      try { HSC.onDetailChange(); } catch (err) { console.error('customers: detail apply failed', err); }
    } catch (err) {
      console.error('customers: attach failed', err);
      HSC.ready = false;
    }
  };

  function makeBeardMesh(c, roots) {
    const T = c.T, n = roots.count;
    const g = new T.af();
    const pos = [], idx = [];
    const SEG = 8;
    for (let s = 0; s <= SEG; s++) {
      pos.push(-1, s / SEG, 0, 1, s / SEG, 0);
      if (s < SEG) { const u = s * 2; idx.push(u, u + 1, u + 2, u + 1, u + 3, u + 2); }
    }
    g.setAttribute('position', new T.mt(pos, 3));
    g.setIndex(idx);
    st.aRoot = new Float32Array(n * 3);
    st.aNormal = new Float32Array(n * 3);
    const seeds = new Float32Array(n * 3), R = HSC.rng(911);
    for (let i = 0; i < n * 3; i++) seeds[i] = R.next();
    g.setAttribute('aRoot', new T.Ra(st.aRoot, 3));
    g.setAttribute('aNormal', new T.Ra(st.aNormal, 3));
    g.setAttribute('aBase', new T.Ra(roots.base.subarray(0, n * 3), 3));
    g.setAttribute('aSeed', new T.Ra(seeds, 3));
    g.instanceCount = n;
    updateRoots(st.base, st.N0);
    const mat = new T.fr({
      vertexShader: HSC.glsl.beardVert(c.Ql),
      fragmentShader: HSC.glsl.beardFrag(c.Ql),
      uniforms: Object.assign({ uGrid: c.uGrid, uHairTint: c.uHairTint, uDensity: c.uDensity, uWidth: { value: 1 } }, c.light, HSC.U),
      side: T.$t,
    });
    const mesh = new T.Ze(g, mat);
    mesh.frustumCulled = false;
    mesh.renderOrder = 1;
    mesh.visible = false;
    return mesh;
  }

  function updateRoots(P, N) {
    const r = st.roots;
    for (let i = 0; i < r.count; i++) {
      let nx = 0, ny = 0, nz = 0, x = 0, y = 0, z = 0;
      for (let j = 0; j < 3; j++) {
        const v = r.tri[i * 3 + j] * 3, w = r.bary[i * 3 + j];
        x += P[v] * w; y += P[v + 1] * w; z += P[v + 2] * w;
        nx += N[v] * w; ny += N[v + 1] * w; nz += N[v + 2] * w;
      }
      const l = Math.hypot(nx, ny, nz) || 1;
      st.aRoot.set([x, y, z], i * 3);
      st.aNormal.set([nx / l, ny / l, nz / l], i * 3);
    }
    if (st.beardMesh) {
      st.beardMesh.geometry.attributes.aRoot.needsUpdate = true;
      st.beardMesh.geometry.attributes.aNormal.needsUpdate = true;
    }
  }

  // ---- face-shape morph applied to the smooth mesh and the coarse picking mesh ----
  function applyMorph(person) {
    const Pt = ctx.Pt;
    const P = Pt.attributes.position.array, N = Pt.attributes.normal.array, I = Pt.index.array;
    const age = clamp((person.years - 18) / 62, 0, 1);
    const m = person.morph;
    let moved = false;
    for (let v = 0; v < P.length / 3; v++) {
      const x = st.base[v * 3], y = st.base[v * 3 + 1], z = st.base[v * 3 + 2];
      const d = HSC.morphDelta(x, y, z, m, age, st.scalp[v]);
      P[v * 3] = x + (d ? d[0] : 0); P[v * 3 + 1] = y + (d ? d[1] : 0); P[v * 3 + 2] = z + (d ? d[2] : 0);
      if (d) moved = true;
    }
    const C = st.coarse.pos;
    for (let v = 0; v < C.length / 3; v++) {
      const x = st.coarseBase[v * 3], y = st.coarseBase[v * 3 + 1], z = st.coarseBase[v * 3 + 2];
      const d = HSC.morphDelta(x, y, z, m, age, st.scalpC[v]);
      C[v * 3] = x + (d ? d[0] : 0); C[v * 3 + 1] = y + (d ? d[1] : 0); C[v * 3 + 2] = z + (d ? d[2] : 0);
    }
    // normals: the original (artist) normals plus the change the morph makes to the geometric normals
    if (moved) {
      const nm = HSC.areaNormals(P, I, st.canon, st.canonCount);
      for (let v = 0; v < N.length / 3; v++) {
        const c = st.canon[v] * 3;
        const x = st.N0[v * 3] + nm[c] - st.nBase[c], y = st.N0[v * 3 + 1] + nm[c + 1] - st.nBase[c + 1], z = st.N0[v * 3 + 2] + nm[c + 2] - st.nBase[c + 2];
        const l = Math.hypot(x, y, z) || 1;
        N[v * 3] = x / l; N[v * 3 + 1] = y / l; N[v * 3 + 2] = z / l;
      }
    } else N.set(st.N0);
    Pt.attributes.position.needsUpdate = true;
    Pt.attributes.normal.needsUpdate = true;
    Pt.computeBoundingSphere();
    updateRoots(P, N);
    st.beardCells = HSC.beardCellPositions(st.surface, P);
    HSC.beardSurface = st.beardCells;
  }

  // ---- iris texture ----
  function drawEyes(person) {
    const cv = ctx.eyeCanvas, tex = ctx.eyeTexture;
    if (!cv || !tex) return;
    const e = cv.getContext('2d');
    const R = HSC.rng(person.seed ^ 0x51ed);
    const stops = HSC.EYES[person.eyes] || HSC.EYES.blue;
    const old = person.years >= 60;
    e.setTransform(1, 0, 0, 1, 0, 0);
    e.scale(0.5, 0.5);
    e.fillStyle = old ? '#ebe1d0' : '#efe7e0';
    e.fillRect(0, 0, 2048, 1024);
    for (let o = 0; o < 70 + (old ? 40 : 0); o++) {
      const s = (R.next() < 0.5 ? 0.05 + R.next() * 0.12 : 0.38 + R.next() * 0.12) * 2048, l = (0.25 + R.next() * 0.5) * 1024;
      e.strokeStyle = `rgba(190,90,85,${0.05 + R.next() * 0.12})`;
      e.lineWidth = 1.5;
      e.beginPath(); e.moveTo(s, l);
      e.bezierCurveTo(s + 30, l + 20 * (R.next() - 0.5), s + 60, l + 40 * (R.next() - 0.5), s + 90 * (R.next() < 0.5 ? 1 : -1), l + 30 * (R.next() - 0.5));
      e.stroke();
    }
    const i = 150;
    e.save();
    e.translate(512, 512);
    e.scale(1, 300 / i);
    e.fillStyle = 'rgba(40,30,28,.28)';
    e.beginPath(); e.arc(0, 0, i * 1.08, 0, 7); e.fill();
    const gr = e.createRadialGradient(0, 0, 10, 0, 0, i);
    gr.addColorStop(0, '#060606'); gr.addColorStop(0.2, '#060606');
    gr.addColorStop(0.24, stops[0]); gr.addColorStop(0.5, stops[1]); gr.addColorStop(0.78, stops[2]); gr.addColorStop(0.93, stops[3]);
    gr.addColorStop(1, '#0b0b0b');
    e.fillStyle = gr;
    e.beginPath(); e.arc(0, 0, i, 0, 7); e.fill();
    const fib = stops[0].match(/\w\w/g).map((h) => parseInt(h, 16));
    for (let o = 0; o < 160; o++) {
      const s = R.next() * 6.283, l = i * (0.32 + R.next() * 0.1), cc = i * (0.62 + R.next() * 0.33);
      const k = 0.9 + R.next() * 0.35;
      e.strokeStyle = `rgba(${Math.min(255, fib[0] * k) | 0},${Math.min(255, fib[1] * k) | 0},${Math.min(255, fib[2] * k) | 0},${0.1 + R.next() * 0.22})`;
      e.lineWidth = 1.6;
      e.beginPath(); e.moveTo(Math.cos(s) * l, Math.sin(s) * l); e.lineTo(Math.cos(s) * cc, Math.sin(s) * cc); e.stroke();
    }
    if (old) {
      // arcus: a pale ring at the edge of the iris
      e.strokeStyle = 'rgba(215,215,205,.4)';
      e.lineWidth = 9;
      e.beginPath(); e.arc(0, 0, i * 0.95, 0, 7); e.stroke();
    }
    e.restore();
    tex.needsUpdate = true;
  }

  // ---- apply a customer ----
  HSC.setPerson = function (person) {
    if (!ctx || !HSC.validPerson(person)) return;
    const key = JSON.stringify(person);
    if (st.key === key) return;
    st.key = key;
    // a fresh customer sits down in a clean gown
    // (not while the reveal hub takes a snapshot of the next customer)
    if (!HSC.snapshotting && st.personSeed !== person.seed) { st.personSeed = person.seed; HSC.clearClippings && HSC.clearClippings(); }
    const U = HSC.U;
    const age = clamp((person.years - 18) / 62, 0, 1);
    const dark = clamp(person.skin.tone / 9.4, 0, 1);
    const skin = HSC.skinColour(person);
    U.uSkinA.value = [...skin, dark];
    // one bright, even light for every customer: bright enough that dark hair reads clearly on the
    // darkest skin, with a broad sheen on the strands (as under a barber's ring light)
    U.uLift.value = LIFT;
    HSC.setExposure && HSC.setExposure(EXPOSURE);
    U.uLip.value = lerp([1.06, 0.78, 0.93], [0.86, 0.7, 0.8], smooth(0.2, 0.8, dark));
    const tint = TINTS[person.hair.colour] || TINTS[1];
    const greyCol = [0.2, 0.2, 0.19];
    const hairDark = lerp(mul([0.035, 0.024, 0.018], tint), greyCol, person.hair.grey * 0.85);
    U.uHairDark.value = hairDark;
    // beards often grow in warmer than the scalp hair, visibly so only on brown, blond and red hair
    const warmable = person.hair.colour >= 3 && person.hair.colour <= 10 ? 1 : 0;
    const beardTint = lerp([1, 1, 1], [1.28, 0.95, 0.78], person.beard.warm * 0.55 * warmable);
    U.uBeardTint.value = beardTint;
    U.uBeardDark.value = lerp(mul(mul([0.035, 0.024, 0.018], tint), beardTint), greyCol, person.beard.grey * 0.85);
    U.uBrowTint.value = lerp(mul([0.085, 0.055, 0.04], tint), [0.36, 0.35, 0.33], person.brow.grey);
    U.uBrowA.value = [person.brow.thick, clamp(0.9 + 0.15 * age, 0, 1.2), 0, 0];
    // how strongly shaved follicles show through: dark hair on light skin shows most, grey hair least
    const hairLum = 0.2126 * hairDark[0] + 0.7152 * hairDark[1] + 0.0722 * hairDark[2];
    const castStrength = (0.2 + 0.8 * (1 - smooth(0.02, 0.14, hairLum))) * (1 - 0.45 * dark) * (1 - 0.55 * person.hair.grey);
    U.uCast.value = [...lerp([0.7, 0.73, 0.8], [0.8, 0.79, 0.8], dark), clamp(castStrength, 0.1, 1)];
    U.uAgeA.value = [age, smooth(0.5, 1, age) * (1 - 0.6 * dark), 1, age * 0.6];
    // hair texture
    const ss = STRAND_STYLE[person.hair.texture](person.hair.curl);
    U.uStyleA.value = ss.A; U.uStyleB.value = ss.B; U.uStyleC.value = ss.C;
    const bs = BEARD_STYLE[person.hair.texture];
    U.uBStyleA.value = bs.A; U.uBStyleB.value = bs.B;
    // grey hair reads silver, pewter or white
    const toneB = { silver: 0.62, pewter: 0.46, white: 0.78 }[person.hair.greyTone] || 0.62;
    U.uGreyA.value = [person.hair.grey, 0, toneB + 0.05 * age, 0];
    U.uGreyB.value = { temples: [1.2, 0, 0, 0.4], front: [0, 1.2, 0, 0.35], crown: [0, 0, 1.2, 0.35], even: [0, 0, 0, 0] }[person.hair.greyPattern || 'temples'] || [1.2, 0, 0, 0.4];
    U.uBeardGrey.value = [person.beard.grey, Math.min(0.85, toneB + 0.04), person.beard.patchy, 0];
    // how far a moustache hangs over the upper lip (never past the mouth line)
    U.uBeardLip.value = { walrus: 0.95, moustache: 0.45, horseshoe: 0.45, pencil: 0, full: 0.4, long: 0.5, boxed: 0.3, goatee: 0.3, vandyke: 0.3 }[person.beard.style] ?? 0.3;
    U.uBeardGreyB.value = { chin: [1.1, 0, 0.4, 0.4], sides: [0, 1.1, 0, 0.35], even: [0, 0, 0, 0] }[person.beard.greyPattern || 'chin'] || [1.1, 0, 0.4, 0.4];
    // alopecia areata patches
    const ar = new Float32Array(12);
    (person.bald.patches || []).slice(0, 3).forEach((q, i) => ar.set(q, i * 4));
    U.uAreata.value = ar;
    // baldness
    // hair loss: Norwood (frontal / temporal + crown), Norwood A, crown-only, diffuse thinning
    const loss = person.bald.type === 'none' ? [0, 0, 0, 0, 0, person.bald.diffuse || 0] : HSC.baldShape(Object.assign({ type: 'norwood' }, person.bald));
    U.uBaldA.value = [loss[0], loss[1], loss[2], loss[3]];
    U.uBaldB.value = [loss[4], loss[5], (person.seed % 97) * 0.37, 0];
    // skin sheen follows the skin tone
    if (ctx.Gi && ctx.Gi.sheenColor) {
      const sc = lerp([1, 0.27, 0.19], [0.42, 0.28, 0.22], dark);
      ctx.Gi.sheenColor.setRGB(sc[0], sc[1], sc[2]);
      ctx.Gi.sheen = 0.6 - 0.2 * dark;
    }
    try { applyMorph(person); } catch (err) { console.error('customers: morph failed', err); }
    try { drawEyes(person); } catch (err) { console.error('customers: eyes failed', err); }
  };

  HSC.setBeard = function (levels) {
    if (!st.beardTex) return;
    let any = false;
    for (let c = 0; c < 8192; c++) {
      const v = levels && levels[c] ? HSC.BEARD_MM[levels[c]] || 0 : 0;
      st.beardData[c] = Math.round((v / 50) * 255);
      if (v >= 0.5) any = true;
    }
    st.beardTex.needsUpdate = true;
    if (st.beardMesh) st.beardMesh.visible = any;
  };

  // clipper picking: is this (morphed) hit on the beard? returns grid coords like the scalp's u/v
  HSC.beardHit = function (x, y, z, triStart, fine) {
    if (!ctx || !st.surface) return null;
    let bx = x, by = y, bz = z;
    if (fine) {
      // map the hit back onto the un-morphed head through the hit triangle's barycentrics
      const P = ctx.Pt.attributes.position.array, I = ctx.Pt.index.array;
      const a = I[triStart] * 3, b = I[triStart + 1] * 3, c = I[triStart + 2] * 3;
      const v0 = [P[b] - P[a], P[b + 1] - P[a + 1], P[b + 2] - P[a + 2]], v1 = [P[c] - P[a], P[c + 1] - P[a + 1], P[c + 2] - P[a + 2]], v2 = [x - P[a], y - P[a + 1], z - P[a + 2]];
      const d00 = v0[0] * v0[0] + v0[1] * v0[1] + v0[2] * v0[2], d01 = v0[0] * v1[0] + v0[1] * v1[1] + v0[2] * v1[2], d11 = v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2];
      const d20 = v2[0] * v0[0] + v2[1] * v0[1] + v2[2] * v0[2], d21 = v2[0] * v1[0] + v2[1] * v1[1] + v2[2] * v1[2];
      const den = d00 * d11 - d01 * d01 || 1;
      const wb = (d11 * d20 - d01 * d21) / den, wc = (d00 * d21 - d01 * d20) / den, wa = 1 - wb - wc;
      const B = st.base;
      bx = B[a] * wa + B[b] * wb + B[c] * wc; by = B[a + 1] * wa + B[b + 1] * wb + B[c + 1] * wc; bz = B[a + 2] * wa + B[b + 2] * wb + B[c + 2] * wc;
    }
    if (HSC.beardZone(bx, by, bz) < 0.2) return null;
    const cell = HSC.beardCell(bx, by, bz);
    if (cell < 0 || !st.beardCells.has[cell]) return null;
    const [u, v] = HSC.beardUV(bx, by, bz);
    return { kind: 'beard', u, v };
  };

  // follow the game's automatic detail level (it lowers scalp strand counts when frames run slow)
  // strand ribbon geometry with a given number of segments (fewer on the low detail level)
  function strandGeometry(geo, seg) {
    const T = ctx.T, pos = [], idx = [];
    for (let s = 0; s <= seg; s++) {
      pos.push(-1, s / seg, 0, 1, s / seg, 0);
      if (s < seg) { const u = s * 2; idx.push(u, u + 1, u + 2, u + 1, u + 3, u + 2); }
    }
    geo.setAttribute('position', new T.mt(pos, 3));
    geo.setIndex(idx);
  }
  // apply the current detail level to everything already built
  HSC.onDetailChange = function () {
    if (!ctx) return;
    const D = HSC.detail;
    if (ctx.Oi && ctx.Oi.mesh) strandGeometry(ctx.Oi.mesh.geometry, D.segments);
    if (st.beardMesh) strandGeometry(st.beardMesh.geometry, D.beardSegments);
    for (const m of [ctx.Gi, ctx.Oi && ctx.Oi.mesh.material, st.beardMesh && st.beardMesh.material]) {
      if (!m) continue;
      m.defines = Object.assign({}, m.defines);
      if (D.shaderLow) m.defines.HSC_LOW = ''; else delete m.defines.HSC_LOW;
      m.needsUpdate = true;
    }
    HSC.setDetail(1);
    HSC.clipCap && HSC.clipCap();
  };

  HSC.setDetail = function (f) {
    if (!st.beardMesh || !st.roots) return;
    const k = Math.max(0.3, Math.min(1, f)) * HSC.detail.beardMax;
    const n = Math.max(1, Math.round(st.roots.count * k));
    st.beardMesh.geometry.instanceCount = n;
    st.beardMesh.material.uniforms.uWidth.value = Math.sqrt(st.roots.count / n);
  };

  HSC.beardStartFor = (person) => (st.surface ? HSC.beardStart(person, st.surface, st.base) : new Array(8192).fill(0));
  HSC.debugState = st;
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Game-state side: the customer record and beard grid live in the saved session.
//   state.look.person    the customer (see people.js)
//   state.beard          beard length level per grid cell (index into BEARD_MM)
//   state.startBeard     the beard the customer walked in with
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const LEVELS = () => HSC.BEARD_MM.length;
  const checked = new WeakSet();
  const okBeard = (a) => {
    if (checked.has(a)) return true;
    const ok = Array.isArray(a) && a.length === 8192 && a.every((v) => Number.isInteger(v) && v >= 0 && v < LEVELS());
    if (ok) checked.add(a);
    return ok;
  };

  // Walk-in hair by age: every walk-in has a 16 mm top; younger men more often come in with the
  // sides and back already shorter (2 = 6 mm ... 5 = same as the top), older men more often even
  // or with a soft, low taper. Every starting length is above guard 0, so all of it can be cut.
  const SIDE_BY_AGE = {
    young: { 2: 25, 3: 35, 4: 25, 5: 15 },
    middle: { 2: 10, 3: 25, 4: 35, 5: 30 },
    old: { 2: 3, 3: 12, 4: 30, 5: 55 },
  };
  const CONTOUR_BY_AGE = {
    young: { low: 1, mid: 1.2, high: 1.2, drop: 1.1, taper: 0.8, even: 1 },
    middle: { low: 1.2, mid: 1, high: 0.7, drop: 0.8, taper: 1.2, even: 1 },
    old: { low: 1.3, mid: 0.8, high: 0.4, drop: 0.5, taper: 1.5, even: 1 },
  };
  HSC.pickWalkIn = function (person, recent = []) {
    const W = HSC.walkIns;
    if (!W || !person) return null;
    const R = HSC.rng(((person.seed >>> 0) ^ 0x5bd1e995) >>> 0 || 1);
    const side = Number(R.pick(SIDE_BY_AGE[person.age] || SIDE_BY_AGE.middle));
    const cw = CONTOUR_BY_AGE[person.age] || CONTOUR_BY_AGE.middle;
    const fresh = (sd) => W.list.filter((p) => p.side === sd && !recent.slice(-4).includes(p.id));
    // every look of this length was seen lately (the longest has only one): a neighbouring length instead
    let list = fresh(side);
    for (const sd of [side - 1, side + 1, side - 2]) if (!list.length) list = fresh(sd);
    if (!list.length) list = W.list.filter((p) => p.side === side);
    const weights = list.map((p) => cw[p.contour] || 1);
    let r = R.next() * weights.reduce((a, b) => a + b, 0);
    for (let i = 0; i < list.length; i++) if ((r -= weights[i]) <= 0) return list[i];
    return list[list.length - 1];
  };
  function walkIn(s, person) {
    if (s.status !== 'cutting' || s.cutStrokeCount || !s.look || s.look.visit !== 'walk-in') return null;
    if (!Array.isArray(s.hair) || !Array.isArray(s.startHair) || s.hair.some((v, i) => v !== s.startHair[i])) return null;
    const recent = Array.isArray(s.recentLooks) ? s.recentLooks.slice(0, -1) : [];
    // VIPs and the very first customer come in with a full, even head of hair: the most to cut
    const q = HSC.meta && HSC.meta.data && HSC.meta.data.queue;
    const queued = q && q.job === s.jobId && q.profile && HSC.walkIns && HSC.walkIns.list.find((w) => w.id === q.profile);
    const p = queued || (person.vip || person.first ? HSC.walkIns && HSC.walkIns.list.find((w) => w.contour === 'even') : HSC.pickWalkIn(person, recent));
    if (!p) return null;
    const hair = HSC.walkIns.build(p);
    const recentLooks = Array.isArray(s.recentLooks) && s.recentLooks.length ? [...s.recentLooks.slice(0, -1), p.id] : [p.id];
    return { hair, startHair: hair.slice(), recentLooks, profile: p.id };
  }

  // make sure the session has a customer and beard for the current job (deterministic per job)
  HSC.ensure = function (s) {
    if (!s || !s.look) return s;
    let person = s.look.person;
    const fresh = !HSC.debugOverride && (!HSC.validPerson(person) || person.job !== s.jobId);
    if (fresh) {
      const seed = ((s.seed >>> 0) ^ Math.imul((s.jobId | 0) + 1, 0x9e3779b1)) >>> 0;
      person = HSC.personForJob ? HSC.personForJob(s, seed || 1) : Object.assign(HSC.makePerson(seed || 1), { job: s.jobId });
    }
    // test hook: show a specific customer (never set by the game)
    let forced = false;
    if (HSC.debugOverride) {
      forced = s.look.person !== HSC.debugOverride;
      person = HSC.debugOverride;
    }
    let beard = s.beard, startBeard = s.startBeard;
    if (fresh || forced || !okBeard(beard) || !okBeard(startBeard) || beard.some((v, i) => v > startBeard[i])) {
      startBeard = HSC.beardStartFor(person);
      beard = startBeard.slice();
      checked.add(startBeard);
      checked.add(beard);
    }
    const w = fresh ? walkIn(s, person) : null;
    if (!w && !fresh && !forced && beard === s.beard && startBeard === s.startBeard && s.look.colour === person.hair.colour) return s;
    const look = Object.assign({}, s.look, { person, colour: person.hair.colour }, w ? { profile: w.profile } : null);
    const out = Object.assign({}, s, { look, beard, startBeard });
    if (w) Object.assign(out, { hair: w.hair, startHair: w.startHair, recentLooks: w.recentLooks });
    return out;
  };

  // a clipper stroke on the beard: every cell under the blade is cut down to the guard length
  HSC.cutBeard = function (s, points, surface) {
    const none = { state: s, changed: false, changedCells: 0, removedLength: 0, intensity: 0 };
    if (!s || s.status !== 'cutting' || s.interactionMode !== 'cut' || !surface || !Array.isArray(points) || !points.length) return none;
    const guard = HSC.GUARD_LEVEL[s.selectedGuard];
    if (guard == null || !okBeard(s.beard)) return none;
    const BLADE_W = 0.56, BLADE_D = 0.1;
    // walk from the previous blade position to the current one in small steps
    const steps = [];
    const valid = points.filter((p) => p && Array.isArray(p.position) && Array.isArray(p.normal));
    for (let i = 0; i < valid.length; i++) {
      const b = valid[i], a = i ? valid[i - 1] : null;
      if (!a) { steps.push(b); continue; }
      const d = Math.hypot(b.position[0] - a.position[0], b.position[1] - a.position[1], b.position[2] - a.position[2]);
      const n = Math.max(1, Math.min(40, Math.ceil(d / 0.03)));
      for (let k = 1; k <= n; k++) {
        const t = k / n, lerp = (u, v) => u.map((x, j) => x + (v[j] - x) * t);
        steps.push({ position: lerp(a.position, b.position), normal: lerp(a.normal, b.normal), bladeAcross: lerp(a.bladeAcross || [1, 0, 0], b.bladeAcross || [1, 0, 0]), bladeAlong: lerp(a.bladeAlong || [0, 1, 0], b.bladeAlong || [0, 1, 0]) });
      }
    }
    const next = s.beard.slice();
    const changed = new Set();
    let removed = 0;
    const { positions: pos, spatial } = surface;
    const reach = Math.hypot(BLADE_W / 2, BLADE_D / 2, 0.1);
    const unit = (v) => { const l = Math.hypot(...v) || 1; return v.map((x) => x / l); };
    for (const p of steps) {
      const g = p.position, across = unit(p.bladeAcross), along = unit(p.bladeAlong), nrm = unit(p.normal);
      const lo = g.map((x) => Math.floor((x - reach) / spatial.size)), hi = g.map((x) => Math.floor((x + reach) / spatial.size));
      for (let i = lo[0]; i <= hi[0]; i++) for (let j = lo[1]; j <= hi[1]; j++) for (let k = lo[2]; k <= hi[2]; k++) {
        const list = spatial.buckets.get(i + ',' + j + ',' + k);
        if (!list) continue;
        for (const c of list) {
          const d = [pos[c * 3] - g[0], pos[c * 3 + 1] - g[1], pos[c * 3 + 2] - g[2]];
          const dot = (v) => d[0] * v[0] + d[1] * v[1] + d[2] * v[2];
          if (Math.abs(dot(across)) > BLADE_W / 2 || Math.abs(dot(along)) > BLADE_D / 2 || Math.abs(dot(nrm)) > 0.1) continue;
          if (next[c] > guard) {
            removed += HSC.BEARD_MM[next[c]] - HSC.BEARD_MM[guard];
            next[c] = guard;
            changed.add(c);
          }
        }
      }
    }
    if (!changed.size) return none;
    checked.add(next);
    return {
      state: Object.assign({}, s, { beard: next, cutStrokeCount: s.cutStrokeCount + 1 }),
      changed: true,
      changedCells: changed.size,
      removedLength: removed,
      intensity: Math.min(1, removed / Math.max(1, changed.size * 16)),
    };
  };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Progress between haircuts: barber level, daily streak, the daily VIP, and the queue that decides
// who the next customer is (so the reveal screen can show them, and a video can swap in a VIP).
//
// Level gates which customer features appear, so the first session keeps showing something new:
//   1 scalp only (clean-shaven, full hair, young / middle-aged)   2 beards and moustaches
//   3 older customers and grey hair   4 hair loss   5+ VIPs sometimes walk in on their own
// The four customer classes are never gated. Saved through the platform storage.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const KEY = 'skin-fade-studio-meta-v1';
  const LEVEL_AT = [0, 2, 4, 7, 10]; // haircuts needed for levels 1..5, then one level every 5
  const cutsFor = (level) => (level <= 5 ? LEVEL_AT[level - 1] : 10 + 5 * (level - 5));
  const levelOf = (cuts) => {
    if (cuts >= 10) return 5 + Math.floor((cuts - 10) / 5);
    let l = 1;
    while (l < 5 && cuts >= cutsFor(l + 1)) l++;
    return l;
  };
  const VIP_BEARDS = ['full', 'long', 'boxed', 'mutton', 'full', 'long'];

  const M = (HSC.meta = { data: null, client: null, levelOf, cutsFor });

  const dayKey = (d = new Date()) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return dayKey(d); };
  const hash = (str) => { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };

  function fresh() {
    return { v: 1, cuts: 0, streak: 0, lastDay: null, firstDay: dayKey(), dailyDay: null, queue: null, trial: null, declines: 0, pauseLeft: 0, offerTurn: 0, seen: {} };
  }
  function sanitize(d) {
    const f = fresh();
    if (!d || typeof d !== 'object' || d.v !== 1) return f;
    const int = (v, dflt) => (Number.isSafeInteger(v) && v >= 0 ? v : dflt);
    const str = (v) => (typeof v === 'string' && /^\d{4}-\d\d-\d\d$/.test(v) ? v : null);
    const q = d.queue && Number.isSafeInteger(d.queue.job) && HSC.validPerson(d.queue.person) ? { job: d.queue.job, person: d.queue.person, profile: typeof d.queue.profile === 'string' ? d.queue.profile : null } : null;
    const t = d.trial && Number.isSafeInteger(d.trial.job) && typeof d.trial.key === 'string' ? d.trial : null;
    return {
      v: 1, cuts: int(d.cuts, 0), streak: int(d.streak, 0), lastDay: str(d.lastDay), firstDay: str(d.firstDay) || f.firstDay,
      dailyDay: str(d.dailyDay), queue: q, trial: t, declines: int(d.declines, 0), pauseLeft: int(d.pauseLeft, 0),
      offerTurn: int(d.offerTurn, 0), seen: d.seen && typeof d.seen === 'object' ? d.seen : {},
    };
  }
  M.save = function () {
    if (M.client && M.client.saveProgress && M.data) M.client.saveProgress(KEY, M.data).catch(() => {});
  };
  // loaded before the game controller starts, so the first customer already follows the level
  HSC.metaInit = async function (client) {
    M.client = client;
    let d = null;
    try { d = client && client.loadProgress ? await client.loadProgress(KEY, null) : null; } catch (e) {}
    M.data = sanitize(d);
    // a streak survives only if the last haircut was today or yesterday
    if (M.data.lastDay !== dayKey() && M.data.lastDay !== yesterday()) M.data.streak = 0;
    oneTab(client);
  };
  // the streak as it stands now (a tab left open past a missed day shows 0, not the old number)
  M.streakNow = () => (M.data && (M.data.lastDay === dayKey() || M.data.lastDay === yesterday()) ? M.data.streak : 0);

  // one game at a time: a newer tab takes over and this one pauses and stops saving (two tabs writing
  // the same saves would lose unlocks and progress). The tab in front always plays: coming back to a paused
  // tab, or the other tab closing while this one is in view, reloads it with the latest saves.
  function oneTab(client) {
    let ch;
    try { ch = new BroadcastChannel('skin-fade-studio-tabs'); } catch (e) { return; }
    const me = Math.random().toString(36).slice(2);
    let by = null, reloading = false;
    const reload = () => { if (!reloading) { reloading = true; location.reload(); } };
    ch.onmessage = (e) => {
      const m = e.data || {};
      if (m.hi && m.me !== me) {
        by = m.me;
        HSC.otherTab = true;
        if (client && client.setPauseReason) client.setPauseReason('other-tab', true);
      } else if (m.bye && m.me === by && document.visibilityState === 'visible') reload();
    };
    ch.postMessage({ hi: 1, me });
    addEventListener('pagehide', () => { try { ch.postMessage({ bye: 1, me }); } catch (e) {} });
    document.addEventListener('visibilitychange', () => { if (HSC.otherTab && document.visibilityState === 'visible') reload(); });
  }

  M.level = () => levelOf(M.data ? M.data.cuts : 0);
  M.today = dayKey;

  // ---- customers ----
  // what a customer may have at this level; `extra` forces a showcase feature or a VIP
  function generate(seed, level, extra = {}) {
    const R = HSC.rng((seed ^ 0x2c1b3c6d) >>> 0 || 1);
    const opts = {};
    if (level < 2) opts.beard = 'clean';
    if (level < 3) { opts.age = R.next() < 0.55 ? 'young' : 'middle'; opts.grey = 0; opts.beardGrey = 0; }
    if (level < 4) opts.noLoss = true;
    if (extra.feature === 'beard') opts.beard = ['full', 'boxed', 'goatee', 'moustache', 'vandyke', 'chinstrap'][Math.floor(R.next() * 6)];
    if (extra.feature === 'old') { opts.age = 'old'; delete opts.grey; delete opts.beardGrey; }
    if (extra.feature === 'loss') { delete opts.noLoss; opts.norwood = ['3', '3v', '4', '5'][Math.floor(R.next() * 4)]; }
    if (extra.vip || extra.first) {
      // the most satisfying cut: a full, thick head of hair (and a big beard once beards are in)
      opts.noLoss = true;
      opts.age = R.next() < 0.6 ? 'young' : 'middle';
      opts.grey = 0; opts.beardGrey = 0;
      opts.beard = extra.first || level < 2 ? 'clean' : VIP_BEARDS[Math.floor(R.next() * VIP_BEARDS.length)];
    }
    const p = HSC.makePerson(seed >>> 0 || 1, opts);
    if (extra.vip) p.vip = true;
    if (extra.first) p.first = true;
    if (extra.daily) p.daily = extra.daily;
    return p;
  }
  M.makeVip = (seed) => generate(seed, M.level(), { vip: true });
  // the walk-in hair is decided with the customer, so the reveal hub can show them exactly
  M.profileFor = function (person, recent) {
    const W = HSC.walkIns;
    if (!W) return null;
    const p = person.vip || person.first ? W.list.find((w) => w.contour === 'even') : HSC.pickWalkIn(person, Array.isArray(recent) ? recent : []);
    return p ? p.id : null;
  };

  // the customer for a job; `seed` is the game's own per-job seed
  HSC.personForJob = function (s, seed) {
    const d = M.data;
    if (d && d.queue && d.queue.job === s.jobId && HSC.validPerson(d.queue.person)) return Object.assign({}, d.queue.person, { job: s.jobId });
    const first = !!d && d.cuts === 0 && s.jobId === 1;
    return Object.assign(generate(seed, M.level(), first ? { first: true } : {}), { job: s.jobId });
  };

  // a haircut was finished: progress, streak, and who comes in next
  M.onFinish = function (state) {
    const d = M.data;
    if (!d) return null;
    const before = levelOf(d.cuts);
    // finishing without a single cut is not a haircut: no level, no streak (the next customer still comes)
    const counted = state.cutStrokeCount > 0;
    if (counted) d.cuts += 1;
    const level = levelOf(d.cuts);
    const today = dayKey();
    if (counted && d.lastDay !== today) d.streak = d.lastDay === yesterday() ? d.streak + 1 : 1;
    if (counted) d.lastDay = today;
    // next customer: the new level's feature > daily VIP (from the second day on; never twice for one day,
    // even with the clock turned back) > VIP walk-in > anyone
    const job = state.jobId + 1;
    // a replayed haircut: the next customer was already chosen and shown, they stay (a daily VIP too)
    if (d.queue && d.queue.job === job && HSC.validPerson(d.queue.person)) {
      M.save();
      return { levelUp: level > before, level, before, job };
    }
    const seed = (((state.seed >>> 0) ^ Math.imul(job + 1, 0x9e3779b1)) >>> 0) || 1;
    let person;
    const FEATURE = { 2: 'beard', 3: 'old', 4: 'loss' };
    if (level > before && FEATURE[level]) {
      person = generate(seed, level, { feature: FEATURE[level] });
    } else if ((!d.dailyDay || today > d.dailyDay) && d.firstDay !== today) {
      person = generate(hash('daily-' + today), level, { vip: true, daily: today });
      d.dailyDay = today;
    } else if (level > before && level === 5) {
      person = generate(seed, level, { vip: true });
    } else {
      person = generate(seed, level, level >= 5 && HSC.rng(seed).next() < 0.12 ? { vip: true } : {});
    }
    d.queue = { job, person, profile: M.profileFor(person, state.recentLooks) };
    M.save();
    return { levelUp: level > before, level, before, job };
  };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Rewards catalogue: complete clipper and gown designs built from these colours, metal finishes and
// patterns. The starting look is free; every other design unlocks with rewarded videos.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';

  const COLOURS = [
    // id, hex, tier (0 starter, 1 common, 2 uncommon, 3 special)
    ['charcoal', '#34363b', 0], ['jet', '#17181a', 0], ['silver', '#b9bec5', 0], ['red', '#c8262e', 0],
    ['steel', '#2f4f6a', 0], ['white', '#f2f1ec', 0], ['navy', '#1d2c50', 0],
    ['graphite', '#4c5058', 1], ['cream', '#efe3c6', 1], ['sand', '#d6c096', 1], ['tan', '#b88857', 1],
    ['brown', '#6a4329', 1], ['burgundy', '#6d1f2e', 1], ['orange', '#ef8420', 1], ['yellow', '#f2cf37', 1],
    ['green', '#2e9549', 1], ['forest', '#1e573a', 1], ['blue', '#2a60c6', 1], ['sky', '#78c1ee', 1],
    ['purple', '#6b3aa6', 1], ['pink', '#f29abf', 1], ['grey', '#8a8f96', 1],
    ['coral', '#ef6a56', 2], ['amber', '#f2a91c', 2], ['lime', '#a4d43b', 2], ['olive', '#6a6f35', 2],
    ['mint', '#9de0c0', 2], ['teal', '#14807c', 2], ['cyan', '#28b3d4', 2], ['indigo', '#3a2f8c', 2],
    ['violet', '#9a69dc', 2], ['lavender', '#c3b1e8', 2], ['magenta', '#d4337e', 2], ['rose', '#c46a79', 2],
    ['peach', '#f5b893', 2], ['mustard', '#c99a2a', 2], ['denim', '#4a6a92', 2], ['khaki', '#a89b6e', 2],
    ['neon-green', '#3bff6c', 3], ['neon-pink', '#ff3fa6', 3], ['neon-orange', '#ff7a1a', 3], ['neon-blue', '#2ad4ff', 3],
    ['pearl', '#f4efe6', 3], ['candy-red', '#e0102a', 3], ['royal-gold', '#d4a62a', 3], ['midnight', '#0e1230', 3],
  ];

  // clipper metal parts
  const FINISHES = [
    // id, light metal, dark metal, metalness, roughness, tier
    ['chrome', '#cfd5da', '#8a9298', 1, 0.22, 0],
    ['brushed', '#c4c8cc', '#8c9196', 1, 0.42, 1],
    ['gunmetal', '#6b7076', '#3e4248', 1, 0.3, 1],
    ['matte-black', '#3a3b3e', '#232427', 0.2, 0.62, 2],
    ['black-chrome', '#4a4d52', '#26282b', 1, 0.16, 2],
    ['gold', '#e3be5b', '#a8832c', 1, 0.2, 3],
    ['rose-gold', '#e7b0a0', '#b0705f', 1, 0.22, 3],
    ['copper', '#d98a5b', '#97522e', 1, 0.26, 2],
    ['titanium-blue', '#7f97d8', '#4a5aa3', 1, 0.24, 3],
    ['titanium-violet', '#a98ad6', '#6a4c9c', 1, 0.24, 3],
    ['white-ceramic', '#f1efea', '#c9c6bf', 0, 0.35, 3],
  ];

  // patterns: drawn on a canvas with the two chosen colours (see patterns.js)
  const CLIPPER_PATTERNS = [
    ['solid', 0], ['two-tone', 0], ['racing', 1], ['pinstripe', 1], ['carbon', 2], ['camo', 2], ['marble', 3],
    ['chevron', 1], ['dots', 1], ['fade', 2], ['checker', 1], ['flames', 3], ['honeycomb', 2], ['wood', 2],
    ['leopard', 3], ['zebra', 3], ['diamond-plate', 3], ['galaxy', 3],
  ];
  const GOWN_PATTERNS = [
    ['solid', 0], ['stripes', 0], ['pinstripe', 1], ['gingham', 1], ['tartan', 2], ['dots', 1], ['chevron', 2],
    ['houndstooth', 2], ['yoke', 1], ['fade', 2], ['argyle', 3], ['waves', 2], ['barber-pole', 3], ['floral', 3],
    ['palms', 3], ['scissors', 3], ['camo', 2], ['checker', 1],
  ];

  const colourHex = new Map(COLOURS.map(([id, hex]) => [id, hex]));
  const finishes = new Map(FINISHES.map(([id, light, dark, metal, rough]) => [id, { id, light, dark, metal, rough }]));

  // Complete, ready-made designs: the player picks a whole clipper or a whole gown. 1,000 clippers and
  // 600 gowns, generated once with colour-harmony rules (every pair of colours goes together, colours that
  // look the same side by side were merged, two-colour patterns have enough contrast to show) and frozen
  // here so that no design ever changes between versions. The first of each is the starting look (free);
  // the rest unlock with one rewarded video each. One clipper and one robe from these are on offer each
  // day (wardrobe.js).
  // Each design is 5 characters: colour / colour / finish-or-pattern / pattern-or-collar indices into the
  // lists above, then shelf * 2 + premium. Clipper: body, accent, finish, pattern. Gown: main, second,
  // pattern, collar.
  const CLIPPER_CODE = 'ABAAAFBDAAiKAACBJHCEeQCKGDBAJIVOGALfTAOPBeJANtCDBAMPABCCbDCEENAKGBaAJIOVFBLgBARPBmDCNbeABAfOCACtTCDEGPDKGEQCJICMFALVNFNPBDFHNQFCAADiCBCFEDCEtNAKGCZCJIiCHAKEXCNOBOCBNCMAAAMhAACGiACELXAIGYECJIOLFBLBMAEOBXDINBiDBAKJAACCLHDEVGAIGbBCHIKVHAKCOAGPBNHCNtYCAASODBCWbCDERZAIGOCCHIVMHAKbUCLPBeAINEBCAANaAACSgDCELiCKGhEDJIXVGALbXALPBgHANVgCBAXLABCEYCDEXGDKGYtCHIVRIALEJDRPBNAKNtEAAAOfAACCDDDEZRCIGCWFHJBSIBLbeDGPBOHHNCZAAAMYDBCBCFDFtFDIGGPAJIWLHBKQfAFOBDGKNaMDBAiGCBCUBHCEDaDIGhBFHJKiFALTKAEOBgHINtiCBAePABCKbDDEQRDIGUFCHIiVHBKLEDPPBODBNCZABAeCDBCGKCCEmCDKGfLCHIfRJBLCXDNOBOGJNVGCBANSCBCBMCDECRDIGeQAHIJFHAKbTDRPBTICNLeCBASLDBCgCGDFSWCIGfbAHISFIALgQCQPBeACNLfABAhPCACFLCDESUAIGViCJIiLFALLVFEPBTCANbiCBAWFCACXVCDENFDIGbBDJIEFJALGOCNOBDCHNCQABARfCBCSPCDEKSDIGfLAJIWFGALVaDRPBgAANJKCAAYMCBCLCFDFVhAKGBRAJIhFFALCNGGPBTIDNJCDAAXSDBCJLHDEJVHKGLtAHIbCIBLmFCLPBXFDNGYCBAMECBCLVDDEOVHIGFeIHJNCGBLJeAOPBTDINtYABAiSABChQCDEQGDKGWCDHITfJALbWDFOBDGCNbgCAAUbCACSWCDEFEJIHGNDJIXLHBKahDGPBOHJNaVAAAPTCACDVFCFfBIIHVBGJJFSJBLYMCPPBNCHNLfAAASJDBCCRDCEiBHIGetAJIBCFALJVHOPBgGHNFLCBADSDACBQADEWCCKGGDCJIONHAKZRANOBNAINGYDBATfAACCLADEGXAIGOCDJIGCJBLfLCRPBYDHNLbAAAgQDACSgCCECTAKGmVCHIKCGBLifDNOBgFCNLBDAAPhABCRBADEMUGIHXBCHINDGBLBLGFPBmDANFWDAAWSDBCiLDDEbJAIGgZCHIFNFBLTVJQPBXACNGfCAAUbDACSLADEVGAKGGVAHIbFIALQtDGPBNCBNFWAAAfPABCVRJCFVODKGbDAJIDMFALCOFRPBNAHNCDDBAWLDBCFeDCENVDIGUSCHIEVJALPMALPBDDANtCDAAXZAACGDCDEWCAIGUZAJISCIALYCCPPBDGHNaBCBAZtDACQRDCECBAIGfBJHJfCIALDVHFOBNFANLNCBAmBDBCLWGCFeYDIGPSAHINLHAKSPDRPBeCCNEiDBAZBDBCGFCCEPSCKGRJDJIVJFBLRFIGPBmAINaGDAAmVABCDVGDFJfCKGFSJHJMCHAKaBCFOBgHJNQBCBAYCDBCLXDCEhBHKGVFHHIgVFALPECFOBgGDNEJABAgaDACLCHCEVtIIHaPCHINBGALXVCMPBOAANGDDAAZTAACNBCDEWLGIHtiAHIebIALViFFPBOAKNEZCBARYDBCbCADEtWDKGPTDJIRFIALUBFGPBeIHNGZCAAUMCACXGACEbtDKGDNHJIhMHBKMaCMPBOACNQPCAATfDACOBCCENOHIGELAJIDCFALFVCNOBXFCNaLAAAZtABCfZDCEOBHKGYhCHIftIALGeAPPBgHBNbCDAAZFDACCYACEfYAIGteIJJMVGALFGCRPBgGBNQMCBADBCACVODDEhBCIGKGAHIBVHBKRZCLPBDDDNaNDBAfQCACVFJDFLKCKGDCDJIVBHAKbUDEOBgFHNJRDBAXFCACVFFCFhaDKGbBCJIKLHAKGfCRPBgFJNQVAAAfbABCtTICFFNFIHbKAHIVWGBLNEDOPBXDJNJZABAOSABCFhCCEFRCIGJSAHICMFBLLODMPBTDHNQeDBAPTABCVhDDEePCIGBPDJIMWFBLTBCMPBgFDNJBCBAeLCACYhACEMUCIGQgDJIKBFALTPDRPBOCINbFCBAeFAACZOACEiDFIHWMCJIhCGALMYDOPBmDBNBVCBAUQDBCPSDCEECAKGbMCHIhVFALFOAGPBOHKNFBAAAPEAACTbDDEJSDIGeGDHIMBFALCtCLPBTCKNBhAAAZtDBCMCHDEeZAKGfRIJJCDGBLFKHOPBNGANLNAAAYPCACYZCCEWCFIHCYCHIfFIBLFDGGPBDAANEWABAYhCACtFDDELfDKGSBJJJOCFALVOFNPBgCDNtNAAAMWCACOFDCEJVHIGOFFJJNVHAKOfCGPBmDINbtABAPMDACFOGDFgCCKGVRCJIKFFALMhHOPBYDCNCgCAASMCACbXDDECXHKGMaCHILOFALFBDOPBgAKNLODBAgVABCECDCESXCKGXVGJJCDHAKYSDGPBmAJNENDAARQABCXGADELBCIGBKGHJUBFBLBSAMPBXADNGJABADEDBCaNCDERBIIHLWGHJBFFALXZDLPBOFDNLCCBAKtDBCSLACEFPDKGYSCJICNFBLZCDEOBgFKNQfDAAPVABCEYADEXGCIGgBGHJDNHBKLWDQPBTCJNagABATiCBChCCCEFhCKGTbDHIWiHAKOFDNOBOGHNBtAAAeGDBCRCIDFCXAIGWaCHItBJALNCARPBOFJNVgDBAWSCACDBCCEEWCKGCKHJIONFBLKFDLPVODAATJDBCiDHCEVMCIGCMCHIFUFALBXGPPFtAAAUBABCJfACENEAKGVWCHIBfJBLfBAFOBhCAAgQCBCXbCCEtVAKGQVCJItbIBLBPAMPbDCAAYhAACtRADEbCIIHQFDHIFVGBLSDDRPJLAAAOfCACeGACETBJKHTCJHJGFIBLRQARPViABAUYCBCZeACEMhCIGPBCHILWFBLWQCOPEKAAADCCBCKFDDEYRDKGQWCJIbeJALBLGGPEWDBATPDBCiDFDFeKAIGPFAHIeTIALLSCEOFOABAmBCACXbCDEEXCIGFNHJIVFJALVgCEOaMCBAhEAACFRCDEWEDKGVBAHIXFGBLFQDPPQCDAARBDACOSADEDCFKHJfAHICSJALRfCRPaUAAARfCACfQADEFhGKHJeAJICGIALFtDLPteCAAKfDBCPfCDENFDKGOBDJICWHAKWFCGPbMCAAYSDBCabCDEDBHIGSgDHICLGALLGAFOVtCBAhYABCYfDCEJRAKGEXAJILXFALBVCGPCMCBAhSDBCGZCDEMQAKGFDHHIOCFBLeFCRPGBDAAgCDBCtTDCERQDKGOFFHJXBFBLBMAOPbfABAmCDBCEXADEPSAIGZBDJIBVIALhVFFPJRABAmVDACtbICFgBFKHKGCHIGeIBLfGJOPtTDAAmBDACVRDCECBJKHfZAJICFHAKVZDGPJVDAAfGDBCaPDCEBfDKGLOCHICSIALFDHRPaMABAhVAACPUCCEDSAKGJLDJIVhFBLWBCNOJZCAASECBCTFCDEhSAKGMPDHIBFJALiRCLPbiDBAKLABCbXACEYRCIGNFAHIFVIBLFXDLPCiCAAOCAACfODCEDaAIGGaCHILNFBLMYDLPQRABAUFDACTbADEfJCIGMUDJIVKFALBCHFOtBAAAfNCBCbfDDERiCKGMhCHIfRJALXBCPPFVDBAPECBCfBJDFOtAIGDEAHIBSIALbBIPPCXABAfZABCetIDFTBJIHOVDHIfFJALLEAPPaPDBAhaCBCbNDCEPVAKGTKAHILKFBLatCFOVODBAKBDAChBDDEZEDKGMSCJIMhHAKQCCPPtaABAefAACaQDDEbgAKGELCHINVGBLBgGNPEiABAYCCACYSDDEaMDIGtKCJIiFFALWLFLPaCDAAWbAACQhDDEfGJKHGZCHIfVJALibDLPCNDAAPtCBCYFADETaAKGSBCHIMFHBKmVARPCRDBAfbCACORDCEKLFIHUSDHIMFGBLQtCFOJtCBARJCACYUCDETYCKGYTDJITVJALEiDRPaBABANCCBCfXCCEhMGIHgZDJIJVGALNBGNPfJDBCbgCCELiDIGCQAJIeGIBLtLDMPECICFSDCKGtQDJIgVGALCgDEOabCCEbXAKGZEAHIOLFALFEANORtJDFaPAIGaeAHIOBGBLNBFEPGCDDEQMAKGJBGJJtfJALLTCGPDiGCFGiAKGePAJINCFALJfCOPLXDDEaGDIGSFIJJiLGALXLHQPaUCCERBDIGKCFJJhMFALitAEOMYCCETtIIHXZCHIBWFBLFBGQPPeDDEZOAKGZBCJICFIALTVCOPiVHCEGfAIGKLHHICLHAKLfDQPPTDCEaVCKGiBHJIOCHBKtTAPPiRADEXZDKGFgAJIUVGALUVANOQVDDEKFGIHUaCJIFhFALeBCNOgCHDEGCAKGFYCJICDFBLWQCEOJRADEEYAIGWECJIEFJBLNFFFPWFADEZSDIGMCHJINOGALRCIQPJZDCEORAIGNbCHILCGALNDGPPiVDCERYAKGiDDHIFtJALfbDLPWBGDFJVFIHPVCJIWVFBLteAGPKGCCEtRAIGNVHHIFOFALVtILPgZDCEbiANOUQACEaNAEOeCJDFPMAOPJZCCEEJCEOgBCCEYtCRPebACEBTJQPNOGDFPEDMPQWACEGXAOPKSCDEYMAOPWVGCFbtCEOTbJCFMFDFOhaDCEbUDMPPtDDEVWGGPUBFCFRLCLPQMADEeKCOPEMDCEGFIEPZgCCENEARPebIDFGLDLPfbJDFRVCMPUFGDFfNDNOTPDFOBDARPCKAMPDaDPPEFDMPNDANOieCGPPGCNOFRCNOiGDOPCDAFOTPCPPRCJEPOCGPPYECQPGCAGPWSDGPRfCEOSNCQPMBFFP';
  const GOWN_CODE = 'EFAFAaBABAhSCSCBUKUFCTJTGQWQWIWBABAWMIMCDiKiFDEGEGLaOaJeFAFABLILCFSRSEFmJmGKRNRJbFAFAQeBeCbKRKEagGgGiEQEILFAFAiSBSCEVHVFFBFBGDCNCJKBABABDIDCOZDZEhaFaGBTQTIfBABAaeBeCUSKSFbUJUGXSMSJVBABAiSISCFeDeEYBGBGWtQtISBABAGfIfCOLHLFJTFTGRJQJIOBABAbCICCgbEbEKRGRGXGQGIXBABAEJIJChBHBFMWJWGRVMVJDFAFAtLILCBgKgFtZFZGiLOLJPFAFAifIfCNbEbECKGKGtaNaJhBABAWFBFCXBDBERfFfGRZPZJRFAFABgCgCXBHBFgBJBGCLNLJFBABABMIMCFXDXEBCFCGeKNKJUBABABJIJCZYHYFabGbGiTPTJgFAFAORIRCfXDXEFhFhGSEMEJYBABAXLCLCEJRJESXLXGRLOLJGFAFASMIMCRKRKEFRGRGGZOZJQFAFATYIYCENRNEfOFOGDaOaJNBABAZRIRCBmEmEbWGWGgaNaJmBABALeBeCKeKeFEFFFGWGPGJiBABAeYIYCJGDGENOFOGQTPTJBFAFAGLBLCmBDBEQCFCGUZPZJTFAFARKBKCVWHWFJRJRGORMRJMFAFAGVBVCPGHGFFtFtGLXQXItFAFAKLBLCEFHFFtbLbGhbObJCBABAOLILChCECEFZLZGaiMiJJBABAtKCKCVMHMFWaGaGLXMXJZFAFAhaIaCQBEBERaLaGMCQCIeJIJCTCKCFYtGtGGXMXJViIiCiTRTEibLbGLXNXJCRIRChYDYEZSJSGfFMFJCZCZCbNDNEQELEGFbMbJOCBCCWLKLFGCLCGaTMTJVNINCLREREbhLhGFmMmJVOCOCDNKNFYRGRGZGQGIPTCTCfLDLEBbLbGtVMVJMEIECFeReEfXFXGgFQFIMECECiBDBEiTFTGahPhJEOCOCJZHZFbeJeGeJOJJFhBhCYMKMFGiFiGbgNgJYRCRCNEDEEhELEGNEMEJZtCtCXGKGFNGJGGitPtJVZIZCSXDXEgbFbGQfQfIfXBXCPUHUFEZLZGNSPSJXEBECGCECESZGZGhMQMISKCKCKEEEEOtLtGaMOMJOZBZCfiRiEDELEGmCMCJGeCeCOFEFEJVFVGEOOOJBRCRCGeEeEfYFYGFVQVIWCCCCWMDMEgCJCGWSNSJMCICCCtHtFUSFSGGeQeItTITCiaDaERLGLGUbNbJLFBFCCPKPFgSGSGBLQLIJbCbCVEEEEWQJQGBDQDIfNBNCJfEfEEKLKGfGMGJEYIYCYMDMEifFfGbWNWJSFIFCaVEVEaWJWGSgQgINGCGChSDSEDQGQGbUNUJFLBLCFQHQFPBGBGJTOTJVmBmChVEVEFfGfGWBMBJFXCXCShHhFKEFEGGWOWJCtCtCPCHCFXCLCGBUMUJXCCCCZFEFEtKJKGgQPQJZfCfCfFEFEBTLTGEDQDIZSCSCgBDBEOZFZGFGNGJMPCPCCZDZEEMGMGKLQLILOCOCBPEPENbLbGfQNQJBPCPCGXDXELtGtGCMQMISDIDCEDHDFJSFSGPSMSJVMIMCYUEUEPCFCGEJMJJZXIXCWEDEENBJBGLbQbIbeIeCgCECEFDGDGLRPRJJGIGCbWRWEBJGJGaMQMIFmImCNSHSFaLFLGXLOLJONINCNtKtFTiGiGMhMhJBaBaCeYEYELeLeGGZPZJieIeCQUDUEfQJQGJEOEJFEIECYEEEEhQJQGPFQFIQTBTCVYHYFCBJBGDBQBIeLCLCfZKZFGCFCGPeOeJBhChCQhHhFNCJCGtXMXJtCICCTYEYEPTLTGNtNtJMQIQCatKtFmFFFGfNMNJFNBNCKfKfFaPJPGLTQTIRiBiCCgHgFMBLBGWaPaJVMCMCRtEtEiDJDGaBMBJaRCRCJGKGFQTJTGGDQDIZfIfCLGEGEQCLCGSFMFJVYBYCYVDVEeZFZGUZOZJKtCtCGCKCFDNLNGbFNFJFbIbCPtDtETCFCGKBIBCYRHRFBVJVGZVIVChSHSFLtJtGXFIFCYBRBEQTLTGQRIRCEPDPESDJDGaPBPCUbRbEFELEGCMIMCJLHLFQWLWGSBCBCNfEfEKRJRGZSBSCNaEaEafFfGeLILCDBHBFMQLQGEXIXCeaKaFZBLBGOBIBCSYKYFCPGPGTZIZCDaKaFEQJQGetItCTiEiEQWFWGbiCiCFNDNEaBFBGSgCgCONDNEZSGSGBmBmCFVHVFWBLBGPSCSCFRHRFCZJZGFWBWCEVRVEMQJQGRCBCCtOHOFLGFGGPMIMCPSHSFFtGtGCDBDCXZRZEXGFGGgZBZCVDHDFLXGXGNVBVCeCKCFYBFBGQBBBCWBHBFeJJJGXSCSCFKRKEBPLPGSYCYCtCHCFGWLWGtYCYCPMDMEVmGmGBUBUCNFHFFXbFbGEiIiCBYEYEDEJEGCZBZCTBHBFBXGXGRYBYCeBEBEbeFeGbtBtCSEDEEJtLtGafIfCBmHmFteJeGMPBPCFYHYFJRGRGUPBPCUBRBEVXJXGZBCBCtYHYFTFJFGfbIbCSXKXFKBLBGXBBBCLVHVFUbLbGKfBfCQDKDFFTLTGafBfCeBRBEGfGfGZCBCCNGDGEUQGQGUbBbCQCKCFLEGEGYBBBCWaDaENEGEGDBCBCBSRSEMEFEGTVBVCTbHbFGFGFGLbCbCBgDgEbXGXGJTBTCZCDCEDQFQGitBtChFEFEbBLBGYTITCTfRfEPEJEGUMBMCFgKgFKbGbGKbCbCaDRDEitJtGEJCJCCRRREbMFMGVhBhCROROEtLGLGNOCOCeBDBENaFaGCYCYCRKDKEUZFZGGPCPCENENEKRFRGtWKWFXVGVGTPKPFOFJFGQDEDEJbGbGtZEZEXLFLGONRNEEXFXGKfEfEVWJWGMCKCFSOLOGEVDVEFhLhGNSDSEtRGRGCLRLEmBJBGfJEJEtXRXENSKSFWVKVFFOEOE';
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const SHELVES = {
    clipper: ['classic', 'bright', 'stripes', 'checks', 'waves', 'metal', 'neon', 'wild'],
    gown: ['plain', 'stripes', 'checks', 'waves', 'wild'],
  };
  const CPAT = CLIPPER_PATTERNS.map((p) => p[0]), GPAT = GOWN_PATTERNS.map((p) => p[0]);
  const CNAME = COLOURS.map((c) => c[0]), FNAME = FINISHES.map((f) => f[0]);
  const designs = { clipper: [], gown: [] };
  const byKey = new Map();
  function decode(tool, code) {
    for (let i = 0; i * 5 < code.length; i++) {
      const v = [...code.slice(i * 5, i * 5 + 5)].map((ch) => B64.indexOf(ch));
      const parts = tool === 'clipper'
        ? { body: CNAME[v[0]], accent: CNAME[v[1]], finish: FNAME[v[2]], pattern: CPAT[v[3]] }
        : { main: CNAME[v[0]], second: CNAME[v[1]], pattern: GPAT[v[2]], collar: CNAME[v[3]] };
      const d = { key: tool + ':' + i, tool, id: String(i), i, shelf: SHELVES[tool][v[4] >> 1], premium: (v[4] & 1) === 1, parts };
      designs[tool].push(d);
      byKey.set(d.key, d);
    }
  }
  decode('clipper', CLIPPER_CODE);
  decode('gown', GOWN_CODE);
  const DEFAULT_LOOK = { clipper: '0', gown: '0' };
  const FREE = new Set(['clipper:0', 'gown:0']);
  // every pick is one rewarded video (the premium flag only marks the flashiest designs)
  const VIDEOS = () => 1;

  HSC.catalog = { COLOURS, FINISHES, colourHex, finishes, designs, byKey, SHELVES, DEFAULT_LOOK, FREE, VIDEOS };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Pattern painter: draws a seamless square tile of a pattern in two colours on a 2D canvas.
// The same tiles texture the 3D clipper / gown and fill the wardrobe swatches.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';

  const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const rgbHex = (c) => '#' + c.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const shade = (h, k) => rgbHex(hexRgb(h).map((v) => (k < 0 ? v * (1 + k) : v + (255 - v) * k)));
  const mix = (a, b, t) => rgbHex(hexRgb(a).map((v, i) => v + (hexRgb(b)[i] - v) * t));
  const lum = (h) => { const [r, g, b] = hexRgb(h); return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };

  // draw fn at all 9 wrap offsets so shapes crossing the tile edge continue on the other side
  function wrapped(ctx, S, fn) {
    for (const ox of [-S, 0, S]) for (const oy of [-S, 0, S]) { ctx.save(); ctx.translate(ox, oy); fn(); ctx.restore(); }
  }
  function blob(ctx, x, y, r, R, n = 9) {
    ctx.beginPath();
    for (let i = 0; i <= n; i++) {
      const a = (i / n) * Math.PI * 2, rr = r * (0.7 + 0.5 * R.next());
      const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
      i ? ctx.quadraticCurveTo(x + Math.cos(a - Math.PI / n) * rr * 1.15, y + Math.sin(a - Math.PI / n) * rr * 1.15, px, py) : ctx.moveTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  }
  // smooth periodic value noise for marble / wood / galaxy (period S)
  function periodicNoise(R, cells) {
    const g = Array.from({ length: cells * cells }, () => R.next());
    const at = (x, y) => g[((y % cells) + cells) % cells * cells + (((x % cells) + cells) % cells)];
    return (u, v) => {
      const x = u * cells, y = v * cells, xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
      const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
      const a = at(xi, yi), b = at(xi + 1, yi), c = at(xi, yi + 1), d = at(xi + 1, yi + 1);
      return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
    };
  }
  function pixels(ctx, S, fn) {
    const img = ctx.createImageData(S, S);
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const c = fn(x / S, y / S), o = (y * S + x) * 4;
      img.data[o] = c[0]; img.data[o + 1] = c[1]; img.data[o + 2] = c[2]; img.data[o + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
  }

  const P = {
    solid(ctx, S, a) { ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); },
    'two-tone'(ctx, S, a, b) { ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b; ctx.fillRect(0, S * 0.5, S, S * 0.5); ctx.fillStyle = shade(b, -0.25); ctx.fillRect(0, S * 0.49, S, S * 0.025); },
    yoke(ctx, S, a, b) { ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b; ctx.fillRect(0, 0, S, S * 0.22); ctx.fillStyle = shade(a, -0.2); ctx.fillRect(0, S * 0.22, S, S * 0.012); },
    racing(ctx, S, a, b) { ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b; ctx.fillRect(S * 0.36, 0, S * 0.1, S); ctx.fillRect(S * 0.54, 0, S * 0.1, S); },
    stripes(ctx, S, a, b) { ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b; for (let i = 0; i < 4; i++) ctx.fillRect((i * S) / 4, 0, S / 8, S); },
    pinstripe(ctx, S, a, b) { ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b; for (let i = 0; i < 8; i++) ctx.fillRect((i * S) / 8, 0, Math.max(1.5, S / 110), S); },
    checker(ctx, S, a, b) { const n = 8, c = S / n; for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) { ctx.fillStyle = (x + y) % 2 ? b : a; ctx.fillRect(x * c, y * c, c, c); } },
    gingham(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S);
      const n = 6, c = S / n;
      ctx.globalAlpha = 0.55; ctx.fillStyle = b;
      for (let i = 0; i < n; i += 2) { ctx.fillRect(i * c, 0, c, S); ctx.fillRect(0, i * c, S, c); }
      ctx.globalAlpha = 1;
    },
    tartan(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S);
      const bands = [[0.0, 0.18, b, 0.6], [0.3, 0.06, shade(a, -0.55), 0.7], [0.5, 0.2, b, 0.55], [0.74, 0.03, '#f2efe6', 0.8], [0.84, 0.05, shade(b, -0.5), 0.7]];
      for (const [p, w, c, al] of bands) { ctx.globalAlpha = al; ctx.fillStyle = c; ctx.fillRect(p * S, 0, w * S, S); ctx.fillRect(0, p * S, S, w * S); }
      ctx.globalAlpha = 1;
    },
    dots(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b;
      const n = 4, c = S / n;
      wrapped(ctx, S, () => { for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) { ctx.beginPath(); ctx.arc(x * c + (y % 2 ? c / 2 : 0) + c / 4, y * c + c / 2, c * 0.2, 0, 7); ctx.fill(); } });
    },
    chevron(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b;
      const n = 4, h = S / n;
      for (let i = -1; i <= n; i++) {
        ctx.beginPath();
        const y = i * h;
        ctx.moveTo(0, y); ctx.lineTo(S / 2, y + h / 2); ctx.lineTo(S, y); ctx.lineTo(S, y + h / 2); ctx.lineTo(S / 2, y + h); ctx.lineTo(0, y + h / 2);
        ctx.closePath(); ctx.fill();
      }
    },
    fade(ctx, S, a, b) { const g = ctx.createLinearGradient(0, 0, 0, S); g.addColorStop(0, a); g.addColorStop(1, b); ctx.fillStyle = g; ctx.fillRect(0, 0, S, S); },
    carbon(ctx, S, a, b) {
      const base = mix(a, '#101010', 0.6), n = 16, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const horiz = (Math.floor(x / 2) + Math.floor(y / 2)) % 2 === 0;
        const g = horiz ? ctx.createLinearGradient(x * c, y * c, x * c, (y + 1) * c) : ctx.createLinearGradient(x * c, y * c, (x + 1) * c, y * c);
        g.addColorStop(0, shade(base, -0.4)); g.addColorStop(0.5, shade(mix(base, b, 0.25), 0.25)); g.addColorStop(1, shade(base, -0.4));
        ctx.fillStyle = g; ctx.fillRect(x * c, y * c, c, c);
      }
    },
    camo(ctx, S, a, b, R) {
      const cols = [a, b, mix(a, b, 0.5), shade(mix(a, b, 0.3), -0.45)];
      ctx.fillStyle = cols[0]; ctx.fillRect(0, 0, S, S);
      for (let k = 1; k < 4; k++) {
        ctx.fillStyle = cols[k];
        for (let i = 0; i < 7; i++) { const x = R.next() * S, y = R.next() * S, r = S * (0.06 + 0.07 * R.next()); wrapped(ctx, S, () => { blob(ctx, x, y, r, HSC.rng(i * 31 + k)); blob(ctx, x + r * 0.8, y + r * 0.3, r * 0.8, HSC.rng(i * 17 + k)); }); }
      }
    },
    marble(ctx, S, a, b, R) {
      const n = periodicNoise(R, 6), n2 = periodicNoise(R, 12), A = hexRgb(a), B = hexRgb(b);
      pixels(ctx, S, (u, v) => {
        const t = Math.abs(Math.sin((u + v) * Math.PI * 4 + 6 * n(u, v) + 2 * n2(u, v)));
        const vein = Math.pow(1 - t, 6);
        return A.map((c, i) => c + (B[i] - c) * vein);
      });
    },
    wood(ctx, S, a, b, R) {
      const n = periodicNoise(R, 4), A = hexRgb(a), B = hexRgb(b);
      pixels(ctx, S, (u, v) => {
        const r = Math.sin((u * 10 + 3 * n(u, v)) * Math.PI * 2) * 0.5 + 0.5;
        const t = Math.pow(r, 3) * 0.75 + 0.15 * n(v, u);
        return A.map((c, i) => c + (B[i] - c) * t);
      });
    },
    galaxy(ctx, S, a, b, R) {
      const n = periodicNoise(R, 5), n2 = periodicNoise(R, 10), base = [10, 10, 24], A = hexRgb(a), B = hexRgb(b);
      pixels(ctx, S, (u, v) => {
        const t = n(u, v), s = n2(u, v);
        return base.map((c, i) => c + A[i] * Math.pow(t, 3) * 0.8 + B[i] * Math.pow(s, 4) * 0.7);
      });
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 90; i++) { ctx.globalAlpha = 0.4 + 0.6 * R.next(); ctx.fillRect(R.next() * S, R.next() * S, 1 + R.next() * 1.5, 1 + R.next() * 1.5); }
      ctx.globalAlpha = 1;
    },
    flames(ctx, S, a, b, R) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S);
      for (const [col, k] of [[b, 1], [mix(b, '#ffe08a', 0.6), 0.6]]) {
        ctx.fillStyle = col;
        for (let i = 0; i < 6; i++) {
          const x = (i / 6) * S + R.next() * S * 0.05, w = S * 0.16 * k, h = S * (0.45 + 0.35 * R.next()) * k;
          wrapped(ctx, S, () => {
            ctx.beginPath(); ctx.moveTo(x - w, S);
            ctx.bezierCurveTo(x - w, S - h * 0.5, x - w * 0.2, S - h * 0.7, x + w * 0.2, S - h);
            ctx.bezierCurveTo(x + w * 0.1, S - h * 0.6, x + w, S - h * 0.45, x + w, S);
            ctx.closePath(); ctx.fill();
          });
        }
      }
    },
    honeycomb(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.strokeStyle = b; ctx.lineWidth = Math.max(1.5, S / 90);
      const r = S / 8, h = r * Math.sqrt(3);
      wrapped(ctx, S, () => {
        for (let row = 0; row * h * 0.5 < S + h; row++) for (let col = 0; col * r * 3 < S + 3 * r; col++) {
          const cx = col * r * 3 + (row % 2 ? r * 1.5 : 0), cy = row * h * 0.5;
          ctx.beginPath();
          for (let i = 0; i <= 6; i++) { const ang = (i / 6) * Math.PI * 2; ctx[i ? 'lineTo' : 'moveTo'](cx + r * Math.cos(ang), cy + r * Math.sin(ang)); }
          ctx.stroke();
        }
      });
    },
    leopard(ctx, S, a, b, R) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S);
      for (let i = 0; i < 16; i++) {
        const x = R.next() * S, y = R.next() * S, r = S * (0.045 + 0.03 * R.next());
        wrapped(ctx, S, () => {
          ctx.fillStyle = b; blob(ctx, x, y, r, HSC.rng(i + 5), 7);
          ctx.fillStyle = mix(a, b, 0.35); blob(ctx, x, y, r * 0.55, HSC.rng(i + 9), 6);
        });
      }
    },
    zebra(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b;
      for (let i = 0; i < 7; i++) {
        const x0 = (i / 7) * S;
        ctx.beginPath(); ctx.moveTo(x0, 0);
        for (let y = 0; y <= S; y += S / 16) ctx.lineTo(x0 + Math.sin((y / S) * Math.PI * 2 + i) * S * 0.04, y);
        for (let y = S; y >= 0; y -= S / 16) ctx.lineTo(x0 + S * 0.055 + Math.sin((y / S) * Math.PI * 2 + i + 0.8) * S * 0.05, y);
        ctx.closePath(); ctx.fill();
      }
    },
    'diamond-plate'(ctx, S, a, b) {
      const g = ctx.createLinearGradient(0, 0, S, S); g.addColorStop(0, shade(a, 0.15)); g.addColorStop(1, shade(a, -0.15));
      ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
      const n = 8, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        ctx.save(); ctx.translate(x * c + c / 2, y * c + c / 2); ctx.rotate(((x + y) % 2 ? 1 : -1) * Math.PI / 4);
        ctx.fillStyle = shade(b, 0.3); ctx.fillRect(-c * 0.32, -c * 0.07, c * 0.64, c * 0.14);
        ctx.fillStyle = shade(b, -0.3); ctx.fillRect(-c * 0.32, c * 0.03, c * 0.64, c * 0.04);
        ctx.restore();
      }
    },
    houndstooth(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b;
      const n = 6, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const ox = x * c, oy = y * c, q = c / 4;
        ctx.beginPath();
        ctx.moveTo(ox, oy + 2 * q); ctx.lineTo(ox + 2 * q, oy); ctx.lineTo(ox + 3 * q, oy); ctx.lineTo(ox + 2 * q, oy + q);
        ctx.lineTo(ox + 4 * q, oy + q); ctx.lineTo(ox + 2 * q, oy + 3 * q); ctx.lineTo(ox + 2 * q, oy + 4 * q); ctx.lineTo(ox + q, oy + 4 * q);
        ctx.lineTo(ox + q, oy + 3 * q); ctx.lineTo(ox, oy + 4 * q);
        ctx.closePath(); ctx.fill();
      }
    },
    argyle(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S);
      const n = 2, w = S / n, h = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        ctx.fillStyle = (x + y) % 2 ? b : mix(a, b, 0.4);
        ctx.beginPath(); ctx.moveTo(x * w + w / 2, y * h); ctx.lineTo(x * w + w, y * h + h / 2); ctx.lineTo(x * w + w / 2, y * h + h); ctx.lineTo(x * w, y * h + h / 2); ctx.closePath(); ctx.fill();
      }
      ctx.strokeStyle = '#f2efe6'; ctx.lineWidth = Math.max(1, S / 160); ctx.setLineDash([S / 40, S / 40]);
      for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(i * w, 0); ctx.lineTo(i * w + S, S); ctx.stroke(); ctx.beginPath(); ctx.moveTo(i * w + S, 0); ctx.lineTo(i * w, S); ctx.stroke(); }
      ctx.setLineDash([]);
    },
    waves(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.strokeStyle = b; ctx.lineWidth = S / 40;
      for (let i = 0; i < 6; i++) {
        ctx.beginPath();
        for (let x = 0; x <= S; x += S / 32) { const y = (i + 0.5) * (S / 6) + Math.sin((x / S) * Math.PI * 4) * S / 30; x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
        ctx.stroke();
      }
    },
    'barber-pole'(ctx, S, a, b) {
      ctx.fillStyle = '#f2efe6'; ctx.fillRect(0, 0, S, S);
      const cols = [a, '#f2efe6', b, '#f2efe6'], w = S / 4;
      ctx.save(); ctx.beginPath(); ctx.rect(0, 0, S, S); ctx.clip();
      for (let i = -4; i < 8; i++) {
        ctx.fillStyle = cols[((i % 4) + 4) % 4];
        ctx.beginPath(); ctx.moveTo(i * w, 0); ctx.lineTo(i * w + w, 0); ctx.lineTo(i * w + w - S, S); ctx.lineTo(i * w - S, S); ctx.closePath(); ctx.fill();
      }
      ctx.restore();
    },
    floral(ctx, S, a, b, R) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S);
      for (let i = 0; i < 12; i++) {
        const x = R.next() * S, y = R.next() * S, r = S * (0.06 + 0.025 * R.next()), rot = R.next() * 6;
        wrapped(ctx, S, () => {
          ctx.fillStyle = b;
          for (let k = 0; k < 5; k++) { const ang = rot + (k / 5) * Math.PI * 2; ctx.beginPath(); ctx.ellipse(x + Math.cos(ang) * r, y + Math.sin(ang) * r, r * 0.75, r * 0.45, ang, 0, 7); ctx.fill(); }
          ctx.fillStyle = lum(b) > 0.5 ? shade(b, -0.5) : '#f6d44a'; ctx.beginPath(); ctx.arc(x, y, r * 0.42, 0, 7); ctx.fill();
        });
      }
    },
    palms(ctx, S, a, b, R) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.fillStyle = b;
      for (let i = 0; i < 9; i++) {
        const x = R.next() * S, y = R.next() * S, s = S * (0.12 + 0.04 * R.next()), rot = R.next() * 6;
        wrapped(ctx, S, () => {
          for (let k = 0; k < 7; k++) {
            const ang = rot + (k / 7) * Math.PI * 2;
            ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
            ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(s * 0.5, -s * 0.36, s, 0); ctx.quadraticCurveTo(s * 0.5, s * 0.2, 0, 0); ctx.fill();
            ctx.restore();
          }
        });
      }
    },
    scissors(ctx, S, a, b) {
      ctx.fillStyle = a; ctx.fillRect(0, 0, S, S); ctx.strokeStyle = b; ctx.fillStyle = b; ctx.lineWidth = Math.max(3, S / 30);
      const n = 4, c = S / n;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        ctx.save(); ctx.translate(x * c + c / 2 + (y % 2 ? c / 2 : 0), y * c + c / 2); ctx.rotate(y % 2 ? 0.6 : -0.6);
        const s = c * 0.44;
        ctx.beginPath(); ctx.arc(-s * 0.45, s * 0.55, s * 0.26, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.arc(s * 0.45, s * 0.55, s * 0.26, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(-s * 0.4, s * 0.38); ctx.lineTo(s * 0.2, -s * 0.85); ctx.lineTo(-s * 0.02, -s * 0.85); ctx.lineTo(-s * 0.18, s * 0.38); ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.moveTo(s * 0.4, s * 0.38); ctx.lineTo(-s * 0.2, -s * 0.85); ctx.lineTo(s * 0.02, -s * 0.85); ctx.lineTo(s * 0.18, s * 0.38); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    },
  };

  HSC.drawPattern = function (ctx, S, name, a, b, seed = 7) {
    const fn = P[name] || P.solid;
    ctx.save();
    ctx.clearRect(0, 0, S, S);
    fn(ctx, S, a, b, HSC.rng(seed));
    ctx.restore();
  };
  HSC.colourTools = { hexRgb, rgbHex, shade, mix, lum };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Wardrobe (the hanger button): the clippers and robes the player owns, two rows at a time (arrows and a
// page number when there are more; the one worn first, then the newest), tap one to wear it. Each day
// there is exactly one new clipper and one new robe on offer (the same for every player that day), with
// a countdown to midnight: one rewarded video unlocks it and puts it on. When the day ends the offer is
// gone. The red dot on the hanger
// comes up once a day while a pick is waiting. Wordless: icons, numbers and pictures of the designs.
// Designs come from catalog.js; progress is saved through the platform storage.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const C = () => HSC.catalog;
  const KEY = 'skin-fade-studio-rewards-v4';
  const INK = '#2a1d15';

  const W = {
    data: null, // { v, own: { clipper: bits, gown: bits } (base64), look: { clipper: id, gown: id }, progress: { key: videos }, dotDay, pick: { day, clipper: key, gown: key }, recent: [keys, newest last] }
    bits: null, // the owned designs, one bit each: { clipper: Uint8Array, gown: Uint8Array }
    client: null,
    game: null,
    clipper: null, // { body:[materials], accent:[...], light:[...], dark:[...] }
    gown: null, // { cloth, collar }
    T: null,
    tex: {},
    preview: { clipper: null, gown: null }, // try-on / trial designs shown without owning them
  };
  HSC.wardrobe = W;

  const today = () => { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); };
  const hash = (str) => { let h = 2166136261; for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };
  const TOOLS = ['clipper', 'gown'];
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const toB64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 3) { const n = (u8[i] << 16) | ((u8[i + 1] || 0) << 8) | (u8[i + 2] || 0); s += B64[n >> 18] + B64[(n >> 12) & 63] + B64[(n >> 6) & 63] + B64[n & 63]; } return s; };
  const fromB64 = (str, len) => { const u8 = new Uint8Array(len); if (!/^[A-Za-z0-9+/]*$/.test(str)) return u8; /* corrupt: nothing owned but the free designs */ let k = 0; for (let i = 0; i + 3 < str.length + 1 && k < len; i += 4) { const n = (B64.indexOf(str[i]) << 18) | (B64.indexOf(str[i + 1]) << 12) | (B64.indexOf(str[i + 2]) << 6) | B64.indexOf(str[i + 3]); for (const v of [n >> 16, (n >> 8) & 255, n & 255]) if (k < len) u8[k++] = v & 255; } return u8; };
  const bytes = (tool) => Math.ceil(C().designs[tool].length / 8);
  const split = (key) => { const c = key.indexOf(':'); return [key.slice(0, c), +key.slice(c + 1)]; };
  const owns = (key) => { const [t, i] = split(key); const b = W.bits && W.bits[t]; return !!b && i >= 0 && ((b[i >> 3] >> (i & 7)) & 1) === 1; };
  function setOwned(key) {
    const [t, i] = split(key);
    W.bits[t][i >> 3] |= 1 << (i & 7);
    W.data.own[t] = toB64(W.bits[t]);
  }

  function fresh() {
    return { v: 4, own: {}, look: Object.assign({}, C().DEFAULT_LOOK), progress: {}, dotDay: null, pick: null };
  }
  function sanitize(d) {
    const f = fresh();
    if (!d || typeof d !== 'object' || d.v !== 4) d = f;
    W.bits = {};
    for (const t of TOOLS) W.bits[t] = typeof (d.own && d.own[t]) === 'string' ? fromB64(d.own[t], bytes(t)) : new Uint8Array(bytes(t));
    const pk = d.pick && typeof d.pick.day === 'string' && C().byKey.has(d.pick.clipper) && C().byKey.has(d.pick.gown) ? { day: d.pick.day, clipper: d.pick.clipper, gown: d.pick.gown } : null;
    const recent = Array.isArray(d.recent) ? d.recent.filter((k) => typeof k === 'string' && C().byKey.has(k)) : [];
    const out = { v: 4, own: {}, look: Object.assign({}, f.look), progress: {}, dotDay: typeof d.dotDay === 'string' ? d.dotDay : null, pick: pk, recent };
    W.data = out;
    for (const k of C().FREE) setOwned(k);
    for (const t of TOOLS) {
      out.own[t] = toB64(W.bits[t]);
      const id = d.look && d.look[t];
      if (id != null && owns(t + ':' + id)) out.look[t] = String(id);
    }
    if (d.progress && typeof d.progress === 'object') for (const [k, n] of Object.entries(d.progress)) if (C().byKey.has(k) && Number.isSafeInteger(n) && n > 0) out.progress[k] = n;
    return out;
  }
  function save() {
    if (W.client && W.client.saveProgress) W.client.saveProgress(KEY, W.data).catch(() => {});
  }
  const track = (name, payload) => { try { W.client && W.client.sendAnalytics && W.client.sendAnalytics(name, payload); } catch (e) {} };

  // ---------------- 3D ----------------
  HSC.attachClipper = function (group) {
    // the game's clipper model; tell its parts apart by their original colours
    const parts = { body: new Set(), accent: new Set(), light: new Set(), dark: new Set() };
    const hex = (m) => (m && m.color ? m.color.getHexString() : '');
    group.traverse((o) => {
      if (!o.isMesh || o === group.userData.comb) return;
      const h = hex(o.material);
      if (h === '25282b') parts.body.add(o.material);
      else if (h === '141516') parts.accent.add(o.material);
      else if (h === 'cfd5da' || h === 'b9bfc4') parts.light.add(o.material);
      else if (h === '8a9298') parts.dark.add(o.material);
    });
    W.clipper = Object.fromEntries(Object.entries(parts).map(([k, s]) => [k, [...s]]));
    applyLook();
  };
  HSC.attachGown = function (robe, T) {
    W.T = T;
    const meshes = [];
    robe.traverse((o) => o.isMesh && meshes.push(o));
    // the robe is the larger mesh, the collar band the other
    meshes.sort((a, b) => b.geometry.attributes.position.count - a.geometry.attributes.position.count);
    W.gown = { cloth: meshes[0] && meshes[0].material, collar: meshes[1] && meshes[1].material, robe };
    applyLook();
  };

  function patternTexture(name, key, a, b, size, flipY, repeat) {
    if (!W.T) return null;
    const cv = document.createElement('canvas');
    cv.width = cv.height = size;
    HSC.drawPattern(cv.getContext('2d'), size, name, a, b, 11);
    const t = new W.T.Fg(cv);
    t.colorSpace = W.T.Lt;
    t.wrapS = t.wrapT = W.T.Pn;
    t.flipY = flipY;
    t.repeat.set(repeat[0], repeat[1]);
    t.anisotropy = 4;
    if (W.tex[key]) W.tex[key].dispose();
    W.tex[key] = t;
    return t;
  }
  const hexOf = (id) => C().colourHex.get(id) || '#888888';
  const finishOf = (id) => C().finishes.get(id) || C().finishes.get('chrome');
  const design = (tool, id) => C().byKey.get(tool + ':' + id) || C().byKey.get(tool + ':' + C().DEFAULT_LOOK[tool]);
  const worn = (tool) => design(tool, W.preview[tool] || W.data.look[tool]);

  function applyLook() {
    if (!W.data) return;
    if (W.clipper && W.T) {
      const c = worn('clipper').parts, body = hexOf(c.body), accent = hexOf(c.accent), fin = finishOf(c.finish);
      const tex = patternTexture(c.pattern, 'clipper', body, accent, 256, true, [2, 1]);
      for (const m of W.clipper.body) { m.color.set('#ffffff'); m.map = tex; m.needsUpdate = true; }
      for (const m of W.clipper.accent) m.color.set(accent);
      for (const [list, col] of [[W.clipper.light, fin.light], [W.clipper.dark, fin.dark]]) for (const m of list) {
        m.color.set(col); m.metalness = fin.metal; m.roughness = fin.rough; m.needsUpdate = true;
      }
    }
    if (W.gown && W.gown.cloth && W.T) {
      const g = worn('gown').parts, main = hexOf(g.main), second = hexOf(g.second);
      const tall = g.pattern === 'yoke' || g.pattern === 'fade';
      const tex = patternTexture(g.pattern, 'gown', main, second, 512, false, tall ? [6, 1] : [6, 2.5]);
      const cloth = W.gown.cloth;
      cloth.color.set('#ffffff');
      cloth.map = tex;
      if (cloth.sheenColor) cloth.sheenColor.set(HSC.colourTools.mix(main, '#ffffff', 0.45));
      cloth.needsUpdate = true;
      if (W.gown.collar) W.gown.collar.color.set(hexOf(g.collar));
    }
    HSC.clippingsCape && HSC.clippingsCape(W.gown && W.gown.robe);
  }

  // ---------------- pictures of the designs ----------------
  function drawClipper(cv, p) {
    const ctx = cv.getContext('2d'), k = cv.width / 440;
    ctx.clearRect(0, 0, cv.width, cv.height); ctx.save(); ctx.scale(k, k); ctx.lineJoin = 'round';
    const body = hexOf(p.body), accent = hexOf(p.accent), fin = finishOf(p.finish);
    const tile = document.createElement('canvas'); tile.width = tile.height = 256;
    HSC.drawPattern(tile.getContext('2d'), 256, p.pattern, body, accent, 11);
    const cx = 220, path = new Path2D();
    path.moveTo(cx - 70, 330); path.lineTo(cx - 84, 190); path.quadraticCurveTo(cx - 84, 70, cx, 62); path.quadraticCurveTo(cx + 84, 70, cx + 84, 190); path.lineTo(cx + 70, 330); path.closePath();
    ctx.save(); ctx.clip(path); ctx.drawImage(tile, cx - 100, 50, 200, 290); ctx.restore();
    const sh = ctx.createLinearGradient(cx - 84, 0, cx + 84, 0);
    sh.addColorStop(0, '#00000040'); sh.addColorStop(0.35, '#ffffff38'); sh.addColorStop(0.55, '#ffffff00'); sh.addColorStop(1, '#00000050');
    ctx.fillStyle = sh; ctx.fill(path); ctx.lineWidth = 6; ctx.strokeStyle = INK; ctx.stroke(path);
    ctx.fillStyle = accent;
    for (const x of [cx - 62, cx + 48]) { ctx.beginPath(); ctx.roundRect(x, 150, 14, 140, 7); ctx.fill(); ctx.lineWidth = 3; ctx.stroke(); }
    ctx.beginPath(); ctx.roundRect(cx - 12, 108, 24, 46, 6); ctx.fill(); ctx.lineWidth = 3; ctx.stroke();
    const g = ctx.createLinearGradient(0, 330, 0, 380); g.addColorStop(0, fin.light); g.addColorStop(0.5, '#fff'); g.addColorStop(1, fin.dark);
    ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(cx - 96, 326, 192, 40, 8); ctx.fill(); ctx.lineWidth = 5; ctx.stroke();
    ctx.fillStyle = fin.dark; for (let i = 0; i < 17; i++) ctx.fillRect(cx - 90 + i * 11, 366, 6, 16);
    ctx.restore();
  }
  function drawGown(cv, p) {
    const ctx = cv.getContext('2d'), k = cv.width / 440;
    ctx.clearRect(0, 0, cv.width, cv.height); ctx.save(); ctx.scale(k, k); ctx.lineJoin = 'round';
    const main = hexOf(p.main), second = hexOf(p.second), collar = hexOf(p.collar);
    const tile = document.createElement('canvas'); tile.width = tile.height = 256;
    HSC.drawPattern(tile.getContext('2d'), 256, p.pattern, main, second, 11);
    const cx = 220, path = new Path2D();
    path.moveTo(cx - 60, 92); path.quadraticCurveTo(cx - 150, 120, cx - 175, 210); path.lineTo(cx - 190, 400);
    path.quadraticCurveTo(cx, 420, cx + 190, 400); path.lineTo(cx + 175, 210); path.quadraticCurveTo(cx + 150, 120, cx + 60, 92); path.closePath();
    ctx.save(); ctx.clip(path);
    // patterns drawn large enough that motifs (palms, scissors, flowers) read on a small gallery tile
    for (let y = 70; y < 430; y += 190) for (let x = cx - 200; x < cx + 200; x += 190) ctx.drawImage(tile, x, y, 190, 190);
    const sh = ctx.createLinearGradient(cx - 190, 0, cx + 190, 0); sh.addColorStop(0, '#00000045'); sh.addColorStop(0.4, '#ffffff22'); sh.addColorStop(1, '#00000045');
    ctx.fillStyle = sh; ctx.fillRect(0, 0, 440, 440); ctx.restore();
    ctx.lineWidth = 6; ctx.strokeStyle = INK; ctx.stroke(path);
    ctx.beginPath(); ctx.ellipse(cx, 96, 64, 22, 0, 0, Math.PI * 2); ctx.fillStyle = collar; ctx.fill(); ctx.lineWidth = 5; ctx.stroke();
    ctx.beginPath(); ctx.ellipse(cx, 92, 44, 13, 0, 0, Math.PI * 2); ctx.fillStyle = '#e4cdb0'; ctx.fill(); ctx.lineWidth = 3; ctx.stroke();
    ctx.restore();
  }
  // drawn on demand and kept for the most recent few hundred (tiles are drawn as they scroll into view)
  const pics = new Map();
  function picture(d, size = 160) {
    const key = d.key + '|' + size;
    let url = pics.get(key);
    if (url) { pics.delete(key); pics.set(key, url); return url; }
    const cv = document.createElement('canvas');
    cv.width = cv.height = size;
    (d.tool === 'clipper' ? drawClipper : drawGown)(cv, d.parts);
    url = cv.toDataURL();
    pics.set(key, url);
    if (pics.size > 300) pics.delete(pics.keys().next().value);
    return url;
  }

  // ---------------- unlocking ----------------
  const canVideo = () => !!(W.client && W.client.rewardedSupported && W.client.showRewarded);
  async function watchVideo(placement) {
    const c = W.client;
    if (!canVideo()) return false;
    let ok = false;
    try { ok = !!(await c.showRewarded(placement)); } catch (e) {}
    if (ok) HSC.lastRewardAt = Date.now();
    return ok;
  }
  // a rewarded video in the last minute: the next interstitial is skipped
  HSC.watchVideo = watchVideo;
  HSC.nope = (el) => { el.classList.remove('hsc-nope'); void el.offsetWidth; el.classList.add('hsc-nope'); setTimeout(() => el.classList.remove('hsc-nope'), 500); };
  HSC.canVideo = canVideo;
  HSC.recentReward = () => !!HSC.lastRewardAt && Date.now() - HSC.lastRewardAt < 60000;
  // one watched video toward a design: 'unlocked' when it has all it needs, else 'progress'
  function grant(d, via) {
    if (owns(d.key)) return 'unlocked';
    const n = (W.data.progress[d.key] || 0) + 1;
    if (n >= C().VIDEOS(d)) {
      delete W.data.progress[d.key];
      setOwned(d.key);
      W.data.recent = W.data.recent.filter((k) => k !== d.key).concat(d.key);
      track('rewards_unlock', { item: d.key, via });
      save();
      return 'unlocked';
    }
    W.data.progress[d.key] = n;
    save();
    return 'progress';
  }
  function equip(tool, id) {
    W.data.look[tool] = id;
    if (W.preview[tool] === id) W.preview[tool] = null;
    save();
    applyLook();
  }
  // today's clipper and robe: the same for every player that day, never one the player owns; a new day
  // brings new picks
  function picks() {
    const day = today();
    if (W.data.pick && W.data.pick.day === day) return W.data.pick;
    const old = W.data.pick;
    if (old) for (const t of TOOLS) delete W.data.progress[old[t]];
    const pick = { day };
    for (const t of TOOLS) {
      const all = C().designs[t], n = all.length;
      let i = hash(day + '|' + t) % n;
      for (let k = 0; k < n && (owns(all[i].key) || C().FREE.has(all[i].key)); k++) i = (i + 1) % n;
      pick[t] = all[i].key;
    }
    W.data.pick = pick;
    save();
    return pick;
  }
  // time left today, as the countdown shows it (h:mm:ss, or m:ss in the last hour)
  function timeLeft() {
    const now = new Date(), start = new Date(now.getFullYear(), now.getMonth(), now.getDate()), end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const t = Math.max(0, Math.floor((end - now) / 1000)), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
    const two = (v) => String(v).padStart(2, '0');
    // the ring around the pick drains with the day: green, orange from 6 h, red from 2 h, a heartbeat at the end
    return { text: h ? `${h}:${two(m)}:${two(sec)}` : `${m}:${two(sec)}`, low: t < 2 * 3600, lvl: t < 2 * 3600 ? 'r' : t < 6 * 3600 ? 'o' : 'g', last: t < 600, frac: Math.max(0, Math.min(1, (t * 1000) / Math.max(1, end - start))) };
  }

  // ---------------- UI ----------------
  // the UI scale: 1 on phones (short side 300-560 px), up to 2.4 on big screens, down to 0.6 in tiny embeds
  HSC.uiScale = () => {
    const m = Math.min(innerWidth, innerHeight);
    return +(m < 300 ? Math.max(0.6, m / 300) : Math.min(2.4, Math.max(1, m / 560))).toFixed(3);
  };
  HSC.applyScale = () => {
    const s = HSC.uiScale();
    if (s !== HSC.S) { HSC.S = s; document.documentElement.style.setProperty('--hsc-s', String(s)); }
  };
  HSC.applyScale();
  const RING = '<svg class="hsc-ring" viewBox="0 0 140 140" aria-hidden="true"><circle class="trk" cx="70" cy="70" r="62"/><g transform="rotate(-90 70 70) translate(0 140) scale(1 -1)"><circle class="arc out" cx="70" cy="70" r="62"/><circle class="arc col" cx="70" cy="70" r="62"/></g></svg>';
  const ICON = {
    hanger: '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 7a2 2 0 1 1 2-2"/><path d="M12 7v1.5L3 15a1.5 1.5 0 0 0 1 2.7h16a1.5 1.5 0 0 0 1-2.7l-9-6.5"/></svg>',
    clock: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><circle cx="12" cy="13" r="8.5"/><path d="M12 8.5V13l3 2"/><path d="M9.5 2.5h5"/></svg>',
    // the same icon as the game's clipper on / off button
    clipper: '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="8" width="10" height="14" rx="3"/><path d="M6 4h12v4H6z"/><path d="M8 4V2M11 4V2M14 4V2M17 4V2"/></svg>',
    arrow: (dir) => `<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="${dir < 0 ? 'M15 5l-7 7 7 7' : 'M9 5l7 7-7 7'}"/></svg>`,
    gown: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linejoin="round"><path d="M9 3h6l1 2 5 3-2 13H5L3 8l5-3z"/><path d="M9 3a3 3 0 0 0 6 0"/></svg>',
    close: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    tick: (s = 20) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="3.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`,
    spark: (s = 34) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}"><path d="M12 1.5l2.2 7.3 7.3 2.2-7.3 2.2L12 20.5l-2.2-7.3L2.5 11l7.3-2.2z" fill="#ffe14d" stroke="${INK}" stroke-width="1.8" stroke-linejoin="round"/></svg>`,
  };
  // the one icon that means "watch a video": a little screen with a play triangle
  const AD = (s = 26) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}"><rect x="2.5" y="4.5" width="19" height="13.5" rx="2.6" fill="#fff6e6" stroke="${INK}" stroke-width="2.2"/><path d="M10 8.2v6.2l5.3-3.1z" fill="${INK}"/><path d="M8 21h8" stroke="${INK}" stroke-width="2.2" stroke-linecap="round"/></svg>`;
  HSC.AD_ICON = AD;
  // the video badge of a locked design
  const videoBadge = (d, s = 24) => {
    const need = C().VIDEOS(d), done = W.data.progress[d.key] || 0;
    return Array.from({ length: need }, (_, i) => (i < done ? `<b class="done">${ICON.tick(s * 0.7)}</b>` : AD(s))).join('');
  };

  const CSS = `
/* every control layer is laid out at phone size and drawn at the screen's scale (--hsc-s, set from the
   short side of the screen): percentages stay true to the screen, pixel sizes and gaps scale together */
.ui,#hsc-hud,#hsc-panel,#hsc-hub{zoom:var(--hsc-s,1)}
#hsc-hud,#hsc-panel,#hsc-hub{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
.hsc-art img,.hsc-tile img{pointer-events:none;-webkit-user-drag:none}
/* just after a screen goes away, the controls under the finger ignore the second tap of a double tap */
body.hsc-settle .ui button,body.hsc-settle #hsc-hud *,body.hsc-settle .hsc-replay{pointer-events:none!important}
#hsc-hud{position:fixed;left:0;top:0;z-index:20;pointer-events:none;font-family:"DM Sans",system-ui,-apple-system,"Segoe UI",sans-serif;color:${INK};transition:opacity .25s}
#hsc-hud .hsc-row{position:absolute;display:flex;gap:8px;align-items:center}
.hsc-btn{pointer-events:auto;position:relative;width:48px;height:48px;border-radius:50%;display:grid;place-items:center;background:#fff6e6;border:3px solid ${INK};box-shadow:0 3px 0 ${INK};color:${INK};cursor:pointer;padding:0}
.hsc-btn:active{transform:translateY(3px);box-shadow:0 1px 0 ${INK}}
.hsc-dot{position:absolute;right:-4px;top:-4px;width:17px;height:17px;border-radius:50%;background:#ff3b30;border:2.5px solid ${INK};animation:hsc-dotpulse 1.2s ease-in-out infinite}
.hsc-dot[hidden]{display:none}
@keyframes hsc-dotpulse{50%{transform:scale(1.18)}}
.hsc-pill{pointer-events:auto;height:36px;padding:0 12px 0 6px;border-radius:18px;display:flex;gap:6px;align-items:center;background:#fff6e6;border:3px solid ${INK};box-shadow:0 3px 0 ${INK};font-weight:800;font-size:18px;font-variant-numeric:tabular-nums}
#hsc-panel{position:fixed;inset:0;z-index:30;display:none;background:#2a1d1599;font-family:"DM Sans",system-ui,-apple-system,"Segoe UI",sans-serif;color:${INK};touch-action:manipulation}
#hsc-panel.open{display:flex;align-items:flex-end;justify-content:center}
.hsc-sheet{position:relative;width:min(100%,600px);max-height:min(92%,920px);overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;display:flex;flex-direction:column;gap:12px;background:#fff6e6;border:3px solid ${INK};border-bottom:0;border-radius:26px 26px 0 0;box-shadow:0 -4px 0 ${INK};padding:12px max(12px,env(safe-area-inset-right)) max(14px,env(safe-area-inset-bottom)) max(12px,env(safe-area-inset-left))}
@media (orientation:landscape){#hsc-panel.open{align-items:center}.hsc-sheet{border-radius:26px;border-bottom:3px solid ${INK};box-shadow:0 5px 0 ${INK};width:min(96%,900px);max-height:94%}}
.hsc-head{display:flex;gap:8px;align-items:center}
.hsc-head .grow{flex:1}
.hsc-tab{width:60px;height:50px;border-radius:16px;display:grid;place-items:center;background:#f1e4cc;border:3px solid ${INK};box-shadow:0 3px 0 ${INK};color:${INK};cursor:pointer;padding:0;position:relative}
.hsc-tab[aria-selected=true]{background:#ffb627}
.hsc-tab .hsc-dot{right:-6px;top:-6px;width:14px;height:14px}
.hsc-x{width:48px;height:48px;border-radius:50%;display:grid;place-items:center;background:#fff6e6;border:3px solid ${INK};box-shadow:0 3px 0 ${INK};cursor:pointer;color:${INK};padding:0}
.hsc-pickwrap{padding:4px 6px 0}
.hsc-coll{display:flex;flex-direction:column;gap:12px;padding:6px 6px 8px}
@media (orientation:landscape){.hsc-sheet{display:grid;grid-template-columns:minmax(0,40%) minmax(0,1fr);grid-template-rows:auto auto;column-gap:16px}.hsc-head{grid-column:1/3}.hsc-pickwrap{align-self:start}}
.hsc-pager{display:flex;align-items:center;justify-content:center;gap:16px}
.hsc-pager[hidden]{display:none}
.hsc-arrow{width:56px;height:50px;border-radius:25px;display:grid;place-items:center;background:#ffb627;border:3px solid ${INK};box-shadow:0 3px 0 ${INK};color:${INK};cursor:pointer;padding:0}
.hsc-arrow:disabled{background:#e9dcc4;color:#a89a8a;box-shadow:0 1px 0 ${INK};cursor:default}
.hsc-arrow:not(:disabled):active{transform:translateY(3px);box-shadow:0 1px 0 ${INK}}
.hsc-page{min-width:70px;text-align:center;font-weight:900;font-size:19px;font-variant-numeric:tabular-nums}
.hsc-pick{position:relative;display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:24px;border:3px solid ${INK};box-shadow:0 5px 0 ${INK};background:radial-gradient(circle at 25% 50%,#fff,#ffe9a8 75%);color:${INK}}
.hsc-art{position:relative;flex:none;width:clamp(92px,34vw,140px);height:clamp(92px,34vw,140px);display:grid;place-items:center}
.hsc-art img{width:81%;height:81%;position:relative}
.hsc-ring{position:absolute;inset:0;width:100%;height:100%}
.hsc-ring .arc{fill:none;stroke-linecap:round}
.hsc-ring .trk{fill:none;stroke:#e9dcc4;stroke-width:11}
.hsc-ring .out{stroke:${INK};stroke-width:15}
.hsc-ring .col{stroke-width:9;stroke:#3fbf5a;transition:stroke .4s}
.hsc-pick.o .hsc-ring .col{stroke:#ff9f1c}.hsc-pick.r .hsc-ring .col{stroke:#ff3b30}
.hsc-pick.taken img{opacity:.45}
.hsc-pick.last{background:radial-gradient(circle at 25% 50%,#fff,#ffc7b8 75%);animation:hsc-alarm 1s ease-in-out infinite}
.hsc-pick.last .hsc-art{animation:hsc-beat 1s ease-in-out infinite}
@keyframes hsc-alarm{0%,100%{box-shadow:0 5px 0 ${INK},0 0 0 4px #ff4d3d55,0 0 14px 4px #ff4d3d66}50%{box-shadow:0 5px 0 ${INK},0 0 0 7px #ff4d3d77,0 0 28px 10px #ff4d3d99}}
@keyframes hsc-beat{0%,45%,100%{transform:scale(1)}12%{transform:scale(1.08)}24%{transform:scale(1.01)}34%{transform:scale(1.06)}}
@media (prefers-reduced-motion:reduce){.hsc-pick.last,.hsc-pick.last .hsc-art{animation:none}}
@media (orientation:landscape) and (max-height:430px){.hsc-sheet{grid-template-columns:minmax(0,46%) minmax(0,1fr)}.hsc-art{width:clamp(80px,14vw,104px);height:clamp(80px,14vw,104px)}.hsc-timer{font-size:15px;padding:0 9px;gap:5px}.hsc-timer svg{width:17px;height:17px}}
.hsc-pick .right{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;gap:10px}
.hsc-pick .right .hsc-vbtn{width:100%;max-width:250px}
/* the pick card sizes itself to its own column (landscape columns can be narrow): the picture gives way so the
   video button and the countdown always fit beside it */
.hsc-pickwrap{container-type:inline-size}
@container (max-width:345px){.hsc-art{width:108px;height:108px}}
@container (max-width:305px){.hsc-art{width:88px;height:88px}.hsc-timer{font-size:15px;padding:0 8px;gap:4px}.hsc-timer svg{width:17px;height:17px}}
@container (max-width:270px){.hsc-art{width:74px;height:74px}.hsc-pick{gap:8px;padding:8px}}
@media (max-width:360px){.hsc-timer{font-size:15px;padding:0 8px;gap:4px}.hsc-timer svg{width:17px;height:17px}.hsc-vbtn{height:62px}}
.hsc-vbtn{height:72px;border-radius:36px;display:flex;align-items:center;justify-content:center;gap:6px;background:#58c8f5;border:3px solid ${INK};box-shadow:0 4px 0 ${INK};cursor:pointer;color:${INK};padding:0;animation:hsc-breathe 1.3s ease-in-out infinite}
.hsc-vbtn:disabled{animation:none}
.hsc-vbtn:not(:disabled):active{transform:translateY(3px);box-shadow:0 1px 0 ${INK}}
.hsc-vbtn .done{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;background:#5ccf72;border:2px solid ${INK};color:${INK}}
.hsc-pick.taken .hsc-vbtn{background:#e9dcc4;color:#7d6e5f;box-shadow:0 2px 0 ${INK};animation:none;cursor:default}
@keyframes hsc-breathe{50%{transform:scale(1.04)}}
.hsc-timer{align-self:center;display:flex;align-items:center;gap:6px;height:34px;padding:0 12px;border-radius:17px;background:#fff6e6;border:2.5px solid ${INK};font-weight:900;font-size:17px;font-variant-numeric:tabular-nums}
.hsc-timer.g{background:#c8f0cf}.hsc-timer.o{background:#ffd27a}.hsc-timer.r{background:#ff3b30;color:#fff}
.hsc-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px 12px}
@media (orientation:landscape) and (min-height:431px){.hsc-grid{grid-template-columns:repeat(5,minmax(0,1fr))}}
.hsc-tile{position:relative;aspect-ratio:1;border-radius:18px;border:3px solid ${INK};box-shadow:0 3px 0 ${INK};background:radial-gradient(circle at 50% 40%,#fff,#f1e4cc 75%);display:grid;place-items:center;padding:0;cursor:pointer;color:${INK}}
.hsc-tile img{width:92%;height:92%;pointer-events:none}
.hsc-tile.cur{outline:4px solid #5ccf72;outline-offset:3px}
.hsc-tile .on{position:absolute;right:-10px;top:-10px;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:#5ccf72;border:3px solid ${INK}}
.hsc-tile .new{position:absolute;left:-12px;top:-14px;filter:drop-shadow(0 2px 0 ${INK})}
.hsc-tile.ghost{border-style:dashed;box-shadow:none;background:#f6ecd8;opacity:.6;cursor:default}
.hsc-tile:not(.ghost):active{transform:translateY(3px)}
.hsc-pop{animation:hsc-popin .5s cubic-bezier(.3,1.6,.5,1)}
.hsc-pickwrap[hidden]{display:none}
/* no video came: a short shake, the button stays ready */
.hsc-nope{animation:hsc-nope .45s ease-in-out!important}
@keyframes hsc-nope{20%,60%{transform:translateX(-7px)}40%,80%{transform:translateX(7px)}}
@keyframes hsc-popin{0%{transform:scale(.75)}100%{transform:scale(1)}}
/* the finish button in the top right: the same size as the buttons in the top left */
.ui .finish.seal,.ui[data-status=cutting] .ctl.finish.seal{width:48px!important;height:48px!important}
.ui .finish.seal svg:not(.seal-shape){width:24px;height:24px}
`;

  const ui = {
    tool: 'clipper',
    page: 0,
    el: {},
    busy: false,
    build() {
      const st = document.createElement('style');
      st.textContent = CSS;
      document.head.appendChild(st);
      const hud = document.createElement('div');
      hud.id = 'hsc-hud';
      hud.innerHTML = `<div class="hsc-row"><button class="hsc-btn hsc-rw" type="button" aria-label="Wardrobe">${ICON.hanger}<span class="hsc-dot" hidden></span></button></div>`;
      document.body.appendChild(hud);
      this.el.hud = hud;
      this.el.row = hud.querySelector('.hsc-row');
      this.el.btn = hud.querySelector('.hsc-rw');
      this.el.dot = hud.querySelector('.hsc-dot');
      this.el.btn.addEventListener('click', () => this.open());

      const panel = document.createElement('div');
      panel.id = 'hsc-panel';
      panel.innerHTML = `<div class="hsc-sheet" role="dialog" aria-label="Wardrobe">
        <div class="hsc-head">
          <button class="hsc-tab" data-tool="clipper" type="button" aria-label="Clippers">${ICON.clipper}<span class="hsc-dot" hidden></span></button>
          <button class="hsc-tab" data-tool="gown" type="button" aria-label="Robes">${ICON.gown}<span class="hsc-dot" hidden></span></button>
          <div class="grow"></div>
          ${HSC.setDetailSetting ? '<button class="hsc-btn hsc-detail" type="button" aria-label="Detail level"></button>' : ''}
          <button class="hsc-x" type="button" aria-label="Close">${ICON.close}</button>
        </div>
        <div class="hsc-pickwrap"></div>
        <div class="hsc-coll"><div class="hsc-grid"></div>
          <div class="hsc-pager" hidden><button class="hsc-arrow" data-dir="-1" type="button" aria-label="Previous">${ICON.arrow(-1)}</button><div class="hsc-page"></div><button class="hsc-arrow" data-dir="1" type="button" aria-label="Next">${ICON.arrow(1)}</button></div></div>
      </div>`;
      document.body.appendChild(panel);
      this.el.panel = panel;
      this.el.sheet = panel.querySelector('.hsc-sheet');
      this.el.pick = panel.querySelector('.hsc-pickwrap');
      this.el.grid = panel.querySelector('.hsc-grid');
      this.el.pager = panel.querySelector('.hsc-pager');
      this.el.pageNum = panel.querySelector('.hsc-page');
      panel.querySelectorAll('.hsc-arrow').forEach((b) => b.addEventListener('click', () => { this.page += +b.dataset.dir; this.render(); }));
      panel.querySelector('.hsc-head .hsc-x').addEventListener('click', () => this.close());
      panel.addEventListener('click', (e) => { if (e.target === panel) this.close(); });
      addEventListener('keydown', (e) => { if (e.key === 'Escape' && this.el.panel.classList.contains('open')) { e.preventDefault(); this.close(); } });
      // turning the device with the panel open: two rows of the new width
      try { matchMedia('(orientation: landscape)').addEventListener('change', () => { if (this.el.panel.classList.contains('open')) this.render(); }); } catch (e) {}
      panel.querySelectorAll('.hsc-tab').forEach((b) => b.addEventListener('click', () => { this.tool = b.dataset.tool; this.page = 0; this.render(); }));
      // the Android build keeps its detail-level button
      this.el.detail = panel.querySelector('.hsc-detail');
      if (this.el.detail) this.el.detail.addEventListener('click', () => {
        const order = ['auto', 'low', 'high'], D = HSC.detail;
        HSC.setDetailSetting(order[(order.indexOf(D.setting) + 1) % order.length]);
        this.drawDetail();
      });
      const place = () => { HSC.applyScale(); this.place(); if (this.el.panel.classList.contains('open')) this.render(); };
      addEventListener('resize', place);
      // keeps the button in place, the red dot up to date, and the countdown ticking
      setInterval(() => {
        place();
        const open = this.el.panel.classList.contains('open');
        if (open && this.day !== today()) this.render(); // midnight: today's new picks replace yesterday's
        else if (open) this.tickTimer();
        this.dot();
      }, 1000);
      place();
      this.dot();
    },
    place() {
      // sit to the right of the game's sound button (or in its place if there is none); the row is drawn at
      // the UI scale, so screen positions are divided by it
      const audio = document.querySelector('.audio-toggle'), S = HSC.S || 1;
      const r = audio ? audio.getBoundingClientRect() : null;
      this.el.row.style.left = r && r.width ? r.right / S + 8 + 'px' : 'max(12px, env(safe-area-inset-left))';
      this.el.row.style.top = r && r.height ? r.top / S + 'px' : 'max(12px, env(safe-area-inset-top))';
    },
    // the red dot: once a day, while today's pick is waiting
    waiting(tool) { return canVideo() && !owns(picks()[tool]); },
    dot() {
      if (!W.data || !this.el.dot) return;
      this.el.dot.hidden = !(W.data.dotDay !== today() && (this.waiting('clipper') || this.waiting('gown')));
      const fresh = W.data.dotDay !== today() || (this.openDot && this.el.panel.classList.contains('open'));
      this.el.panel.querySelectorAll('.hsc-tab').forEach((b) => { b.querySelector('.hsc-dot').hidden = !(fresh && this.waiting(b.dataset.tool)); });
    },
    open() {
      // open on the tab whose pick is still waiting
      if (!this.waiting(this.tool) && this.waiting(this.tool === 'clipper' ? 'gown' : 'clipper')) this.tool = this.tool === 'clipper' ? 'gown' : 'clipper';
      this.page = 0;
      this.render();
      this.openDot = W.data.dotDay !== today();
      this.dot();
      W.data.dotDay = today();
      save();
      this.el.panel.classList.add('open');
      this.fit();
      W.client && W.client.setPauseReason && W.client.setPauseReason('wardrobe', true);
      try { this.el.panel.querySelector('.hsc-x').focus({ preventScroll: true }); } catch (e) {}
    },
    close() {
      if (!this.el.panel.classList.contains('open')) return;
      this.el.panel.classList.remove('open');
      HSC.settle && HSC.settle();
      W.client && W.client.setPauseReason && W.client.setPauseReason('wardrobe', false);
      this.dot();
    },
    drawDetail() {
      if (!this.el.detail) return; // builds with one fixed detail level have no button
      const D = HSC.detail || { level: 'high', setting: 'auto' };
      const on = D.level === 'low' ? 1 : 3;
      const bar = (i, h) => `<rect x="${4 + i * 6}" y="${20 - h}" width="4.4" height="${h}" rx="1.2" fill="${i < on ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.6"/>`;
      this.el.detail.innerHTML = `<svg viewBox="0 0 24 24" width="26" height="26">${bar(0, 6)}${bar(1, 11)}${bar(2, 16)}${D.setting === 'auto' ? '<circle cx="5" cy="5" r="2.6" fill="#ff8a3d" stroke="currentColor" stroke-width="1.2"/>' : ''}</svg>`;
    },
    tickTimer() {
      const t = this.el.pick.querySelector('.hsc-timer');
      if (!t) return;
      const left = timeLeft();
      t.querySelector('span').textContent = left.text;
      const taken = !!t.dataset.taken, card = this.el.pick.querySelector('.hsc-pick');
      t.classList.toggle('low', left.low && !taken);
      for (const l of ['g', 'o', 'r']) { t.classList.toggle(l, !taken && left.lvl === l); card.classList.toggle(l, !taken && left.lvl === l); }
      card.classList.toggle('last', !taken && left.last);
      // what is left of the day, as an arc that empties anticlockwise towards the top (a red dot at the very end)
      const C = 2 * Math.PI * 62, len = Math.max(left.frac * C, left.frac > 0 ? 4 : 0);
      this.el.pick.querySelectorAll('.hsc-ring .arc').forEach((a) => a.setAttribute('stroke-dasharray', `${len.toFixed(1)} ${C.toFixed(1)}`));
    },
    render() {
      if (!W.data) return;
      this.drawDetail();
      const tool = this.tool, cur = W.data.look[tool];
      this.el.panel.querySelectorAll('.hsc-tab').forEach((b) => b.setAttribute('aria-selected', b.dataset.tool === tool ? 'true' : 'false'));
      // today's pick: one video and it is yours; the countdown runs to midnight
      const pk = picks(), d = C().byKey.get(pk[tool]), taken = owns(d.key);
      this.day = pk.day;
      // no rewarded videos on this platform: nothing to offer, only the wardrobe
      this.el.pick.hidden = !canVideo();
      const need = C().VIDEOS(d), done = W.data.progress[d.key] || 0;
      const badge = taken ? ICON.tick(34) : Array.from({ length: need }, (_, i) => (i < done ? `<b class="done">${ICON.tick(20)}</b>` : AD(need > 1 ? 40 : 46))).join('');
      this.el.pick.innerHTML = `<div class="hsc-pick${taken ? ' taken' : ''}"><div class="hsc-art">${taken ? '' : RING}<img src="${picture(d, 260)}" alt=""></div>
        <div class="right"><button class="hsc-vbtn" type="button" ${taken ? 'disabled' : ''} aria-label="${taken ? 'Yours: a new one tomorrow' : "Today's pick: watch a video to get it"}">${badge}</button>
        <div class="hsc-timer" ${taken ? 'data-taken="1"' : ''} aria-label="Time left today">${ICON.clock}<span></span></div></div></div>`;
      this.el.pick.querySelector('.hsc-vbtn').addEventListener('click', () => this.take(d));
      this.tickTimer();
      // everything the player owns: the one worn first, then the newest; one empty slot at the end hints that
      // there is more to get. Two rows at a time (only those pictures are drawn), arrows for the rest.
      const rank = new Map(W.data.recent.map((k, n) => [k, n]));
      const owned = C().designs[tool].filter((x) => owns(x.key))
        .sort((a, b) => ((b.id === cur) - (a.id === cur)) || ((rank.has(b.key) ? rank.get(b.key) : -1) - (rank.has(a.key) ? rank.get(a.key) : -1)) || a.i - b.i);
      // two rows; one on squat portrait screens (tiny square embeds), where two rows of tiles cannot fit
      const land = matchMedia('(orientation: landscape)').matches;
      const rows = !land && innerHeight / (HSC.S || 1) < 520 ? 1 : 2;
      const cols = land && matchMedia('(min-height: 431px)').matches ? 5 : 4, per = cols * rows;
      const items = [...owned, null], pages = Math.ceil(items.length / per);
      this.page = Math.max(0, Math.min(pages - 1, this.page));
      this.el.grid.innerHTML = items.slice(this.page * per, this.page * per + per).map((x) => (x
        ? `<button type="button" class="hsc-tile${x.id === cur ? ' cur' : ''}" data-key="${x.key}" aria-label="${x.id === cur ? 'Wearing' : 'Wear this'}"><img src="${picture(x)}" alt="">${x.id === cur ? `<span class="on">${ICON.tick(18)}</span>` : ''}${x.key === this.fresh ? `<span class="new">${ICON.spark(30)}</span>` : ''}</button>`
        : '<div class="hsc-tile ghost"></div>')).join('');
      this.el.pager.hidden = pages <= 1;
      this.el.pageNum.textContent = `${this.page + 1}/${pages}`;
      const [prev, next] = this.el.pager.querySelectorAll('.hsc-arrow');
      prev.disabled = this.page === 0;
      next.disabled = this.page >= pages - 1;
      for (const b of this.el.grid.querySelectorAll('.hsc-tile[data-key]')) b.addEventListener('click', () => {
        const x = C().byKey.get(b.dataset.key);
        // the worn design leads the wardrobe: back to the first page to see it there
        if (W.data.look[x.tool] !== x.id) { equip(x.tool, x.id); this.page = 0; this.render(); this.pop(x.key); }
      });
      this.fit();
    },
    fit() {
      const sh = this.el.sheet;
      if (!sh || !this.el.panel.classList.contains('open')) return;
      // the tiles follow the sheet's width, so a smaller drawing reflows taller: refine a few times
      let z = 1;
      sh.style.zoom = '';
      for (let i = 0; i < 6 && sh.scrollHeight > sh.clientHeight + 1 && z > 0.55; i++) {
        z = Math.max(0.55, z * (sh.clientHeight / sh.scrollHeight) * 0.995);
        sh.style.zoom = String(z);
      }
    },
    pop(key) {
      const t = this.el.grid.querySelector(`[data-key="${key}"]`);
      if (t) { t.classList.remove('hsc-pop'); void t.offsetWidth; t.classList.add('hsc-pop'); }
    },
    async take(d) {
      if (this.busy || owns(d.key)) return;
      this.busy = true;
      const b = this.el.pick.querySelector('.hsc-vbtn');
      b.disabled = true;
      const ok = await watchVideo('unlock-item');
      this.busy = false;
      if (!ok) { b.disabled = false; HSC.nope && HSC.nope(b); return; }
      if (grant(d, 'daily') === 'unlocked') { equip(d.tool, d.id); this.fresh = d.key; this.page = 0; this.render(); this.pop(d.key); }
      else this.render();
    },
  };

  HSC.wardrobeApply = () => applyLook();
  // for other modules: the current look, pictures of designs, and a design previewed without owning it
  HSC.rewards = {
    canVideo,
    owns: (key) => !!W.data && owns(key),
    preview(tool, id) { W.preview[tool] = id || null; applyLook(); },
    clearPreview() { W.preview = { clipper: null, gown: null }; applyLook(); },
    picture: (d, size) => picture(d, size),
  };
  HSC.wardrobeInit = async function ({ client, game }) {
    W.client = client;
    W.game = game;
    let d = null;
    try { d = client && client.loadProgress ? await client.loadProgress(KEY, null) : null; } catch (e) {}
    W.data = sanitize(d);
    try { ui.build(); } catch (e) { console.error('customers: rewards UI failed', e); }
    try { HSC.hubInit && HSC.hubInit(); } catch (e) { console.error('customers: hub failed', e); }
    applyLook();
    save();
  };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Completion screen: after the reveal spin only the finished customer (in the robe they came in with)
// and the next customer, docked against the next button, are left on screen; the top buttons hide.
// The barber level badge shows only on a level-up. The next customer is a real 3D render; a chime plays
// as the reveal lands, and the gown is brushed off. Also: the streak flame in the top bar.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const M = () => HSC.meta;
  const INK = '#2a1d15';

  // ---------------- next customer: a real render ----------------
  // The game's own thumbnail() renders the head with any hair grid. For a snapshot the next customer is
  // put on the head for one synchronous render, then the current customer is put back.
  const shots = new Map();
  function snapshot(person, profileId) {
    const key = JSON.stringify([person.seed, !!person.vip, person.beard.style, profileId]);
    if (shots.has(key)) return shots.get(key);
    const v = HSC.view, g = globalThis.skinFadeStudio, W = HSC.walkIns;
    if (!v || !v.thumbnail || !g || !W) return null;
    const s = g.getState();
    const prof = W.list.find((w) => w.id === profileId) || W.list.find((w) => w.contour === 'even');
    let url = null;
    HSC.snapshotting = true;
    try {
      HSC.setPerson(person);
      HSC.setBeard(HSC.beardStartFor(person));
      // their own hair colour (the game sets it only for the customer in the chair)
      if (v.setAppearance) v.setAppearance(person.hair.colour);
      url = v.thumbnail(W.build(prof), 160, 4, { size: 240, headOnly: true });
    } catch (e) {
      console.error('customers: snapshot failed', e);
    } finally {
      try { HSC.setPerson(s.look.person); HSC.setBeard(s.beard); if (v.setAppearance) v.setAppearance(s.look.colour != null ? s.look.colour : 1); } catch (e) {}
      HSC.snapshotting = false;
    }
    if (url) shots.set(key, url);
    if (shots.size > 12) shots.delete(shots.keys().next().value);
    return url;
  }

  // ---------------- reveal sound ----------------
  // synthesised (no audio files): a soft whoosh as the camera spins, a bright bell chime when it lands
  const sfx = { ctx: null, out: null, noise: null };
  const view = () => { try { return globalThis.skinFadeStudio.getView(); } catch (e) { return null; } };
  const audible = () => { const v = view(); return !!(v && v.audio && !v.paused); };
  function ac() {
    if (!sfx.ctx) {
      const C = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!C) return null;
      sfx.ctx = new C();
      sfx.out = sfx.ctx.createGain();
      sfx.out.connect(sfx.ctx.destination);
    }
    if (sfx.ctx.state === 'suspended') sfx.ctx.resume().catch(() => {});
    const v = view();
    sfx.out.gain.value = 0.55 * (v && typeof v.volume === 'number' ? v.volume : 1);
    return sfx.ctx;
  }
  function whoosh() {
    if (!audible()) return;
    const c = ac();
    if (!c) return;
    const t = c.currentTime;
    if (!sfx.noise) {
      sfx.noise = c.createBuffer(1, Math.round(c.sampleRate * 1.2), c.sampleRate);
      const d = sfx.noise.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    const src = c.createBufferSource(), bp = c.createBiquadFilter(), gn = c.createGain();
    src.buffer = sfx.noise;
    bp.type = 'bandpass'; bp.Q.value = 1.2;
    bp.frequency.setValueAtTime(420, t); bp.frequency.exponentialRampToValueAtTime(2600, t + 0.75);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(0.22, t + 0.3); gn.gain.exponentialRampToValueAtTime(0.0001, t + 1.05);
    src.connect(bp).connect(gn).connect(sfx.out);
    src.start(t); src.stop(t + 1.1);
  }
  function chime(levelUp) {
    if (!audible()) return;
    const c = ac();
    if (!c) return;
    const t0 = c.currentTime + 0.02;
    const notes = levelUp ? [1046.5, 1318.5, 1568, 2093, 2637] : [1046.5, 1318.5, 1568, 2093];
    notes.forEach((f, i) => {
      const t = t0 + i * 0.075;
      for (const [mul, amp] of [[1, 0.16], [2.76, 0.045], [5.4, 0.015]]) {
        const o = c.createOscillator(), g = c.createGain();
        o.type = 'sine'; o.frequency.value = f * mul;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(amp, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.3 / mul + 0.25);
        o.connect(g).connect(sfx.out);
        o.start(t); o.stop(t + 1.6);
      }
    });
    // a little sparkle on top
    for (let k = 0; k < 6; k++) {
      const t = t0 + 0.28 + k * 0.06 + Math.random() * 0.03;
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'triangle'; o.frequency.value = 3200 + Math.random() * 2600;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.03, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
      o.connect(g).connect(sfx.out);
      o.start(t); o.stop(t + 0.15);
    }
  }

  // ---------------- UI ----------------
  const ICON = {
    replay: '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 12a7.5 7.5 0 1 0 2.4-5.5"/><path d="M4.5 3.8v5h5"/></svg>',
    play: '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>',
    tick: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    star: '<svg viewBox="0 0 24 24" width="40" height="40"><path d="M12 2.5l2.9 6 6.6.8-4.9 4.5 1.3 6.5L12 17l-5.9 3.3 1.3-6.5L2.5 9.3l6.6-.8z" fill="#ffc83d" stroke="#2a1d15" stroke-width="2" stroke-linejoin="round"/></svg>',
    flame: '<svg viewBox="0 0 24 24" width="20" height="20"><path d="M12 2c1 4 5 6 5 11a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5 0 2 1 3 2 3 0-3-1-6 1-9.5z" fill="#ff8a3d" stroke="#2a1d15" stroke-width="2" stroke-linejoin="round"/></svg>',
    crown: '<svg viewBox="0 0 24 24" width="30" height="30"><path d="M3 18l1.5-11 5 5L12 4l2.5 8 5-5L21 18z" fill="#ffc83d" stroke="#2a1d15" stroke-width="2" stroke-linejoin="round"/></svg>',
    chev: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    spark: '<svg viewBox="0 0 24 24" width="26" height="26"><path d="M12 1.5l2.2 7.3 7.3 2.2-7.3 2.2L12 20.5l-2.2-7.3L2.5 11l7.3-2.2z" fill="#fff6e6" stroke="#2a1d15" stroke-width="1.8" stroke-linejoin="round"/></svg>',
    gown: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><path d="M9 3h6l1 2 5 3-2 13H5L3 8l5-3z"/></svg>',
    clipper: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><path d="M8 3h8a2 2 0 0 1 2 2v12H6V5a2 2 0 0 1 2-2z"/><path d="M5 17h14v3H5z"/></svg>',
  };
  const CSS = `
#hsc-hub{position:fixed;inset:0;z-index:19;pointer-events:none;font-family:"DM Sans",system-ui,-apple-system,"Segoe UI",sans-serif;color:${INK};opacity:0;transition:opacity .35s}
#hsc-hub.show{opacity:1}
#hsc-hub.show .hsc-hit{pointer-events:auto}
.hsc-level{position:absolute;right:max(14px,env(safe-area-inset-right));top:max(14px,env(safe-area-inset-top));display:flex;align-items:center;gap:6px;padding:4px 12px 4px 6px;border-radius:24px;background:#fff6e6;border:3px solid ${INK};box-shadow:0 3px 0 ${INK}}
.hsc-level b{position:relative;display:grid;place-items:center;width:40px;height:40px;margin:-6px 0}
.hsc-level b span{position:absolute;font-size:16px;font-weight:900;padding-top:3px}
.hsc-pips{display:flex;gap:4px}
.hsc-pips i{width:14px;height:14px;border-radius:50%;border:2.5px solid ${INK};background:#f1e4cc}
.hsc-pips i.on{background:#5ccf72}
.hsc-level.up{animation:hsc-pop .7s cubic-bezier(.3,1.6,.5,1) 2}
@keyframes hsc-pop{0%{transform:scale(1)}40%{transform:scale(1.25)}100%{transform:scale(1)}}
.hsc-next{position:absolute;width:92px;height:92px;border-radius:20px;border:3px solid ${INK};background:radial-gradient(circle at 50% 35%,#fff6e6,#e4d2b4);overflow:visible}
.hsc-next img{width:100%;height:100%;border-radius:17px;display:block;object-fit:cover}
#hsc-dock{position:fixed;display:none;border-radius:30px;background:#fff6e6;border:3px solid ${INK};box-shadow:0 4px 0 ${INK};pointer-events:none}
#hsc-dock.show{display:block;animation:hsc-in .3s ease-out}
@keyframes hsc-in{from{opacity:0;transform:translateY(8px)}}
.hsc-hint{position:absolute;color:${INK};animation:hsc-nudge 1s ease-in-out infinite}
@keyframes hsc-nudge{50%{transform:translateX(4px)}}
.hsc-new{position:absolute;right:-12px;top:-12px;animation:hsc-spin 2.4s linear infinite}
@keyframes hsc-spin{to{transform:rotate(360deg)}}
.hsc-flag{position:absolute;left:-8px;top:-10px}
.hsc-crown{position:absolute;left:50%;top:-20px;transform:translateX(-50%) rotate(-6deg)}
/* replay this customer: a video, so the video blue with the video icon as a subscript */
.hsc-replay{position:absolute;width:76px;height:76px;border-radius:50%;padding:0;display:grid;place-items:center;background:#58c8f5;color:${INK};border:3px solid ${INK};box-shadow:0 4px 0 ${INK};cursor:pointer;animation:hsc-rbreathe 1.3s ease-in-out infinite}
.hsc-replay .hsc-ad{position:absolute;right:-10px;bottom:-8px;width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#fff6e6;border:2.5px solid ${INK}}
.hsc-replay:disabled{animation:none;opacity:.6;cursor:default}
.hsc-replay:not(:disabled):active{transform:translateY(3px);box-shadow:0 1px 0 ${INK}}
@keyframes hsc-rbreathe{50%{transform:scale(1.05)}}
.hsc-replay[hidden]{display:none}
@media (prefers-reduced-motion:reduce){.hsc-replay{animation:none}}
body.hsc-reveal #hsc-hud,body.hsc-spin #hsc-hud{opacity:0;pointer-events:none;visibility:hidden}
#hsc-hub .hsc-next.hsc-hit{cursor:pointer}
body.hsc-reveal #hsc-hud *{pointer-events:none}
body.hsc-reveal .ui .top{visibility:hidden}
.hsc-level{opacity:0;transition:opacity .4s}
.hsc-level.up{opacity:1}
.hsc-streak[hidden],#hsc-hub [hidden]{display:none}
`;

  const st = { job: null, round: null, el: {}, built: false };

  function build() {
    if (st.built || !document.body) return;
    st.built = true;
    const style = document.createElement('style');
    style.textContent = CSS + TUT_CSS;
    document.head.appendChild(style);
    const hub = document.createElement('div');
    hub.id = 'hsc-hub';
    hub.innerHTML = `<div class="hsc-level" aria-label="Barber level"><b>${ICON.star}<span></span></b><div class="hsc-pips"></div></div>
      <div class="hsc-next hsc-hit" aria-hidden="true"><img alt=""></div>
      <span class="hsc-hint" aria-hidden="true">${ICON.chev}</span>
      <button class="hsc-replay hsc-hit" type="button" aria-label="Watch a video to cut this customer again">${ICON.replay}<span class="hsc-ad">${HSC.AD_ICON ? HSC.AD_ICON(26) : ''}</span></button>
`;
    document.body.appendChild(hub);
    st.el = {
      hub, level: hub.querySelector('.hsc-level'), levelNum: hub.querySelector('.hsc-level b span'), pips: hub.querySelector('.hsc-pips'),
      next: hub.querySelector('.hsc-next'), nextImg: hub.querySelector('.hsc-next img'), hint: hub.querySelector('.hsc-hint'),
      replay: hub.querySelector('.hsc-replay'),
    };
    st.el.replay.addEventListener('click', replay);
    // the next customer's picture is part of the next button
    st.el.next.addEventListener('click', () => { const b = document.querySelector('.training-continue'); if (b && !b.disabled) b.click(); });
    // a mouse or touch press does not leave a top button focused (Space / Enter stay with the game)
    document.addEventListener('click', (e) => { const a = document.activeElement; if (e.detail > 0 && a && a.tagName === 'BUTTON' && !a.closest('#hsc-panel')) setTimeout(() => a.blur(), 0); }, true);
    // the dock sits under the game's next button (inside the game root, before its HUD), so the next
    // customer and the next button read as one control
    const dock = document.createElement('div');
    dock.id = 'hsc-dock';
    const game = document.getElementById('game'), hud = document.getElementById('hud');
    if (game) game.insertBefore(dock, hud && hud.parentNode === game ? hud : null); else document.body.appendChild(dock);
    st.el.dock = dock;
    // the first tap anywhere lets the reveal sounds play later
    document.addEventListener('pointerdown', () => { if (audible()) ac(); }, true);
    // the next button hides the hub at once
    document.addEventListener('click', (e) => { if (e.target && e.target.closest && e.target.closest('.training-continue')) leaveReveal(); }, true);
    setInterval(tick, 150);
  }
  function streakChip() {
    const row = document.querySelector('#hsc-hud .hsc-row');
    if (!row) return;
    let chip = row.querySelector('.hsc-streak');
    if (!chip) {
      chip = document.createElement('div');
      chip.className = 'hsc-pill hsc-streak';
      chip.innerHTML = `${ICON.flame}<span></span>`;
      row.appendChild(chip);
    }
    const n = M() && M().data ? (M().streakNow ? M().streakNow() : M().data.streak) : 0;
    chip.hidden = n < 1;
    chip.querySelector('span').textContent = n;
    chip.setAttribute('aria-label', 'Days in a row: ' + n);
  }

  HSC.onHaircutDone = function (state) {
    if (!M() || !M().data) return;
    build();
    const info = M().onFinish(state);
    st.round = { job: state.jobId, info, shown: false };
    render();
    streakChip();
    HSC.brushClippings && HSC.brushClippings();
    whoosh();
  };

  function render() {
    if (!st.built || !st.round) return;
    const d = M().data, lv = M().levelOf(d.cuts), from = M().cutsFor(lv), to = M().cutsFor(lv + 1);
    st.el.levelNum.textContent = lv;
    st.el.pips.innerHTML = Array.from({ length: to - from }, (_, i) => `<i class="${i < d.cuts - from ? 'on' : ''}"></i>`).join('');
    st.el.level.classList.toggle('up', !!st.round.info && st.round.info.levelUp);
    st.el.level.setAttribute('aria-label', 'Barber level ' + lv);
    // next customer
    const q = d.queue && st.round.info && d.queue.job === st.round.info.job ? d.queue.person : null;
    st.el.next.hidden = !q;
    if (q) {
      const want = st.round.shown || st.round.ready, url = want ? snapshot(q, d.queue.profile) : null;
      if (url) st.el.nextImg.src = url;
      // no picture (the render failed): no card, never an older customer's picture
      else if (want) { st.el.next.hidden = true; return; }
      st.el.next.querySelectorAll('.hsc-new,.hsc-flag,.hsc-crown').forEach((n) => n.remove());
      if (q.vip) st.el.next.insertAdjacentHTML('beforeend', `<span class="hsc-crown">${ICON.crown}</span>`);
      const isNew = st.round.info.levelUp || q.daily;
      if (isNew) st.el.next.insertAdjacentHTML('beforeend', `<span class="hsc-new">${ICON.spark}</span>`);
      if (q.daily) st.el.next.insertAdjacentHTML('beforeend', `<span class="hsc-flag">${ICON.flame}</span>`);
    }
  }

  // one video, then the same customer walks back in with the hair they came with
  async function replay() {
    const g = globalThis.skinFadeStudio, b = st.el.replay, r = st.round;
    if (!g || !g.replay || b.disabled || !r || r.left || g.getState().status !== 'reveal') return;
    b.disabled = true;
    const ok = HSC.watchVideo ? await HSC.watchVideo('replay-customer') : false;
    const job = r.job, here = () => g.getState().status === 'reveal' && g.getState().jobId === job;
    if (ok && here()) {
      leaveReveal();
      // the game can stay paused for a while after the video (the platform resumes it): the replay is paid
      // for, so it waits until the game takes it, unless the player has moved on
      let done = false;
      const until = Date.now() + 120000;
      while (!done && here() && Date.now() < until) {
        done = await g.replay();
        if (!done) await new Promise((res) => setTimeout(res, 150));
      }
      if (!done && here()) r.left = false;
    } else if (!ok) HSC.nope && HSC.nope(b);
    b.disabled = false;
  }

  // the next customer docks right against the game's next button
  function layout() {
    const arrow = document.querySelector('.training-continue');
    if (!arrow) return;
    const r = arrow.getBoundingClientRect();
    if (!r.width) return;
    // worked out in screen pixels at the UI scale S; the hub layer is drawn at S, so its positions are divided
    // by S (the dock lives in the unscaled game root)
    const S = HSC.S || 1, px = (v) => v / S + 'px';
    const card = Math.round(Math.max(72 * S, Math.min(100 * S, r.height * 1.12))), gap = 22 * S, pad = 8 * S;
    const cx = r.left - gap - card, cy = r.top + r.height / 2 - card / 2;
    Object.assign(st.el.next.style, { left: px(cx), top: px(cy), width: px(card), height: px(card) });
    Object.assign(st.el.hint.style, { left: px(r.left - gap), top: px(r.top + r.height / 2 - 11 * S) });
    const top = Math.min(cy, r.top) - pad, bottom = Math.max(cy + card, r.bottom) + pad;
    Object.assign(st.el.dock.style, { left: cx - pad + 'px', top: top + 'px', width: r.right + pad - (cx - pad) + 'px', height: bottom - top + 'px', borderRadius: 30 * S + 'px', borderWidth: Math.max(2, 3 * S) + 'px' });
    // replay sits level with the next button, in the far corner from it
    const rb = st.el.replay, size = Math.round(Math.max(64 * S, Math.min(80 * S, r.height)));
    rb.hidden = !(HSC.canVideo && HSC.canVideo());
    const vw = innerWidth, onLeft = (cx + r.right) / 2 > vw / 2, dockL = cx - pad, dockR = r.right + pad;
    const midY = r.top + r.height / 2 - size / 2, sp = 16 * S, edgeMin = 12 * S;
    let rx, ry, side, stacked = false;
    if (innerHeight >= innerWidth) {
      // portrait: the mirror image of the next row, as far from its edge as the row is from the other edge;
      // too narrow to sit beside the row: above it, on the same side
      const gap2 = Math.max(18 * S, onLeft ? vw - dockR : dockL);
      rx = onLeft ? gap2 : vw - gap2 - size;
      const clash = onLeft ? rx + size + 10 * S > dockL : rx - 10 * S < dockR;
      ry = midY;
      side = onLeft ? 'left' : 'right';
      if (clash) stacked = true;
    } else {
      // landscape: the row sits beside the customer; replay joins it on its outer side (never over the
      // customer), or sits right above its outer end when there is no room beside it
      const outerLeft = (dockL + dockR) / 2 < vw / 2;
      const beside = outerLeft ? dockL - sp - size >= edgeMin : dockR + sp + size <= vw - edgeMin;
      if (beside) { rx = outerLeft ? dockL - sp - size : dockR + sp; ry = midY; }
      else stacked = true;
      side = 'left';
    }
    // no room beside the next row: the top-left corner instead (the top buttons are hidden on this screen),
    // lined up with where the sound button sits
    if (stacked) {
      const a = document.querySelector('.ui .top');
      const ar = a ? a.getBoundingClientRect() : null;
      rx = ar && ar.width ? ar.left : 12 * S;
      ry = ar && ar.height ? ar.top : 12 * S;
      side = 'left';
    }
    const gapPx = side === 'left' ? rx : vw - rx - size;
    side = `max(${gapPx / S}px, env(safe-area-inset-${side}))`;
    const onLeftSide = stacked || innerHeight < innerWidth ? true : onLeft;
    Object.assign(rb.style, { left: onLeftSide ? side : 'auto', right: onLeftSide ? 'auto' : side, top: px(ry), width: px(size), height: px(size) });
  }

  // a short pause on input after a screen goes away: the second tap of a double tap would land on what
  // appears under the finger (the clipper button sits where next was)
  let settleT = 0;
  HSC.settle = () => { document.body.classList.add('hsc-settle'); clearTimeout(settleT); settleT = setTimeout(() => document.body.classList.remove('hsc-settle'), 450); };

  // the player left the reveal
  function leaveReveal() {
    const r = st.round;
    if (!r || r.left) return;
    r.left = true;
    HSC.settle();
    st.el.hub && st.el.hub.classList.remove('show');
    st.el.dock && st.el.dock.classList.remove('show');
    document.body.classList.remove('hsc-reveal');
  }

  function tick() {
    const g = globalThis.skinFadeStudio;
    if (!g || !M() || !M().data) return;
    const s = g.getState(), v = g.getView();
    if (st.job !== s.jobId) {
      if (st.round && st.round.job !== s.jobId) { leaveReveal(); st.round = null; }
      st.job = s.jobId;
      streakChip();
    }
    const q0 = M().data.queue;
    if (s.status === 'reveal' && !st.round && (!q0 || q0.job !== s.jobId + 1) && !HSC.otherTab) {
      // a reload during the reveal, and the haircut never reached the progress save (the tab closed between
      // the two saves): count it now, so the next customer is chosen and shown
      HSC.onHaircutDone(s);
    }
    if (s.status === 'reveal' && !st.round) {
      // a reload during the reveal
      const cuts = M().data.cuts, q = M().data.queue;
      const levelUp = cuts > 0 && M().levelOf(cuts) > M().levelOf(cuts - 1) && !!q && q.job === s.jobId + 1;
      st.round = { job: s.jobId, info: { levelUp, job: s.jobId + 1 }, shown: false };
      render();
    }
    document.body.classList.toggle('hsc-spin', s.status === 'reveal' && !v.revealComplete);
    const show = s.status === 'reveal' && v.revealComplete && st.round && st.round.job === s.jobId && !st.round.left;
    if (show && !st.el.hub.classList.contains('show')) {
      // render the next customer now that the spin has stopped, then show everything
      st.round.ready = true;
      render();
      st.round.shown = true;
      st.el.hub.classList.add('show');
      st.el.dock.classList.add('show');
      document.body.classList.add('hsc-reveal');
      chime(!!(st.round.info && st.round.info.levelUp));
    }
    if (!show && st.el.hub.classList.contains('show')) { st.el.hub.classList.remove('show'); st.el.dock.classList.remove('show'); document.body.classList.remove('hsc-reveal'); }
    if (show) layout();
  }

  // ---------------- first-time "turn the customer" hint ----------------
  // One layout on every screen: the turn icon beside a dotted arc, the hand sweeping along it, the group
  // centred above the head. Only the arc scales with the head (60% of its width, it shows the motion over
  // the head); the icon and the hand keep the size of the game's other buttons and hints. The whole hint
  // ends just above the top of the hair and keeps clear of the top buttons.
  // Geometry at arc scale k, relative to the anchor (the arc's left end), in px:
  //   arc box   x -8k..132k, y -30k..10k (ends at y 0, top of the curve at -18k)
  //   icon 38px x -8k-50..-8k-12, y -26..12          hand 44x48 from (-10,-6), sweeping 118k to the right
  HSC.tutSpinLayout = function (head0, vw0) {
    // the hint is drawn at the UI scale: lay it out in its own (scaled) pixels, hand back screen pixels
    const S = HSC.S || 1;
    const head = { x: head0.x / S, top: head0.top / S, left: head0.left / S, right: head0.right / S }, vw = vw0 / S;
    const out = spinLayout(head, vw, S);
    return { left: out.left * S, top: out.top * S, k: out.k };
  };
  function spinLayout(head, vw, S) {
    const W = head.right - head.left;
    const hairTop = head.top - 0.11 * W; // the scalp top from the game, plus the hair standing on it
    const gap = 8;
    const tops = [...document.querySelectorAll('.ui .top > *, .ui .top button, #hsc-hud .hsc-row')]
      .map((e) => e.getBoundingClientRect()).map((r) => ({ left: r.left / S, right: r.right / S, top: r.top / S, bottom: r.bottom / S, width: r.width })).filter((r) => r.width && r.top < 160);
    const place = (k) => {
      const gl = -8 * k - 50, gr = Math.max(132 * k, 118 * k + 34);
      const left = Math.max(8 - gl, Math.min(vw - 8 - gr, head.x - (gl + 132 * k) / 2));
      const top = hairTop - gap - 42;
      const box = { l: left + gl, t: top + Math.min(-26, -20 * k), r: left + gr };
      const limit = Math.max(8, ...tops.filter((r) => r.right > box.l && r.left < box.r).map((r) => r.bottom + 6));
      return { left, top, k, fits: box.t >= limit, room: top - limit, below: limit + Math.max(26, 20 * k) };
    };
    let k = Math.max(0.6, Math.min(2.6, (0.6 * W) / 140));
    let p = place(k);
    // too little room for a tall curve: flatten (shrink) the arc, the icon and hand stay
    if (!p.fits && p.room > 26) { k = Math.max(0.6, Math.min(k, p.room / 20)); p = place(k); }
    // no room above the head at all (tiny screens): just below the top buttons, never under them
    if (!p.fits) p = Object.assign({}, p, { top: p.below });
    return { left: p.left, top: p.top, k };
  }
  const TUT_CSS = `
.tutorial.tut-spin .tut-path{left:calc(-8px * var(--k,1));top:calc(-30px * var(--k,1));width:calc(140px * var(--k,1));height:calc(40px * var(--k,1))}
.tutorial.tut-spin .tut-trail{vector-effect:non-scaling-stroke}
.tutorial.tut-spin .tut-tool{left:calc(-8px * var(--k,1) - 50px);top:-26px}
.tutorial.tut-spin .tut-hand{animation-name:hsc-across}
@keyframes hsc-across{0%,12%{transform:translateX(0);opacity:0}20%{opacity:1}80%{transform:translateX(calc(118px * var(--k,1)));opacity:1}100%{transform:translateX(calc(118px * var(--k,1)));opacity:0}}`;

  HSC.tutStyle = function (h) {
    const S = HSC.S || 1;
    if (S === 1 || !h) return h;
    const o = Object.assign({}, h);
    for (const k of ['left', 'top']) if (typeof o[k] === 'string' && o[k].endsWith('px')) o[k] = parseFloat(o[k]) / S + 'px';
    return o;
  };

  HSC.hubInit = function () {
    build();
    streakChip();
  };
})(globalThis.HSC || (globalThis.HSC = {}));

// ---------------------------------------------------------------------------------------------
// Falling hair: every clipper pass releases cut pieces the length of what was removed, in the
// customer's colour (with grey strands) and curl. They flutter down with air drag, tumble, land on
// the gown and settle (sliding off steep folds), and stay there until the next customer.
// World units: about 1 unit = 10 cm.
// ---------------------------------------------------------------------------------------------
(function (HSC) {
  'use strict';
  const MAX = 4000, SEG = 6;
  const G = 98; // gravity in world units / s^2
  const K = {
    pos: new Float32Array(MAX * 3), vel: new Float32Array(MAX * 3), dir: new Float32Array(MAX * 3), axis: new Float32Array(MAX * 3),
    spin: new Float32Array(MAX), len: new Float32Array(MAX), drag: new Float32Array(MAX), phase: new Float32Array(MAX),
    state: new Uint8Array(MAX), // 0 free, 1 falling, 2 sliding, 3 resting
    born: new Float64Array(MAX), col: new Float32Array(MAX * 3), curl: new Float32Array(MAX * 4),
    count: 0, next: 0, last: 0, moving: 0,
  };
  let mesh = null, geo = null, attrs = null, ctx = null, field = null, Rng = HSC.rng(4242);

  const VERT = `
attribute vec4 iPos;   // xyz centre, w length
attribute vec3 iDir;   // unit direction of the piece
attribute vec4 iCurl;  // curl radius (x length), turns, phase, width
attribute vec3 iCol;
varying vec3 vCol; varying float vShade; varying float vEdge;
void main(){
  float t=position.y-.5;
  vec3 d=normalize(iDir);
  vec3 up=abs(d.y)<.95?vec3(0.0,1.0,0.0):vec3(1.0,0.0,0.0);
  vec3 a=normalize(cross(d,up)),b=cross(d,a);
  float L=iPos.w;
  float ph=t*iCurl.y*6.2831+iCurl.z;
  vec3 p=iPos.xyz+d*(t*L)+(a*cos(ph)+b*sin(ph))*iCurl.x*L;
  vec3 tang=normalize(d*L+(-a*sin(ph)+b*cos(ph))*iCurl.x*L*iCurl.y*6.2831+vec3(1e-5));
  vec3 view=normalize(cameraPosition-p);
  vec3 side=normalize(cross(tang,view)+vec3(1e-5));
  p+=side*position.x*iCurl.w;
  vCol=iCol; vEdge=position.x;
  vShade=.62+.5*sqrt(max(0.0,1.0-pow(dot(tang,normalize(vec3(-.3,.8,.5))),2.0)));
  gl_Position=projectionMatrix*viewMatrix*vec4(p,1.0);
}`;
  const FRAG = `
varying vec3 vCol; varying float vShade; varying float vEdge;
void main(){
  if(abs(vEdge)>.98)discard;
  gl_FragColor=vec4(vCol*vShade,1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

  HSC.attachClippings = function (c) {
    ctx = c;
    const T = c.T;
    geo = new T.af();
    const pos = [], idx = [];
    for (let s = 0; s <= SEG; s++) {
      pos.push(-1, s / SEG, 0, 1, s / SEG, 0);
      if (s < SEG) { const u = s * 2; idx.push(u, u + 1, u + 2, u + 1, u + 3, u + 2); }
    }
    geo.setAttribute('position', new T.mt(pos, 3));
    geo.setIndex(idx);
    attrs = {
      iPos: new T.Ra(new Float32Array(MAX * 4), 4), iDir: new T.Ra(new Float32Array(MAX * 3), 3),
      iCurl: new T.Ra(new Float32Array(MAX * 4), 4), iCol: new T.Ra(new Float32Array(MAX * 3), 3),
    };
    for (const [k, a] of Object.entries(attrs)) { a.setUsage && a.setUsage(35048); geo.setAttribute(k, a); }
    geo.instanceCount = 0;
    mesh = new T.Ze(geo, new T.fr({ vertexShader: VERT, fragmentShader: FRAG, side: T.$t }));
    mesh.frustumCulled = false;
    mesh.renderOrder = 2;
    c.scene.add(mesh);
  };

  // heightfield of the gown's top surface (world space), rebuilt when the gown is attached / changed
  let robeRef = null;
  HSC.clippingsCape = function (robe) { if (robe) { robeRef = robe; field = null; } };
  function buildField(robe) {
    try {
      robe.updateWorldMatrix(true, true);
      const pts = [];
      robe.traverse((o) => {
        if (!o.isMesh) return;
        const p = o.geometry.attributes.position, m = o.matrixWorld.elements;
        for (let i = 0; i < p.count; i++) {
          const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
          pts.push(m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]);
        }
      });
      let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
      for (let i = 0; i < pts.length; i += 3) { x0 = Math.min(x0, pts[i]); x1 = Math.max(x1, pts[i]); z0 = Math.min(z0, pts[i + 2]); z1 = Math.max(z1, pts[i + 2]); }
      const N = 96, h = new Float32Array(N * N).fill(-1e9);
      const cell = (x, z) => [Math.min(N - 1, Math.max(0, Math.floor(((x - x0) / (x1 - x0)) * N))), Math.min(N - 1, Math.max(0, Math.floor(((z - z0) / (z1 - z0)) * N)))];
      for (let i = 0; i < pts.length; i += 3) { const [cx, cz] = cell(pts[i], pts[i + 2]); h[cz * N + cx] = Math.max(h[cz * N + cx], pts[i + 1]); }
      // fill gaps (and the neck opening) from neighbours
      for (let pass = 0; pass < 12; pass++) {
        const src = h.slice();
        for (let z = 0; z < N; z++) for (let x = 0; x < N; x++) {
          if (src[z * N + x] > -1e8) continue;
          let s = 0, n = 0;
          for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
            const v = src[Math.min(N - 1, Math.max(0, z + dz)) * N + Math.min(N - 1, Math.max(0, x + dx))];
            if (v > -1e8) { s += v; n++; }
          }
          if (n) h[z * N + x] = s / n;
        }
      }
      field = { N, h, x0, x1, z0, z1 };
    } catch (e) { console.error('customers: clippings field failed', e); }
  }
  function heightAt(x, z) {
    if (!field) return -1e9;
    const { N, h, x0, x1, z0, z1 } = field;
    const fx = ((x - x0) / (x1 - x0)) * N - 0.5, fz = ((z - z0) / (z1 - z0)) * N - 0.5;
    if (fx < 0 || fz < 0 || fx > N - 1 || fz > N - 1) return -1e9;
    const ix = Math.floor(fx), iz = Math.floor(fz), tx = fx - ix, tz = fz - iz;
    const a = h[iz * N + ix], b = h[iz * N + Math.min(N - 1, ix + 1)], c = h[Math.min(N - 1, iz + 1) * N + ix], d = h[Math.min(N - 1, iz + 1) * N + Math.min(N - 1, ix + 1)];
    if (a < -1e8 || b < -1e8 || c < -1e8 || d < -1e8) return -1e9;
    return a + (b - a) * tx + (c - a) * tz + (a - b - c + d) * tx * tz;
  }

  function hairColour(kind) {
    const tint = ctx && ctx.uHairTint ? ctx.uHairTint.value : { x: 1, y: 1, z: 1 };
    const U = HSC.U;
    const greyF = kind === 'beard' ? U.uBeardGrey.value[0] : U.uGreyA.value[0];
    if (Rng.next() < greyF) { const g = 0.36 + 0.26 * Rng.next(); return [g, g * 0.98, g * 0.93]; }
    const bt = kind === 'beard' ? U.uBeardTint.value : [1, 1, 1];
    const k = 0.055 + 0.04 * Rng.next();
    return [k * tint.x * bt[0], k * 0.68 * tint.y * bt[1], k * 0.38 * tint.z * bt[2]];
  }

  // called by the renderer for each successful cut, with the blade hit and HSC.lastCut set by the controller
  HSC.emitClippings = function (hit, intensity) {
    if (!mesh || !hit || !hit.point) return false;
    if (!field && robeRef) buildField(robeRef);
    const cut = HSC.lastCut || { cells: 6, removed: 30, kind: 'scalp' };
    HSC.lastCut = null;
    const mmEach = Math.max(0.5, cut.removed / Math.max(1, cut.cells));
    const rate = (HSC.detail && HSC.detail.clipRate) || 1;
    const n = Math.min(Math.ceil(36 * rate), Math.ceil((cut.cells * 0.45 + cut.removed / 60) * rate));
    const across = hit.bladeAcross || [1, 0, 0], nrm = hit.normal;
    const curl = HSC.U.uStyleC.value, bcurl = HSC.U.uBStyleB.value;
    const isBeard = cut.kind === 'beard';
    const now = performance.now();
    for (let k = 0; k < n; k++) {
      const i = alloc();
      const s = (Rng.next() - 0.5) * 0.23;
      const o = i * 3;
      K.pos[o] = hit.point.x + across[0] * s + nrm.x * 0.008;
      K.pos[o + 1] = hit.point.y + across[1] * s + nrm.y * 0.008;
      K.pos[o + 2] = hit.point.z + across[2] * s + nrm.z * 0.008;
      // flicked off the blade: outward from the head, plus a little scatter
      const out = 0.4 + 0.9 * Rng.next();
      K.vel[o] = nrm.x * out + (Rng.next() - 0.5) * 0.9;
      K.vel[o + 1] = nrm.y * out + (Rng.next() - 0.2) * 0.8;
      K.vel[o + 2] = nrm.z * out + (Rng.next() - 0.5) * 0.9;
      const d = [Rng.next() - 0.5, Rng.next() - 0.5, Rng.next() - 0.5], dl = Math.hypot(...d) || 1;
      const ax = [Rng.next() - 0.5, Rng.next() - 0.5, Rng.next() - 0.5], al = Math.hypot(...ax) || 1;
      K.dir.set(d.map((v) => v / dl), o);
      K.axis.set(ax.map((v) => v / al), o);
      K.spin[i] = (4 + 10 * Rng.next()) * (Rng.next() < 0.5 ? -1 : 1);
      // a piece is the removed length (varying), 1 mm ~ 0.01 world units
      const L = Math.max(0.004, mmEach * (0.5 + 0.7 * Rng.next()) * 0.01024);
      K.len[i] = L;
      // short fluff hangs in the air longer than long pieces
      K.drag[i] = 9 + 22 * (1 - Math.min(1, L / 0.12));
      K.phase[i] = Rng.next() * 6.28;
      K.state[i] = 1;
      K.born[i] = now;
      K.col.set(hairColour(cut.kind), o);
      const cr = isBeard ? bcurl : curl;
      K.curl.set([cr[0] * 0.8, Math.max(0.3, cr[1] * Math.min(1, L / 0.15)), Rng.next() * 6.28, 0.0028 * (cr[3] || 1)], i * 4);
    }
    K.moving += n;
    K.dirty = true;
    return true;
  };
  const cap = () => Math.min(MAX, (HSC.detail && HSC.detail.clipMax) || MAX);
  function alloc() {
    if (K.count < cap()) return K.count++;
    // reuse the oldest piece
    const i = K.next % cap();
    K.next = (i + 1) % cap();
    return i;
  }
  HSC.clipCap = function () {
    if (K.count > cap()) { K.count = cap(); K.next = 0; K.dirty = true; }
  };

  HSC.clearClippings = function () { K.count = 0; K.next = 0; K.moving = 0; K.dirty = false; if (geo) geo.instanceCount = 0; };
  HSC.clippingsActive = () => K.moving > 0;

  // the barber brushes the gown off at the reveal: resting pieces are flicked outward in a sweep
  // across the gown, most of them falling off the shoulders and the lap
  HSC.brushClippings = function () {
    if (!mesh || !K.count) return;
    const rest = [];
    let cx = 0, cz = 0;
    for (let i = 0; i < K.count; i++) if (K.state[i] === 3 && K.len[i] > 0) { rest.push(i); cx += K.pos[i * 3]; cz += K.pos[i * 3 + 2]; }
    if (!rest.length) return;
    cx /= rest.length; cz /= rest.length;
    rest.sort((a, b) => K.pos[a * 3] - K.pos[b * 3]);
    const waves = 6;
    for (let w = 0; w < waves; w++) {
      setTimeout(() => {
        const now = performance.now();
        const from = Math.floor((rest.length * w) / waves), to = Math.floor((rest.length * (w + 1)) / waves);
        for (let k = from; k < to; k++) {
          const i = rest[k], o = i * 3;
          if (K.state[i] !== 3) continue;
          let dx = K.pos[o] - cx, dz = K.pos[o + 2] - cz;
          const l = Math.hypot(dx, dz) || 1;
          dx /= l; dz /= l;
          const sp = 3 + 2.5 * Rng.next();
          K.vel[o] = dx * sp + (Rng.next() - 0.5) * 0.6;
          K.vel[o + 1] = 1.2 + 1.4 * Rng.next();
          K.vel[o + 2] = dz * sp + 1.6 + (Rng.next() - 0.5) * 0.8;
          K.pos[o + 1] += 0.02;
          K.drag[i] = 1 + 1.2 * Rng.next(); // flicked pieces fly further than drifting fluff
          K.state[i] = 1;
          K.born[i] = now;
          K.moving++;
        }
        K.dirty = true;
      }, 500 + w * 170);
    }
  };

  HSC.stepClippings = function () {
    if (!mesh) return;
    const now = performance.now();
    if (!K.moving && !K.dirty) { K.last = now; return; }
    K.dirty = false;
    const dt = Math.min(0.033, K.last ? (now - K.last) / 1000 : 0.016);
    K.last = now;
    let moving = 0;
    const t = now / 1000;
    for (let i = 0; i < K.count; i++) {
      const st = K.state[i];
      if (st === 0 || st === 3) continue;
      const o = i * 3;
      let x = K.pos[o], y = K.pos[o + 1], z = K.pos[o + 2], vx = K.vel[o], vy = K.vel[o + 1], vz = K.vel[o + 2];
      if (st === 1) {
        // gravity, air drag and a little flutter
        const k = K.drag[i], ph = K.phase[i];
        vx += (Math.sin(t * 7 + ph) * 5) * dt;
        vz += (Math.cos(t * 6 + ph * 1.3) * 5) * dt;
        vy -= G * dt;
        const damp = Math.exp(-k * dt);
        vx *= damp; vy *= damp; vz *= damp;
        // tumble
        const a = [K.axis[o], K.axis[o + 1], K.axis[o + 2]], d = [K.dir[o], K.dir[o + 1], K.dir[o + 2]], ang = K.spin[i] * dt;
        const c = Math.cos(ang), s = Math.sin(ang), dot = a[0] * d[0] + a[1] * d[1] + a[2] * d[2];
        const cr = [a[1] * d[2] - a[2] * d[1], a[2] * d[0] - a[0] * d[2], a[0] * d[1] - a[1] * d[0]];
        for (let q = 0; q < 3; q++) K.dir[o + q] = d[q] * c + cr[q] * s + a[q] * dot * (1 - c);
      } else {
        // sliding down a steep fold of the gown
        vx *= Math.exp(-6 * dt); vz *= Math.exp(-6 * dt);
      }
      x += vx * dt; y += vy * dt; z += vz * dt;
      const ground = heightAt(x, z);
      if (y < ground + 0.004) {
        const e = 0.05;
        const gx = (heightAt(x + e, z) - heightAt(x - e, z)) / (2 * e), gz = (heightAt(x, z + e) - heightAt(x, z - e)) / (2 * e);
        const slope = Math.hypot(gx, gz);
        y = ground + 0.004;
        if (slope > 1.1 && Number.isFinite(slope) && slope < 50) {
          K.state[i] = 2;
          const sp = 0.9;
          vx = (-gx / slope) * sp; vz = (-gz / slope) * sp; vy = 0;
        } else {
          K.state[i] = 3;
          vx = vy = vz = 0;
          // lie flat on the cloth
          K.dir[o + 1] *= 0.15;
          const l = Math.hypot(K.dir[o], K.dir[o + 1], K.dir[o + 2]) || 1;
          K.dir[o] /= l; K.dir[o + 1] /= l; K.dir[o + 2] /= l;
        }
      }
      if (y < -4 || now - K.born[i] > 20000) { K.state[i] = 3; vx = vy = vz = 0; if (y < -4) K.len[i] = 0; }
      K.pos[o] = x; K.pos[o + 1] = y; K.pos[o + 2] = z;
      K.vel[o] = vx; K.vel[o + 1] = vy; K.vel[o + 2] = vz;
      if (K.state[i] !== 3) moving++;
    }
    K.moving = moving;
    // upload
    const P = attrs.iPos.array, D = attrs.iDir.array, Cu = attrs.iCurl.array, Co = attrs.iCol.array;
    for (let i = 0; i < K.count; i++) {
      P[i * 4] = K.pos[i * 3]; P[i * 4 + 1] = K.pos[i * 3 + 1]; P[i * 4 + 2] = K.pos[i * 3 + 2]; P[i * 4 + 3] = K.len[i];
      D[i * 3] = K.dir[i * 3]; D[i * 3 + 1] = K.dir[i * 3 + 1]; D[i * 3 + 2] = K.dir[i * 3 + 2];
      for (let q = 0; q < 4; q++) Cu[i * 4 + q] = K.curl[i * 4 + q];
      Co[i * 3] = K.col[i * 3]; Co[i * 3 + 1] = K.col[i * 3 + 1]; Co[i * 3 + 2] = K.col[i * 3 + 2];
    }
    for (const a of Object.values(attrs)) a.needsUpdate = true;
    geo.instanceCount = K.count;
  };
})(globalThis.HSC || (globalThis.HSC = {}));

